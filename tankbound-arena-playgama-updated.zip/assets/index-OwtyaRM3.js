import { n as require_client, r as require_react, t as require_jsx_runtime } from "./vendor-react-BZy67Uj2.js";
import { A as Minimize2, B as Film, C as Radio, D as Palette, E as Pause, F as House, G as ChevronRight, H as Compass, I as Hexagon, J as ChartColumn, K as ChevronLeft, L as HardDrive, M as Map$1, N as Lock, O as Package, P as Layers, R as Gift, S as RotateCcw, T as PenLine, U as Clock, V as Crosshair, W as CircleCheck, X as Award, Y as BookOpen, Z as ArrowLeft, _ as Skull, a as Volume2, b as Settings, c as Trophy, d as Trash2, f as Target, g as SlidersVertical, h as Sparkles, i as VolumeX, j as Maximize2, k as Music, l as TrendingUp, m as Stamp, n as X$1, o as Users, p as Star, q as Check, r as Wrench, s as User, t as Zap, u as TrendingDown, v as ShoppingCart, w as Play, x as RotateCw, y as Shield, z as Flame } from "./vendor-ui-DrMVxk7M.js";
import { t as __webpack_exports__default } from "./vendor-phaser-CpLD4Qbr.js";
// \0vite/modulepreload-polyfill.js
(function polyfill() {
	const relList = document.createElement("link").relList;
	if (relList && relList.supports && relList.supports("modulepreload")) return;
	for (const link of document.querySelectorAll("link[rel=\"modulepreload\"]")) processPreload(link);
	new MutationObserver((mutations) => {
		for (const mutation of mutations) {
			if (mutation.type !== "childList") continue;
			for (const node of mutation.addedNodes) if (node.tagName === "LINK" && node.rel === "modulepreload") processPreload(node);
		}
	}).observe(document, {
		childList: true,
		subtree: true
	});
	function getFetchOpts(link) {
		const fetchOpts = {};
		if (link.integrity) fetchOpts.integrity = link.integrity;
		if (link.referrerPolicy) fetchOpts.referrerPolicy = link.referrerPolicy;
		if (link.crossOrigin === "use-credentials") fetchOpts.credentials = "include";
		else if (link.crossOrigin === "anonymous") fetchOpts.credentials = "omit";
		else fetchOpts.credentials = "same-origin";
		return fetchOpts;
	}
	function processPreload(link) {
		if (link.ep) return;
		link.ep = true;
		const fetchOpts = getFetchOpts(link);
		fetch(link.href, fetchOpts);
	}
})();
// src/data/progression.ts
var import_react = require_react();
var import_client = require_client();
var SCRAP_REWARD_CONFIG = {
	matchCompletionScrap: 20,
	eliminationScrap: 10,
	victoryBonusScrap: 35,
	placementPerformanceBonuses: [
		25,
		18,
		12,
		6,
		2,
		0,
		0,
		0
	],
	damagePerBonusScrap: 50,
	maxDamagePerformanceScrap: 15
};
var XP_REWARD_CONFIG = {
	matchCompletionXp: 50,
	victoryBonusXp: 100,
	eliminationXp: 20,
	topThreeBonusXp: 30,
	topThreeMaxPlacement: 3
};
var LEVEL_CURVE_CONFIG = {
	startingLevel: 1,
	baseXp: 100,
	linearStep: 50,
	quadraticStep: 10
};
/**
* Computes the XP required to advance from `level` to `level + 1`.
* Strictly increasing for every level >= 1 without excessive grinding:
* Lv1->2: 100, Lv2->3: 160, Lv3->4: 240, Lv4->5: 340, Lv5->6: 460, ...
*/
function getXpRequiredForLevel(level, config = LEVEL_CURVE_CONFIG) {
	const n = Math.max(config.startingLevel, Math.floor(level)) - config.startingLevel;
	return Math.max(1, Math.round(config.baseXp + n * config.linearStep + n * n * config.quadraticStep));
}
/**
* Visual-only tank cosmetics. Never modifies tank damage, HP, speed, reload, or ability strength.
*/
var COSMETIC_DEFINITIONS = {
	default: {
		id: "default",
		name: "Factory Standard",
		description: "Original combat livery unique to each tank hull.",
		unlockLevel: 1,
		previewPrimary: "#5B7048",
		previewSecondary: "#3E4F30",
		previewAccent: "#E08E26"
	},
	brass_trim: {
		id: "brass_trim",
		name: "Field Brass Trim",
		description: "Warm brushed-brass turret plating and gilded barrel accents (visual only).",
		unlockLevel: 3,
		previewPrimary: "#6F6842",
		previewSecondary: "#4B452B",
		previewAccent: "#F59E0B",
		turretColorOverride: "#8F824E",
		accentColorOverride: "#FBBF24"
	},
	cobalt_strike: {
		id: "cobalt_strike",
		name: "Cobalt Strike",
		description: "Slate-cobalt armor finish with crisp glacier-cyan highlights (visual only).",
		unlockLevel: 7,
		previewPrimary: "#365573",
		previewSecondary: "#22384D",
		previewAccent: "#38BDF8",
		hullPrimaryOverride: "#365573",
		hullSecondaryOverride: "#22384D",
		turretColorOverride: "#4A7094",
		accentColorOverride: "#38BDF8"
	},
	apex_obsidian: {
		id: "apex_obsidian",
		name: "Apex Obsidian",
		description: "Championship matte-obsidian armor with radiant gold trim (visual only).",
		unlockLevel: 10,
		previewPrimary: "#26292E",
		previewSecondary: "#181A1E",
		previewAccent: "#FACC15",
		hullPrimaryOverride: "#2A2D34",
		hullSecondaryOverride: "#1B1D22",
		turretColorOverride: "#383C46",
		accentColorOverride: "#FACC15",
		treadColorOverride: "#121316"
	},
	crimson_vanguard: {
		id: "crimson_vanguard",
		name: "Crimson Vanguard",
		description: "Earned via Sharpshooter achievement. Deep crimson steel & ember trim (visual only).",
		unlockLevel: 0,
		unlockSourceLabel: "Sharpshooter",
		previewPrimary: "#7F2B2B",
		previewSecondary: "#541B1B",
		previewAccent: "#FB923C",
		hullPrimaryOverride: "#7F2B2B",
		hullSecondaryOverride: "#541B1B",
		turretColorOverride: "#993838",
		accentColorOverride: "#FB923C"
	},
	desert_phantom: {
		id: "desert_phantom",
		name: "Sandstorm Spec",
		description: "Earned via Last Tank Standing achievement. Arid dune plating & amber optics (visual only).",
		unlockLevel: 0,
		unlockSourceLabel: "Last Tank Standing",
		previewPrimary: "#A38A62",
		previewSecondary: "#735E3E",
		previewAccent: "#FDE047",
		hullPrimaryOverride: "#A38A62",
		hullSecondaryOverride: "#735E3E",
		turretColorOverride: "#B89E74",
		accentColorOverride: "#FDE047"
	},
	emerald_squad: {
		id: "emerald_squad",
		name: "Emerald Corps",
		description: "Earned via Tank Enthusiast achievement. Forest-emerald armor & lime trim (visual only).",
		unlockLevel: 0,
		unlockSourceLabel: "Tank Enthusiast",
		previewPrimary: "#2E6B4E",
		previewSecondary: "#1E4A35",
		previewAccent: "#4ADE80",
		hullPrimaryOverride: "#2E6B4E",
		hullSecondaryOverride: "#1E4A35",
		turretColorOverride: "#3C8763",
		accentColorOverride: "#4ADE80"
	},
	hazard_stripes: {
		id: "hazard_stripes",
		name: "Demolition Amber",
		description: "Earned via Demolition Expert achievement. Charcoal iron & high-vis amber (visual only).",
		unlockLevel: 0,
		unlockSourceLabel: "Demolition Expert",
		previewPrimary: "#44464A",
		previewSecondary: "#2C2E31",
		previewAccent: "#F59E0B",
		hullPrimaryOverride: "#44464A",
		hullSecondaryOverride: "#2C2E31",
		turretColorOverride: "#575A60",
		accentColorOverride: "#F59E0B"
	},
	warlord_crimson: {
		id: "warlord_crimson",
		name: "Dominator Ruby",
		description: "Earned via Dominator achievement. Dark titanium hull & ruby glow (visual only).",
		unlockLevel: 0,
		unlockSourceLabel: "Dominator",
		previewPrimary: "#3A232D",
		previewSecondary: "#24141B",
		previewAccent: "#F43F5E",
		hullPrimaryOverride: "#3A232D",
		hullSecondaryOverride: "#24141B",
		turretColorOverride: "#4F303D",
		accentColorOverride: "#F43F5E",
		treadColorOverride: "#161114"
	},
	arctic_chrome: {
		id: "arctic_chrome",
		name: "Arctic Chrome",
		description: "Workshop Edition: Polar titanium plating with glacier-blue accents (visual only).",
		unlockLevel: 0,
		scrapCost: 120,
		unlockSourceLabel: "Shop · 120 Scrap",
		previewPrimary: "#B9C8D9",
		previewSecondary: "#64798F",
		previewAccent: "#38BDF8",
		hullPrimaryOverride: "#B9C8D9",
		hullSecondaryOverride: "#64798F",
		turretColorOverride: "#DAE5F0",
		accentColorOverride: "#38BDF8",
		treadColorOverride: "#242D38"
	},
	inferno_forged: {
		id: "inferno_forged",
		name: "Inferno Forged",
		description: "Workshop Edition: Molten charcoal steel with forged amber-red highlights (visual only).",
		unlockLevel: 0,
		scrapCost: 160,
		unlockSourceLabel: "Shop · 160 Scrap",
		previewPrimary: "#3B2322",
		previewSecondary: "#241413",
		previewAccent: "#FB923C",
		hullPrimaryOverride: "#3B2322",
		hullSecondaryOverride: "#241413",
		turretColorOverride: "#572C26",
		accentColorOverride: "#FB923C",
		treadColorOverride: "#171111"
	}
};
var COSMETIC_LIST = [
	COSMETIC_DEFINITIONS.default,
	COSMETIC_DEFINITIONS.brass_trim,
	COSMETIC_DEFINITIONS.cobalt_strike,
	COSMETIC_DEFINITIONS.apex_obsidian,
	COSMETIC_DEFINITIONS.crimson_vanguard,
	COSMETIC_DEFINITIONS.desert_phantom,
	COSMETIC_DEFINITIONS.emerald_squad,
	COSMETIC_DEFINITIONS.hazard_stripes,
	COSMETIC_DEFINITIONS.warlord_crimson,
	COSMETIC_DEFINITIONS.arctic_chrome,
	COSMETIC_DEFINITIONS.inferno_forged
];
/**
* Returns a purely visual TankVisualConfig with the cosmetic color scheme applied.
*/
function getEffectiveTankVisual(tank, cosmeticId = "default") {
	const cosmetic = COSMETIC_DEFINITIONS[cosmeticId] ?? COSMETIC_DEFINITIONS.default;
	if (cosmetic.id === "default") return tank.visual;
	return {
		...tank.visual,
		hullPrimary: cosmetic.hullPrimaryOverride ?? tank.visual.hullPrimary,
		hullSecondary: cosmetic.hullSecondaryOverride ?? tank.visual.hullSecondary,
		turretColor: cosmetic.turretColorOverride ?? tank.visual.turretColor,
		accentColor: cosmetic.accentColorOverride ?? tank.visual.accentColor,
		treadColor: cosmetic.treadColorOverride ?? tank.visual.treadColor
	};
}
/**
* Configurable level milestone reward schedule. Easy to expand with additional levels/rewards.
*/
var MILESTONE_REWARDS = [
	{
		level: 2,
		id: "milestone_lvl_2",
		title: "Field Requisition",
		description: "Small Scrap currency bonus for reaching Level 2.",
		type: "currency",
		scrapAmount: 100
	},
	{
		level: 3,
		id: "milestone_lvl_3",
		title: "Field Brass Trim",
		description: "Basic tank cosmetic with brushed brass turret & barrel accents (visual only).",
		type: "cosmetic",
		cosmeticId: "brass_trim"
	},
	{
		level: 5,
		id: "milestone_lvl_5",
		title: "Commander Supply Crate",
		description: "Scrap currency reward for seasoned arena commanders.",
		type: "currency",
		scrapAmount: 250
	},
	{
		level: 7,
		id: "milestone_lvl_7",
		title: "Cobalt Strike Camo",
		description: "Additional tank cosmetic featuring cobalt plating & cyan trim (visual only).",
		type: "cosmetic",
		cosmeticId: "cobalt_strike"
	},
	{
		level: 10,
		id: "milestone_lvl_10",
		title: "Apex Obsidian Skin",
		description: "Special mastery tank skin with obsidian armor & gold trim (visual only).",
		type: "cosmetic",
		cosmeticId: "apex_obsidian"
	}
];
function calculateMatchXpBreakdown(result, config = XP_REWARD_CONFIG) {
	const completionXp = Math.max(0, Math.round(config.matchCompletionXp));
	const victoryBonusXp = result.victory ? Math.max(0, Math.round(config.victoryBonusXp)) : 0;
	const eliminationXp = Math.max(0, Math.floor(result.eliminations)) * Math.max(0, Math.round(config.eliminationXp));
	const topThreeBonusXp = result.placement >= 1 && result.placement <= config.topThreeMaxPlacement ? Math.max(0, Math.round(config.topThreeBonusXp)) : 0;
	return {
		completionXp,
		victoryBonusXp,
		eliminationXp,
		topThreeBonusXp,
		totalXp: completionXp + victoryBonusXp + eliminationXp + topThreeBonusXp
	};
}
function calculateMatchScrapBreakdown(result, config = SCRAP_REWARD_CONFIG) {
	const completionScrap = Math.max(0, Math.round(config.matchCompletionScrap));
	const eliminationScrap = Math.max(0, Math.floor(result.eliminations)) * Math.max(0, Math.round(config.eliminationScrap));
	const victoryBonusScrap = result.victory ? Math.max(0, Math.round(config.victoryBonusScrap)) : 0;
	const placementIdx = Math.max(0, Math.floor(result.placement) - 1);
	const placementBonus = Math.max(0, Math.round(config.placementPerformanceBonuses[placementIdx] ?? 0));
	const damageStep = Math.max(1, Math.round(config.damagePerBonusScrap));
	const performanceBonusScrap = placementBonus + Math.min(Math.max(0, Math.round(config.maxDamagePerformanceScrap)), Math.max(0, Math.floor(Math.max(0, result.damageDealt) / damageStep)));
	return {
		completionScrap,
		eliminationScrap,
		victoryBonusScrap,
		performanceBonusScrap,
		totalScrap: completionScrap + eliminationScrap + victoryBonusScrap + performanceBonusScrap
	};
}
/**
* Centralized XP, leveling, and milestone reward service.
* Idempotent per matchId: calling multiple times with the same matchId returns the existing state with alreadyProcessed=true.
*/
function applyMatchProgression(prev, result, overrides = {}) {
	const xpConfig = overrides.xpConfig ?? XP_REWARD_CONFIG;
	const curveConfig = overrides.curveConfig ?? LEVEL_CURVE_CONFIG;
	const milestones = overrides.milestones ?? MILESTONE_REWARDS;
	const matchId = result.matchId?.trim();
	if (Boolean(matchId && prev.processedMatchIds.includes(matchId))) return {
		nextProgression: prev,
		summary: {
			matchId: matchId || "unknown",
			xpBreakdown: {
				completionXp: 0,
				victoryBonusXp: 0,
				eliminationXp: 0,
				topThreeBonusXp: 0,
				totalXp: 0
			},
			scrapBreakdown: {
				completionScrap: 0,
				eliminationScrap: 0,
				victoryBonusScrap: 0,
				performanceBonusScrap: 0,
				totalScrap: 0
			},
			previousLevel: prev.level,
			newLevel: prev.level,
			previousXp: prev.xp,
			previousXpToNext: prev.xpToNext,
			newXp: prev.xp,
			newXpToNext: prev.xpToNext,
			levelsGained: 0,
			unlockedMilestones: [],
			scrapFromMatch: 0,
			scrapFromMilestones: 0,
			totalScrapAwarded: 0,
			alreadyProcessed: true
		}
	};
	const xpBreakdown = calculateMatchXpBreakdown(result, xpConfig);
	const computedScrapBreakdown = result.scrapBreakdown ?? calculateMatchScrapBreakdown(result, overrides.scrapConfig ?? SCRAP_REWARD_CONFIG);
	const previousLevel = Math.max(curveConfig.startingLevel, Math.floor(prev.level));
	const previousXp = Math.max(0, Math.floor(prev.xp));
	const previousXpToNext = getXpRequiredForLevel(previousLevel, curveConfig);
	let newLevel = previousLevel;
	let newXp = previousXp + xpBreakdown.totalXp;
	let newXpToNext = previousXpToNext;
	while (newXp >= newXpToNext) {
		newXp -= newXpToNext;
		newLevel += 1;
		newXpToNext = getXpRequiredForLevel(newLevel, curveConfig);
	}
	const claimedLevels = new Set(prev.claimedMilestoneLevels);
	const unlockedCosmetics = new Set(prev.unlockedCosmetics.length > 0 ? prev.unlockedCosmetics : ["default"]);
	unlockedCosmetics.add("default");
	const unlockedMilestones = [];
	let scrapFromMilestones = 0;
	for (const milestone of milestones) if (milestone.level <= newLevel && !claimedLevels.has(milestone.level)) {
		claimedLevels.add(milestone.level);
		unlockedMilestones.push(milestone);
		if (milestone.type === "currency" && milestone.scrapAmount) scrapFromMilestones += Math.max(0, Math.round(milestone.scrapAmount));
		if (milestone.type === "cosmetic" && milestone.cosmeticId) unlockedCosmetics.add(milestone.cosmeticId);
	}
	const scrapFromMatch = Math.max(0, Math.round(result.scrapEarned));
	const scrapBreakdown = result.scrapBreakdown ? result.scrapBreakdown : {
		...computedScrapBreakdown,
		totalScrap: scrapFromMatch
	};
	const totalScrapAwarded = scrapFromMatch + scrapFromMilestones;
	const safeElims = Math.max(0, Math.floor(result.eliminations));
	const safeSurvivalSec = Math.max(0, Math.floor(result.survivalSec));
	const bestPlacement = prev.bestPlacement === null ? result.placement : Math.min(prev.bestPlacement, result.placement);
	const updatedProcessedIds = matchId ? [matchId, ...prev.processedMatchIds].slice(0, 50) : prev.processedMatchIds;
	return {
		nextProgression: {
			...prev,
			level: newLevel,
			xp: newXp,
			xpToNext: newXpToNext,
			totalXpEarned: Math.max(0, prev.totalXpEarned) + xpBreakdown.totalXp,
			scrap: Math.max(0, prev.scrap) + totalScrapAwarded,
			totalScrapEarned: Math.max(0, prev.totalScrapEarned ?? 0) + totalScrapAwarded,
			matchesPlayed: Math.max(0, prev.matchesPlayed) + 1,
			wins: Math.max(0, prev.wins) + (result.victory ? 1 : 0),
			defeats: Math.max(0, prev.defeats ?? 0) + (result.victory ? 0 : 1),
			totalEliminations: Math.max(0, prev.totalEliminations) + safeElims,
			totalPlaytimeSec: Math.max(0, prev.totalPlaytimeSec) + safeSurvivalSec,
			bestPlacement,
			claimedMilestoneLevels: Array.from(claimedLevels).sort((a, b) => a - b),
			unlockedCosmetics: Array.from(unlockedCosmetics),
			processedMatchIds: updatedProcessedIds
		},
		summary: {
			matchId: matchId || `match_${Date.now()}`,
			xpBreakdown,
			scrapBreakdown,
			previousLevel,
			newLevel,
			previousXp,
			previousXpToNext,
			newXp,
			newXpToNext,
			levelsGained: newLevel - previousLevel,
			unlockedMilestones,
			scrapFromMatch,
			scrapFromMilestones,
			totalScrapAwarded,
			alreadyProcessed: false
		}
	};
}
/**
* Centralized reward distributor used by missions, achievements, and bonus claims.
* Applies XP through the exact same leveling curve and grants level milestones automatically.
*/
function grantProgressionRewards(prev, reward, overrides = {}) {
	const curveConfig = overrides.curveConfig ?? LEVEL_CURVE_CONFIG;
	const milestones = overrides.milestones ?? MILESTONE_REWARDS;
	const xpAwarded = Math.max(0, Math.round(reward.xp ?? 0));
	const baseScrapAwarded = Math.max(0, Math.round(reward.scrap ?? 0));
	const previousLevel = Math.max(curveConfig.startingLevel, Math.floor(prev.level));
	let newLevel = previousLevel;
	let newXp = Math.max(0, Math.floor(prev.xp)) + xpAwarded;
	let newXpToNext = getXpRequiredForLevel(previousLevel, curveConfig);
	while (newXp >= newXpToNext) {
		newXp -= newXpToNext;
		newLevel += 1;
		newXpToNext = getXpRequiredForLevel(newLevel, curveConfig);
	}
	const claimedLevels = new Set(prev.claimedMilestoneLevels);
	const unlockedCosmetics = new Set(prev.unlockedCosmetics.length > 0 ? prev.unlockedCosmetics : ["default"]);
	unlockedCosmetics.add("default");
	const unlockedMilestones = [];
	let scrapFromMilestones = 0;
	for (const milestone of milestones) if (milestone.level <= newLevel && !claimedLevels.has(milestone.level)) {
		claimedLevels.add(milestone.level);
		unlockedMilestones.push(milestone);
		if (milestone.type === "currency" && milestone.scrapAmount) scrapFromMilestones += Math.max(0, Math.round(milestone.scrapAmount));
		if (milestone.type === "cosmetic" && milestone.cosmeticId) unlockedCosmetics.add(milestone.cosmeticId);
	}
	let cosmeticUnlocked = null;
	if (reward.cosmeticId && reward.cosmeticId in COSMETIC_DEFINITIONS) {
		if (!unlockedCosmetics.has(reward.cosmeticId)) cosmeticUnlocked = reward.cosmeticId;
		unlockedCosmetics.add(reward.cosmeticId);
	}
	const scrapAwarded = baseScrapAwarded + scrapFromMilestones;
	return {
		nextProgression: {
			...prev,
			level: newLevel,
			xp: newXp,
			xpToNext: newXpToNext,
			totalXpEarned: Math.max(0, prev.totalXpEarned) + xpAwarded,
			scrap: Math.max(0, prev.scrap) + scrapAwarded,
			totalScrapEarned: Math.max(0, prev.totalScrapEarned ?? 0) + scrapAwarded,
			claimedMilestoneLevels: Array.from(claimedLevels).sort((a, b) => a - b),
			unlockedCosmetics: Array.from(unlockedCosmetics)
		},
		xpAwarded,
		scrapAwarded,
		cosmeticUnlocked,
		previousLevel,
		newLevel,
		levelsGained: newLevel - previousLevel,
		unlockedMilestones
	};
}
function formatPlaytime(totalSeconds) {
	const safe = Math.max(0, Math.floor(totalSeconds));
	const hours = Math.floor(safe / 3600);
	const mins = Math.floor(safe % 3600 / 60);
	const secs = safe % 60;
	if (hours > 0) return `${hours}h ${mins.toString().padStart(2, "0")}m`;
	return `${mins}m ${secs.toString().padStart(2, "0")}s`;
}
// src/data/customization.ts
var PAINT_COLOR_SWATCHES = [
	{
		name: "Olive Drab",
		hex: "#5B7048",
		scrapCost: 0
	},
	{
		name: "Dark Sage",
		hex: "#3E4F30",
		scrapCost: 0
	},
	{
		name: "Steel Slate",
		hex: "#4B5563",
		scrapCost: 0
	},
	{
		name: "Gunmetal",
		hex: "#333B46",
		scrapCost: 0
	},
	{
		name: "Obsidian",
		hex: "#26292E",
		scrapCost: 0
	},
	{
		name: "Desert Sand",
		hex: "#B89B72",
		scrapCost: 0
	},
	{
		name: "Forest Moss",
		hex: "#2E6B4E",
		scrapCost: 25
	},
	{
		name: "Cobalt Blue",
		hex: "#365573",
		scrapCost: 30
	},
	{
		name: "Arctic Ice",
		hex: "#CBD5E1",
		scrapCost: 35
	},
	{
		name: "Canyon Rust",
		hex: "#B86B2B",
		scrapCost: 25
	},
	{
		name: "Crimson Red",
		hex: "#8F2D2D",
		scrapCost: 35
	},
	{
		name: "Hazard Amber",
		hex: "#D97706",
		scrapCost: 30
	},
	{
		name: "Phantom Violet",
		hex: "#4B435E",
		scrapCost: 35
	},
	{
		name: "Arc Teal",
		hex: "#2E5A6B",
		scrapCost: 40
	}
];
var DECAL_COLOR_SWATCHES = [
	{
		name: "Stencil Cream",
		hex: "#F3EFE6",
		scrapCost: 0
	},
	{
		name: "Tactical Amber",
		hex: "#E08E26",
		scrapCost: 0
	},
	{
		name: "Command Gold",
		hex: "#FACC15",
		scrapCost: 0
	},
	{
		name: "Stencil Charcoal",
		hex: "#161815",
		scrapCost: 0
	},
	{
		name: "Signal Red",
		hex: "#EF4444",
		scrapCost: 25
	},
	{
		name: "Glacier Cyan",
		hex: "#38BDF8",
		scrapCost: 25
	},
	{
		name: "Squad Emerald",
		hex: "#4ADE80",
		scrapCost: 25
	},
	{
		name: "Arc Violet",
		hex: "#C084FC",
		scrapCost: 25
	}
];
var STARTER_PAINT_COLORS = Array.from(/* @__PURE__ */ new Set([...PAINT_COLOR_SWATCHES.filter((s) => s.scrapCost === 0).map((s) => s.hex.toUpperCase()), ...DECAL_COLOR_SWATCHES.filter((s) => s.scrapCost === 0).map((s) => s.hex.toUpperCase())]));
var DECAL_POSITION_OPTIONS = [
	{
		id: "hull_front",
		label: "Front Glacis",
		shortLabel: "Front",
		surface: "hull"
	},
	{
		id: "hull_rear",
		label: "Rear Deck",
		shortLabel: "Rear",
		surface: "hull"
	},
	{
		id: "hull_flanks",
		label: "Side Skirts",
		shortLabel: "Flanks",
		surface: "hull"
	},
	{
		id: "turret_top",
		label: "Turret Dome",
		shortLabel: "Turret",
		surface: "turret"
	}
];
var TANK_DECAL_LIST = [
	{
		id: "none",
		name: "No Decal",
		category: "None",
		description: "Clean painted armor with no surface markings.",
		scrapCost: 0
	},
	{
		id: "chevron",
		name: "Strike Chevron",
		category: "Insignia",
		description: "Armored battalion V-chevron insignia.",
		scrapCost: 0
	},
	{
		id: "iron_crosshair",
		name: "Target Crosshair",
		category: "Insignia",
		description: "Precision gunnery reticle emblem.",
		scrapCost: 35
	},
	{
		id: "shield_crest",
		name: "Vanguard Crest",
		category: "Insignia",
		description: "Armored defense division shield emblem.",
		scrapCost: 40
	},
	{
		id: "command_star",
		name: "Command Star",
		category: "Star",
		description: "Classic five-point military command star.",
		scrapCost: 0
	},
	{
		id: "num_01",
		name: "Unit 01",
		category: "Number",
		description: "Lead company tactical stencil number 01.",
		labelText: "01",
		scrapCost: 0
	},
	{
		id: "num_07",
		name: "Unit 07",
		category: "Number",
		description: "Reconnaissance unit stencil number 07.",
		labelText: "07",
		scrapCost: 30
	},
	{
		id: "num_42",
		name: "Unit 42",
		category: "Number",
		description: "Heavy division stencil number 42.",
		labelText: "42",
		scrapCost: 30
	},
	{
		id: "num_99",
		name: "Unit 99",
		category: "Number",
		description: "Veteran squadron stencil number 99.",
		labelText: "99",
		scrapCost: 35
	},
	{
		id: "twin_stripes",
		name: "Twin Racing Stripes",
		category: "Stripes",
		description: "Dual parallel armored rally stripes.",
		scrapCost: 0
	},
	{
		id: "hazard_stripes",
		name: "Hazard Chevrons",
		category: "Stripes",
		description: "Diagonal high-visibility caution bands.",
		scrapCost: 45
	},
	{
		id: "apex_diamond",
		name: "Apex Diamond",
		category: "Geometric",
		description: "Twin-ring tactical diamond prism.",
		scrapCost: 45
	},
	{
		id: "hex_core",
		name: "Hexagon Core",
		category: "Geometric",
		description: "Reinforced hexagonal reactor mark.",
		scrapCost: 50
	},
	{
		id: "thunder_bolt",
		name: "Shock Bolt",
		category: "Geometric",
		description: "High-voltage lightning strike glyph.",
		scrapCost: 50
	},
	{
		id: "apex_crown",
		name: "Arena Crown",
		category: "Special",
		description: "Three-spire championship victory crown.",
		scrapCost: 65
	},
	{
		id: "winged_crest",
		name: "Winged Ace",
		category: "Special",
		description: "Spread-wing ace commander emblem.",
		scrapCost: 65
	}
];
var STARTER_DECAL_IDS = TANK_DECAL_LIST.filter((d) => (d.scrapCost ?? 0) === 0).map((d) => d.id);
var TANK_DECAL_MAP = Object.fromEntries(TANK_DECAL_LIST.map((d) => [d.id, d]));
var TANK_COSMETIC_PRESETS = [
	{
		id: "assault_forest_vanguard",
		tankId: "assault",
		name: "Forest Vanguard",
		description: "High-contrast olive camo with twin cream rally stripes.",
		scrapCost: 45,
		customization: {
			primaryColor: "#435C38",
			secondaryColor: "#2B3D24",
			turretColor: "#5B784D",
			barrelColor: "#232920",
			decalId: "twin_stripes",
			decalPosition: "hull_front",
			decalColor: "#F3EFE6",
			presetId: "assault_forest_vanguard"
		}
	},
	{
		id: "assault_desert_sentinel",
		tankId: "assault",
		name: "Desert Sentinel",
		description: "Arid sandstone armor with bold battalion chevron.",
		scrapCost: 65,
		customization: {
			primaryColor: "#B89B72",
			secondaryColor: "#7D6648",
			turretColor: "#CCB086",
			barrelColor: "#4A3D2B",
			decalId: "chevron",
			decalPosition: "turret_top",
			decalColor: "#161815",
			presetId: "assault_desert_sentinel"
		}
	},
	{
		id: "assault_midnight_strike",
		tankId: "assault",
		name: "Midnight Strike",
		description: "Stealth charcoal hull paired with amber Unit 01 markings.",
		scrapCost: 85,
		customization: {
			primaryColor: "#2B3038",
			secondaryColor: "#1B1E24",
			turretColor: "#3B424D",
			barrelColor: "#1F2329",
			decalId: "num_01",
			decalPosition: "turret_top",
			decalColor: "#E08E26",
			presetId: "assault_midnight_strike"
		}
	},
	{
		id: "fortress_iron_bastion",
		tankId: "fortress",
		name: "Iron Bastion",
		description: "Heavy gunmetal hull anchored by a vanguard shield crest.",
		scrapCost: 45,
		customization: {
			primaryColor: "#3D444E",
			secondaryColor: "#272C33",
			turretColor: "#545D6B",
			barrelColor: "#1F242B",
			decalId: "shield_crest",
			decalPosition: "turret_top",
			decalColor: "#38BDF8",
			presetId: "fortress_iron_bastion"
		}
	},
	{
		id: "fortress_arctic_aegis",
		tankId: "fortress",
		name: "Arctic Aegis",
		description: "Tundra white composite armor with steel-cobalt cannon.",
		scrapCost: 65,
		customization: {
			primaryColor: "#CBD5E1",
			secondaryColor: "#64748B",
			turretColor: "#E2E8F0",
			barrelColor: "#334155",
			decalId: "command_star",
			decalPosition: "hull_front",
			decalColor: "#365573",
			presetId: "fortress_arctic_aegis"
		}
	},
	{
		id: "fortress_siege_breaker",
		tankId: "fortress",
		name: "Siege Breaker",
		description: "Charcoal armor with industrial hazard stripes on flanks.",
		scrapCost: 85,
		customization: {
			primaryColor: "#33363B",
			secondaryColor: "#212327",
			turretColor: "#484C54",
			barrelColor: "#D97706",
			decalId: "hazard_stripes",
			decalPosition: "hull_flanks",
			decalColor: "#FACC15",
			presetId: "fortress_siege_breaker"
		}
	},
	{
		id: "scout_canyon_runner",
		tankId: "scout",
		name: "Canyon Runner",
		description: "Burnt copper chassis marked with lightning speed stripes.",
		scrapCost: 45,
		customization: {
			primaryColor: "#C26327",
			secondaryColor: "#823E14",
			turretColor: "#E07A38",
			barrelColor: "#2A231E",
			decalId: "num_07",
			decalPosition: "turret_top",
			decalColor: "#F3EFE6",
			presetId: "scout_canyon_runner"
		}
	},
	{
		id: "scout_night_recon",
		tankId: "scout",
		name: "Night Recon",
		description: "Cobalt-night stealth recon hull with glacier wings.",
		scrapCost: 65,
		customization: {
			primaryColor: "#24374D",
			secondaryColor: "#162333",
			turretColor: "#365573",
			barrelColor: "#1A2430",
			decalId: "winged_crest",
			decalPosition: "hull_front",
			decalColor: "#38BDF8",
			presetId: "scout_night_recon"
		}
	},
	{
		id: "scout_hazard_hornet",
		tankId: "scout",
		name: "Hazard Hornet",
		description: "High-visibility amber chassis with black racing stripes.",
		scrapCost: 85,
		customization: {
			primaryColor: "#D97706",
			secondaryColor: "#92400E",
			turretColor: "#F59E0B",
			barrelColor: "#1C1917",
			decalId: "twin_stripes",
			decalPosition: "hull_rear",
			decalColor: "#161815",
			presetId: "scout_hazard_hornet"
		}
	},
	{
		id: "artillery_dune_howitzer",
		tankId: "artillery",
		name: "Dune Howitzer",
		description: "Tan desert camouflage with matte olive siege barrel.",
		scrapCost: 45,
		customization: {
			primaryColor: "#A88E68",
			secondaryColor: "#756044",
			turretColor: "#BEA37A",
			barrelColor: "#3E4F30",
			decalId: "iron_crosshair",
			decalPosition: "turret_top",
			decalColor: "#161815",
			presetId: "artillery_dune_howitzer"
		}
	},
	{
		id: "artillery_crimson_battery",
		tankId: "artillery",
		name: "Crimson Battery",
		description: "Deep red artillery division hull with gold Unit 42 stencil.",
		scrapCost: 65,
		customization: {
			primaryColor: "#7F2B2B",
			secondaryColor: "#4F1818",
			turretColor: "#9C3636",
			barrelColor: "#26292E",
			decalId: "num_42",
			decalPosition: "hull_rear",
			decalColor: "#FACC15",
			presetId: "artillery_crimson_battery"
		}
	},
	{
		id: "artillery_steel_tempest",
		tankId: "artillery",
		name: "Steel Tempest",
		description: "Cool titanium slate hull with amber command star.",
		scrapCost: 85,
		customization: {
			primaryColor: "#4B5563",
			secondaryColor: "#2D343E",
			turretColor: "#667385",
			barrelColor: "#1E232A",
			decalId: "command_star",
			decalPosition: "turret_top",
			decalColor: "#E08E26",
			presetId: "artillery_steel_tempest"
		}
	},
	{
		id: "tesla_arc_overload",
		tankId: "tesla",
		name: "Arc Overload",
		description: "Deep cobalt coil housing with high-voltage cyan bolt.",
		scrapCost: 45,
		customization: {
			primaryColor: "#224966",
			secondaryColor: "#152E42",
			turretColor: "#31658C",
			barrelColor: "#1F3A52",
			decalId: "thunder_bolt",
			decalPosition: "turret_top",
			decalColor: "#38BDF8",
			presetId: "tesla_arc_overload"
		}
	},
	{
		id: "tesla_copper_coil",
		tankId: "tesla",
		name: "Copper Coil",
		description: "Obsidian frame with warm bronze-copper induction barrel.",
		scrapCost: 65,
		customization: {
			primaryColor: "#2B2F36",
			secondaryColor: "#1B1E24",
			turretColor: "#404552",
			barrelColor: "#B86B2B",
			decalId: "hex_core",
			decalPosition: "hull_front",
			decalColor: "#FACC15",
			presetId: "tesla_copper_coil"
		}
	},
	{
		id: "tesla_cryo_surge",
		tankId: "tesla",
		name: "Cryo Surge",
		description: "Glacier frost chassis with emerald capacitor core mark.",
		scrapCost: 85,
		customization: {
			primaryColor: "#B8C7D6",
			secondaryColor: "#6E8296",
			turretColor: "#DCE6F0",
			barrelColor: "#2E5A6B",
			decalId: "apex_diamond",
			decalPosition: "turret_top",
			decalColor: "#38BDF8",
			presetId: "tesla_cryo_surge"
		}
	},
	{
		id: "phantom_void_stalker",
		tankId: "phantom",
		name: "Void Stalker",
		description: "Obsidian stealth facets with violet diamond insignia.",
		scrapCost: 45,
		customization: {
			primaryColor: "#25232E",
			secondaryColor: "#16151C",
			turretColor: "#363245",
			barrelColor: "#1E1B26",
			decalId: "apex_diamond",
			decalPosition: "hull_front",
			decalColor: "#C084FC",
			presetId: "phantom_void_stalker"
		}
	},
	{
		id: "phantom_crimson_wraith",
		tankId: "phantom",
		name: "Crimson Wraith",
		description: "Dark maroon stealth hull crowned with gold Unit 99.",
		scrapCost: 65,
		customization: {
			primaryColor: "#4A222D",
			secondaryColor: "#2E141B",
			turretColor: "#662F3E",
			barrelColor: "#1D181B",
			decalId: "num_99",
			decalPosition: "turret_top",
			decalColor: "#FACC15",
			presetId: "phantom_crimson_wraith"
		}
	},
	{
		id: "phantom_emerald_specter",
		tankId: "phantom",
		name: "Emerald Specter",
		description: "Deep jungle shadow armor with bright lime ace crown.",
		scrapCost: 85,
		customization: {
			primaryColor: "#214A37",
			secondaryColor: "#153023",
			turretColor: "#2E6B4E",
			barrelColor: "#18241E",
			decalId: "apex_crown",
			decalPosition: "turret_top",
			decalColor: "#4ADE80",
			presetId: "phantom_emerald_specter"
		}
	}
];
var TANK_PRESET_MAP = Object.fromEntries(TANK_COSMETIC_PRESETS.map((p) => [p.id, p]));
function getTankPresets(tankId) {
	return TANK_COSMETIC_PRESETS.filter((p) => p.tankId === tankId);
}
function getPaintColorCost(hex) {
	const upper = hex.trim().toUpperCase();
	const paintMatch = PAINT_COLOR_SWATCHES.find((s) => s.hex.toUpperCase() === upper);
	if (paintMatch) return paintMatch.scrapCost;
	const decalMatch = DECAL_COLOR_SWATCHES.find((s) => s.hex.toUpperCase() === upper);
	if (decalMatch) return decalMatch.scrapCost;
	return 0;
}
function getDecalCost(decalId) {
	return TANK_DECAL_MAP[decalId]?.scrapCost ?? 0;
}
var HEX_COLOR_RE = /^#[0-9a-fA-F]{6}$/;
function normalizeHexColor(value, fallback) {
	if (typeof value === "string" && HEX_COLOR_RE.test(value.trim())) return value.trim().toUpperCase();
	return fallback.toUpperCase();
}
function createDefaultTankCustomization(tank, cosmeticId = "default") {
	const visual = getEffectiveTankVisual(tank, cosmeticId);
	return {
		primaryColor: normalizeHexColor(visual.hullPrimary, tank.visual.hullPrimary),
		secondaryColor: normalizeHexColor(visual.hullSecondary, tank.visual.hullSecondary),
		turretColor: normalizeHexColor(visual.turretColor, tank.visual.turretColor),
		barrelColor: normalizeHexColor(visual.barrelColor ?? visual.hullSecondary, tank.visual.hullSecondary),
		decalId: "none",
		decalPosition: "turret_top",
		decalColor: normalizeHexColor(visual.accentColor, "#F3EFE6"),
		presetId: null
	};
}
function resolveEffectiveTankVisual(tank, cosmeticId = "default", customization) {
	const base = getEffectiveTankVisual(tank, cosmeticId);
	if (!customization) return {
		...base,
		barrelColor: base.barrelColor ?? base.hullSecondary
	};
	return {
		...base,
		hullPrimary: normalizeHexColor(customization.primaryColor, base.hullPrimary),
		hullSecondary: normalizeHexColor(customization.secondaryColor, base.hullSecondary),
		turretColor: normalizeHexColor(customization.turretColor, base.turretColor),
		barrelColor: normalizeHexColor(customization.barrelColor, base.barrelColor ?? base.hullSecondary)
	};
}
function areCustomizationsEqual(a, b) {
	if (!a && !b) return true;
	if (!a || !b) return false;
	return normalizeHexColor(a.primaryColor, "#000000") === normalizeHexColor(b.primaryColor, "#000000") && normalizeHexColor(a.secondaryColor, "#000000") === normalizeHexColor(b.secondaryColor, "#000000") && normalizeHexColor(a.turretColor, "#000000") === normalizeHexColor(b.turretColor, "#000000") && normalizeHexColor(a.barrelColor, "#000000") === normalizeHexColor(b.barrelColor, "#000000") && a.decalId === b.decalId && a.decalPosition === b.decalPosition && normalizeHexColor(a.decalColor, "#000000") === normalizeHexColor(b.decalColor, "#000000");
}
function getCustomizationSignature(tankId, cosmeticId = "default", customization) {
	if (!customization) return `${tankId}_${cosmeticId}`;
	const raw = [
		tankId,
		cosmeticId,
		normalizeHexColor(customization.primaryColor, ""),
		normalizeHexColor(customization.secondaryColor, ""),
		normalizeHexColor(customization.turretColor, ""),
		normalizeHexColor(customization.barrelColor, ""),
		customization.decalId,
		customization.decalPosition,
		normalizeHexColor(customization.decalColor, "")
	].join("|");
	let h = 2166136261;
	for (let i = 0; i < raw.length; i++) {
		h ^= raw.charCodeAt(i);
		h = Math.imul(h, 16777619);
	}
	return `${tankId}_c_${(h >>> 0).toString(36)}`;
}
// src/data/tanks.ts
var TANK_DEFINITIONS = {
	assault: {
		id: "assault",
		name: "Assault Tank",
		role: "Balanced",
		description: "Versatile frontline battle tank with dependable armor, crisp handling, moderate magazine capacity, and reliable reload pacing.",
		implemented: true,
		unlockCost: 0,
		isStarter: true,
		stats: {
			maxHp: 170,
			moveSpeed: 215,
			acceleration: 980,
			turnSpeed: 7.5,
			reloadSec: .58,
			magazineCapacity: 12,
			reloadDurationSec: 2.5,
			projectileDamage: 20,
			projectileSpeed: 560,
			projectileRange: 540,
			projectileRadius: 6,
			bodyRadius: 23,
			detectionMultiplier: 1
		},
		ratings: {
			armor: 6,
			firepower: 7,
			mobility: 7,
			range: 6
		},
		activeAbility: {
			id: "rapid_fire",
			name: "Rapid Fire",
			description: "Doubles firing speed for 4 seconds without bypassing magazine capacity.",
			cooldownSec: 11,
			durationSec: 4,
			fireRateMultiplier: 2
		},
		passiveAbility: {
			id: "efficient_reload",
			name: "Efficient Reload",
			description: "Reduces magazine reload duration by 25% for both automatic and manual reloads.",
			reloadDurationMultiplier: .75
		},
		visual: {
			hullPrimary: "#5B7048",
			hullSecondary: "#3E4F30",
			turretColor: "#708A59",
			accentColor: "#E08E26",
			treadColor: "#242722",
			silhouette: "balanced"
		}
	},
	fortress: {
		id: "fortress",
		name: "Fortress Tank",
		role: "Heavy Defensive Tank",
		description: "Thick composite plating and a heavy-caliber cannon built to anchor choke points and absorb incoming fire.",
		implemented: true,
		unlockCost: 130,
		isStarter: false,
		stats: {
			maxHp: 160,
			moveSpeed: 168,
			acceleration: 740,
			turnSpeed: 5.5,
			reloadSec: .82,
			magazineCapacity: 16,
			reloadDurationSec: 4,
			projectileDamage: 24,
			projectileSpeed: 510,
			projectileRange: 490,
			projectileRadius: 8,
			bodyRadius: 26,
			detectionMultiplier: 1.05
		},
		ratings: {
			armor: 10,
			firepower: 8,
			mobility: 4,
			range: 5
		},
		activeAbility: {
			id: "fortress_shield",
			name: "Fortress Shield",
			description: "Deploys an 80 HP protective barrier around the hull for 5 seconds to absorb incoming projectile damage.",
			cooldownSec: 13,
			durationSec: 5,
			shieldAmount: 80
		},
		passiveAbility: {
			id: "reinforced_armor",
			name: "Reinforced Armor",
			description: "Heavy layered hull plating increases maximum health by 50% (160 to 240 HP).",
			maxHpMultiplier: 1.5
		},
		visual: {
			hullPrimary: "#4B5563",
			hullSecondary: "#333B46",
			turretColor: "#647082",
			accentColor: "#38BDF8",
			treadColor: "#1E2228",
			silhouette: "heavy"
		}
	},
	scout: {
		id: "scout",
		name: "Scout Tank",
		role: "High-mobility tank",
		description: "Stripped-down recon chassis built for fast movement, quick repositioning, and hit-and-run combat.",
		implemented: true,
		unlockCost: 90,
		isStarter: false,
		stats: {
			maxHp: 135,
			moveSpeed: 216,
			acceleration: 1300,
			turnSpeed: 10.5,
			reloadSec: .56,
			magazineCapacity: 8,
			reloadDurationSec: 1.5,
			projectileDamage: 17,
			projectileSpeed: 600,
			projectileRange: 470,
			projectileRadius: 5,
			bodyRadius: 20,
			detectionMultiplier: .95
		},
		ratings: {
			armor: 4,
			firepower: 5,
			mobility: 10,
			range: 5
		},
		activeAbility: {
			id: "afterburner",
			name: "Afterburner",
			description: "Turbine surge grants +45% movement speed for 3.5 seconds, stacking additively with Lightweight Chassis.",
			cooldownSec: 10,
			durationSec: 3.5,
			speedBoostMultiplier: 1.45
		},
		passiveAbility: {
			id: "lightweight_chassis",
			name: "Lightweight Chassis",
			description: "Compact frame increases movement speed by 25% (216 to 270) without altering turret aim.",
			moveSpeedMultiplier: 1.25
		},
		visual: {
			hullPrimary: "#B86B2B",
			hullSecondary: "#8A4E1D",
			turretColor: "#D4823A",
			accentColor: "#FACC15",
			treadColor: "#26211D",
			silhouette: "sleek"
		}
	},
	artillery: {
		id: "artillery",
		name: "Artillery Tank",
		role: "Long-range specialist",
		description: "Long-barreled self-propelled siege cannon built to bombard distant targets with heavy shells and area barrages.",
		implemented: true,
		unlockCost: 170,
		isStarter: false,
		stats: {
			maxHp: 140,
			moveSpeed: 185,
			acceleration: 820,
			turnSpeed: 6.2,
			reloadSec: 1.05,
			magazineCapacity: 3,
			reloadDurationSec: 5,
			projectileDamage: 28,
			projectileSpeed: 680,
			projectileRange: 560,
			projectileRadius: 7,
			bodyRadius: 23,
			detectionMultiplier: 1
		},
		ratings: {
			armor: 5,
			firepower: 9,
			mobility: 5,
			range: 10
		},
		activeAbility: {
			id: "shell_barrage",
			name: "Shell Barrage",
			description: "Launches 4 arcing shells into the aimed target area with staggered impacts and warning rings (uses ability cooldown only).",
			cooldownSec: 14,
			durationSec: 2,
			barrageShellCount: 4,
			barrageImpactIntervalSec: .45,
			barrageFlightSec: .65,
			barrageAoERadius: 88,
			barrageShellDamage: 28,
			barrageScatterRadius: 68
		},
		passiveAbility: {
			id: "extended_range",
			name: "Extended Range",
			description: "Extended rifled siege barrel increases normal attack projectile range by 40% (560 to 784).",
			projectileRangeMultiplier: 1.4
		},
		visual: {
			hullPrimary: "#7C6245",
			hullSecondary: "#59442E",
			turretColor: "#967956",
			accentColor: "#EF4444",
			treadColor: "#25211C",
			silhouette: "long_barrel"
		}
	},
	tesla: {
		id: "tesla",
		name: "Tesla Tank",
		role: "Electric control specialist",
		description: "Arc-capacitor battle tank that uses electric projectiles and EMP area disruption to control enemy movement.",
		implemented: true,
		unlockCost: 210,
		isStarter: false,
		stats: {
			maxHp: 155,
			moveSpeed: 210,
			acceleration: 950,
			turnSpeed: 7.5,
			reloadSec: .68,
			magazineCapacity: 10,
			reloadDurationSec: 3,
			projectileDamage: 19,
			projectileSpeed: 580,
			projectileRange: 510,
			projectileRadius: 7,
			bodyRadius: 23,
			detectionMultiplier: 1
		},
		ratings: {
			armor: 6,
			firepower: 7,
			mobility: 7,
			range: 6
		},
		activeAbility: {
			id: "emp_pulse",
			name: "EMP Pulse",
			description: "Releases a 220px electric shockwave around the hull, slowing nearby enemies by 45% for 2.5s and interrupting active movement abilities.",
			cooldownSec: 12,
			durationSec: 0,
			empRadius: 220,
			empSlowStrength: .45,
			empSlowDurationSec: 2.5,
			empDamage: 16
		},
		passiveAbility: {
			id: "static_charge",
			name: "Static Charge",
			description: "Normal electric attacks apply Static Charge, slowing hit opponents by 25% for 1.8 seconds (reapplying refreshes duration without stacking).",
			slowStrength: .25,
			slowDurationSec: 1.8
		},
		visual: {
			hullPrimary: "#2E5A6B",
			hullSecondary: "#1D3C48",
			turretColor: "#3C758C",
			accentColor: "#22D3EE",
			treadColor: "#1B2428",
			silhouette: "coil"
		}
	},
	phantom: {
		id: "phantom",
		name: "Phantom Tank",
		role: "Evasion specialist",
		description: "Low-profile stealth tank that reduces enemy attention, temporarily phases out of danger, and repositions rapidly.",
		implemented: true,
		unlockCost: 250,
		isStarter: false,
		stats: {
			maxHp: 135,
			moveSpeed: 242,
			acceleration: 1150,
			turnSpeed: 9.2,
			reloadSec: .64,
			magazineCapacity: 6,
			reloadDurationSec: 2,
			projectileDamage: 19,
			projectileSpeed: 610,
			projectileRange: 530,
			projectileRadius: 5,
			bodyRadius: 21,
			detectionMultiplier: .72
		},
		ratings: {
			armor: 4,
			firepower: 7,
			mobility: 9,
			range: 7
		},
		activeAbility: {
			id: "phase_shift",
			name: "Phase Shift",
			description: "Enters a translucent phased state for 3.0s, reducing incoming damage by 50% and gaining +35% speed to reposition without bypassing obstacles.",
			cooldownSec: 13,
			durationSec: 3,
			speedBoostMultiplier: 1.35,
			phaseDamageMultiplier: .5
		},
		passiveAbility: {
			id: "ghost_protocol",
			name: "Ghost Protocol",
			description: "Low-signature stealth baffles reduce AI opponent detection range by 28% unless Phantom closes in or attacks.",
			detectionMultiplier: .72
		},
		visual: {
			hullPrimary: "#4B435E",
			hullSecondary: "#342E43",
			turretColor: "#63587D",
			accentColor: "#A78BFA",
			treadColor: "#1E1B24",
			silhouette: "angular"
		}
	}
};
var TANK_LIST = [
	TANK_DEFINITIONS.assault,
	TANK_DEFINITIONS.fortress,
	TANK_DEFINITIONS.scout,
	TANK_DEFINITIONS.artillery,
	TANK_DEFINITIONS.tesla,
	TANK_DEFINITIONS.phantom
];
function getEffectiveTankMaxHp(definition) {
	const mult = definition.passiveAbility.maxHpMultiplier ?? 1;
	return Math.round(definition.stats.maxHp * mult);
}
function getEffectiveTankReloadSec(definition) {
	const mult = definition.passiveAbility.reloadDurationMultiplier ?? 1;
	return Math.max(.25, Number((definition.stats.reloadDurationSec * mult).toFixed(3)));
}
function getEffectiveTankMoveSpeed(definition) {
	const mult = definition.passiveAbility.moveSpeedMultiplier ?? 1;
	return Math.round(definition.stats.moveSpeed * mult);
}
function getEffectiveTankProjectileRange(definition) {
	const mult = definition.passiveAbility.projectileRangeMultiplier ?? 1;
	return Math.round(definition.stats.projectileRange * mult);
}
// src/data/economy.ts
function failPurchase(progression, reason, cost = 0) {
	return {
		success: false,
		reason,
		cost,
		remainingScrap: Math.max(0, Math.floor(progression.scrap)),
		nextProgression: progression
	};
}
function getSafeScrap(progression) {
	return Math.max(0, Math.floor(progression.scrap));
}
function getSafeScrapSpent(progression) {
	return Math.max(0, Math.floor(progression.totalScrapSpent ?? 0));
}
function isTankUnlocked(progression, tankId) {
	const def = TANK_DEFINITIONS[tankId];
	if (!def || !def.implemented) return false;
	return def.isStarter || progression.unlockedTanks.includes(tankId);
}
function isDecalUnlocked(progression, decalId) {
	const def = TANK_DECAL_MAP[decalId];
	if (!def) return false;
	if ((def.scrapCost ?? 0) <= 0) return true;
	if (STARTER_DECAL_IDS.includes(decalId)) return true;
	if (progression.unlockedDecals.includes(decalId)) return true;
	for (const presetId of progression.unlockedPresets) if (TANK_PRESET_MAP[presetId]?.customization.decalId === decalId) return true;
	return false;
}
function isPresetUnlocked(progression, presetId) {
	const preset = TANK_PRESET_MAP[presetId];
	if (!preset) return false;
	if ((preset.scrapCost ?? 0) <= 0) return true;
	return progression.unlockedPresets.includes(presetId);
}
function isSpecialCosmeticUnlocked(progression, cosmeticId) {
	if (cosmeticId === "default") return true;
	return progression.unlockedCosmetics.includes(cosmeticId);
}
function isPaintColorUnlocked(progression, rawHex, tank) {
	const hex = normalizeHexColor(rawHex, "#000000");
	if (STARTER_PAINT_COLORS.includes(hex)) return true;
	if (progression.unlockedPaintColors.some((c) => c.toUpperCase() === hex)) return true;
	if (tank) {
		const def = createDefaultTankCustomization(tank, progression.equippedCosmetic);
		if (def.primaryColor === hex || def.secondaryColor === hex || def.turretColor === hex || def.barrelColor === hex || def.decalColor === hex) return true;
	}
	for (const presetId of progression.unlockedPresets) {
		const c = TANK_PRESET_MAP[presetId]?.customization;
		if (c && (c.primaryColor.toUpperCase() === hex || c.secondaryColor.toUpperCase() === hex || c.turretColor.toUpperCase() === hex || c.barrelColor.toUpperCase() === hex || c.decalColor.toUpperCase() === hex)) return true;
	}
	if (PAINT_COLOR_SWATCHES.some((s) => s.hex.toUpperCase() === hex && s.scrapCost > 0) || DECAL_COLOR_SWATCHES.some((s) => s.hex.toUpperCase() === hex && s.scrapCost > 0)) return false;
	return progression.customPaintUnlocked;
}
function getLockedItemsInCustomization(progression, tank, draft) {
	const locked = [];
	if (draft.presetId && !isPresetUnlocked(progression, draft.presetId)) {
		const preset = TANK_PRESET_MAP[draft.presetId];
		if (preset) {
			locked.push(`${preset.name} (${preset.scrapCost ?? 0} Scrap)`);
			return locked;
		}
	}
	const zones = [
		["Primary paint", draft.primaryColor],
		["Secondary paint", draft.secondaryColor],
		["Turret paint", draft.turretColor],
		["Barrel paint", draft.barrelColor],
		["Decal color", draft.decalColor]
	];
	for (const [label, hex] of zones) if (!isPaintColorUnlocked(progression, hex, tank)) {
		const cost = getPaintColorCost(hex);
		locked.push(cost > 0 ? `${label} (${cost} Scrap)` : `${label} (Custom Studio)`);
	}
	if (!isDecalUnlocked(progression, draft.decalId)) {
		const decal = TANK_DECAL_MAP[draft.decalId];
		locked.push(`${decal?.name ?? draft.decalId} (${getDecalCost(draft.decalId)} Scrap)`);
	}
	return locked;
}
/**
* Purchases an unowned combat tank with Scrap.
* Prevents duplicate purchases, negative Scrap, and preserves existing unlocked tanks.
*/
function purchaseTankWithScrap(progression, tankId) {
	const def = TANK_DEFINITIONS[tankId];
	if (!def || !def.implemented) return failPurchase(progression, "not_found");
	if (isTankUnlocked(progression, tankId)) return failPurchase(progression, "already_unlocked", 0);
	const cost = Math.max(0, Math.floor(def.unlockCost));
	const currentScrap = getSafeScrap(progression);
	if (currentScrap < cost) return failPurchase(progression, "insufficient_scrap", cost);
	const nextScrap = currentScrap - cost;
	const unlockedTanks = Array.from(/* @__PURE__ */ new Set([...progression.unlockedTanks, tankId]));
	return {
		success: true,
		reason: "purchased",
		cost,
		remainingScrap: nextScrap,
		nextProgression: {
			...progression,
			scrap: nextScrap,
			totalScrapSpent: getSafeScrapSpent(progression) + cost,
			unlockedTanks
		}
	};
}
/**
* Purchases a paint swatch or decal color with Scrap.
*/
function purchasePaintColorWithScrap(progression, rawHex) {
	const hex = normalizeHexColor(rawHex, "");
	if (!hex) return failPurchase(progression, "not_found");
	const swatch = PAINT_COLOR_SWATCHES.find((s) => s.hex.toUpperCase() === hex) ?? DECAL_COLOR_SWATCHES.find((s) => s.hex.toUpperCase() === hex);
	if (!swatch) return failPurchase(progression, "not_found");
	if (swatch.scrapCost <= 0 || progression.unlockedPaintColors.some((c) => c.toUpperCase() === hex)) return failPurchase(progression, "already_unlocked", 0);
	const cost = Math.max(0, Math.floor(swatch.scrapCost));
	const currentScrap = getSafeScrap(progression);
	if (currentScrap < cost) return failPurchase(progression, "insufficient_scrap", cost);
	const nextScrap = currentScrap - cost;
	const nextColors = Array.from(/* @__PURE__ */ new Set([...progression.unlockedPaintColors.map((c) => c.toUpperCase()), hex]));
	return {
		success: true,
		reason: "purchased",
		cost,
		remainingScrap: nextScrap,
		nextProgression: {
			...progression,
			scrap: nextScrap,
			totalScrapSpent: getSafeScrapSpent(progression) + cost,
			unlockedPaintColors: nextColors
		}
	};
}
/**
* Unlocks the full Custom Paint Studio hex picker with Scrap.
*/
function purchaseCustomPaintStudioWithScrap(progression) {
	if (progression.customPaintUnlocked) return failPurchase(progression, "already_unlocked", 0);
	const cost = 60;
	const currentScrap = getSafeScrap(progression);
	if (currentScrap < cost) return failPurchase(progression, "insufficient_scrap", cost);
	const nextScrap = currentScrap - cost;
	return {
		success: true,
		reason: "purchased",
		cost,
		remainingScrap: nextScrap,
		nextProgression: {
			...progression,
			scrap: nextScrap,
			totalScrapSpent: getSafeScrapSpent(progression) + cost,
			customPaintUnlocked: true
		}
	};
}
/**
* Purchases a tank decal permanently with Scrap.
*/
function purchaseDecalWithScrap(progression, decalId) {
	const decal = TANK_DECAL_MAP[decalId];
	if (!decal) return failPurchase(progression, "not_found");
	if ((decal.scrapCost ?? 0) <= 0 || progression.unlockedDecals.includes(decalId)) return failPurchase(progression, "already_unlocked", 0);
	const cost = Math.max(0, Math.floor(decal.scrapCost ?? 0));
	const currentScrap = getSafeScrap(progression);
	if (currentScrap < cost) return failPurchase(progression, "insufficient_scrap", cost);
	const nextScrap = currentScrap - cost;
	return {
		success: true,
		reason: "purchased",
		cost,
		remainingScrap: nextScrap,
		nextProgression: {
			...progression,
			scrap: nextScrap,
			totalScrapSpent: getSafeScrapSpent(progression) + cost,
			unlockedDecals: Array.from(/* @__PURE__ */ new Set([...progression.unlockedDecals, decalId]))
		}
	};
}
/**
* Purchases a tank cosmetic preset permanently with Scrap (and unlocks its colors & decal).
*/
function purchasePresetWithScrap(progression, presetId) {
	const preset = TANK_PRESET_MAP[presetId];
	if (!preset) return failPurchase(progression, "not_found");
	if ((preset.scrapCost ?? 0) <= 0 || progression.unlockedPresets.includes(presetId)) return failPurchase(progression, "already_unlocked", 0);
	const cost = Math.max(0, Math.floor(preset.scrapCost ?? 0));
	const currentScrap = getSafeScrap(progression);
	if (currentScrap < cost) return failPurchase(progression, "insufficient_scrap", cost);
	const nextScrap = currentScrap - cost;
	const nextPresets = Array.from(/* @__PURE__ */ new Set([...progression.unlockedPresets, presetId]));
	const nextDecals = Array.from(/* @__PURE__ */ new Set([...progression.unlockedDecals, preset.customization.decalId]));
	return {
		success: true,
		reason: "purchased",
		cost,
		remainingScrap: nextScrap,
		nextProgression: {
			...progression,
			scrap: nextScrap,
			totalScrapSpent: getSafeScrapSpent(progression) + cost,
			unlockedPresets: nextPresets,
			unlockedDecals: nextDecals
		}
	};
}
/**
* Purchases a Scrap-shop Special Appearance skin permanently.
*/
function purchaseSpecialCosmeticWithScrap(progression, cosmeticId) {
	const def = COSMETIC_DEFINITIONS[cosmeticId];
	if (!def) return failPurchase(progression, "not_found");
	if (isSpecialCosmeticUnlocked(progression, cosmeticId)) return failPurchase(progression, "already_unlocked", 0);
	if (!def.scrapCost || def.scrapCost <= 0) return failPurchase(progression, "not_purchasable", 0);
	const cost = Math.max(0, Math.floor(def.scrapCost));
	const currentScrap = getSafeScrap(progression);
	if (currentScrap < cost) return failPurchase(progression, "insufficient_scrap", cost);
	const nextScrap = currentScrap - cost;
	return {
		success: true,
		reason: "purchased",
		cost,
		remainingScrap: nextScrap,
		nextProgression: {
			...progression,
			scrap: nextScrap,
			totalScrapSpent: getSafeScrapSpent(progression) + cost,
			unlockedCosmetics: Array.from(/* @__PURE__ */ new Set([...progression.unlockedCosmetics, cosmeticId]))
		}
	};
}
/**
* Grants an optional rewarded-advertisement Scrap bonus idempotently.
* Never grants duplicate Scrap for the same grantId.
*/
function applyRewardedAdScrap(progression, grantId, amount = 35) {
	const cleanId = grantId.trim();
	const safeAmount = Math.max(0, Math.floor(amount));
	if (!cleanId || safeAmount <= 0) return {
		granted: false,
		amountAwarded: 0,
		nextProgression: progression
	};
	const processed = progression.processedRewardedAdIds ?? [];
	if (processed.includes(cleanId)) return {
		granted: false,
		amountAwarded: 0,
		nextProgression: progression
	};
	const nextScrap = getSafeScrap(progression) + safeAmount;
	const nextEarned = Math.max(nextScrap, Math.floor(progression.totalScrapEarned ?? 0) + safeAmount);
	const nextProcessed = [cleanId, ...processed].slice(0, 50);
	return {
		granted: true,
		amountAwarded: safeAmount,
		nextProgression: {
			...progression,
			scrap: nextScrap,
			totalScrapEarned: nextEarned,
			processedRewardedAdIds: nextProcessed
		}
	};
}
// src/data/missions.ts
var MISSION_RESET_CONFIG = {
	timezone: "Asia/Manila",
	dailyResetHour: 0,
	weeklyResetDayOfWeek: 1,
	weeklyResetHour: 0
};
var DAILY_MISSION_POOL = [
	{
		id: "daily_play_3",
		scope: "daily",
		title: "Frontline Duty",
		description: "Play 3 matches in any arena.",
		metric: "matches_played",
		target: 3,
		reward: {
			xp: 60,
			scrap: 40
		}
	},
	{
		id: "daily_win_1",
		scope: "daily",
		title: "First Victory",
		description: "Win 1 match as the last tank standing or highest HP.",
		metric: "wins",
		target: 1,
		reward: {
			xp: 90,
			scrap: 60
		}
	},
	{
		id: "daily_elims_5",
		scope: "daily",
		title: "Target Practice",
		description: "Eliminate 5 enemy tanks.",
		metric: "eliminations",
		target: 5,
		reward: {
			xp: 75,
			scrap: 50
		}
	},
	{
		id: "daily_powerups_5",
		scope: "daily",
		title: "Supply Runner",
		description: "Collect 5 battlefield power-ups.",
		metric: "powerups_collected",
		target: 5,
		reward: {
			xp: 65,
			scrap: 45
		}
	},
	{
		id: "daily_scout_2",
		scope: "daily",
		title: "Recon Patrol",
		description: "Play 2 matches using the Scout Tank.",
		metric: "tank_matches",
		target: 2,
		tankId: "scout",
		reward: {
			xp: 80,
			scrap: 55
		}
	},
	{
		id: "daily_abilities_10",
		scope: "daily",
		title: "Systems Overdrive",
		description: "Activate tank active abilities 10 times.",
		metric: "abilities_activated",
		target: 10,
		reward: {
			xp: 70,
			scrap: 45
		}
	},
	{
		id: "daily_industrial_1",
		scope: "daily",
		title: "Factory Raid",
		description: "Play a match in Industrial Zone.",
		metric: "arena_matches",
		target: 1,
		arenaId: "industrial_zone",
		reward: {
			xp: 65,
			scrap: 45
		}
	},
	{
		id: "daily_obstacles_10",
		scope: "daily",
		title: "Breach & Clear",
		description: "Destroy 10 destructible obstacles.",
		metric: "obstacles_destroyed",
		target: 10,
		reward: {
			xp: 70,
			scrap: 50
		}
	},
	{
		id: "daily_top3_2",
		scope: "daily",
		title: "Podium Finish",
		description: "Survive into the final 3 tanks in 2 matches.",
		metric: "top_three_finishes",
		target: 2,
		reward: {
			xp: 85,
			scrap: 60
		}
	},
	{
		id: "daily_fortress_2",
		scope: "daily",
		title: "Armor Bastion",
		description: "Play 2 matches using the Fortress Tank.",
		metric: "tank_matches",
		target: 2,
		tankId: "fortress",
		reward: {
			xp: 80,
			scrap: 55
		}
	}
];
var WEEKLY_MISSION_POOL = [
	{
		id: "weekly_play_15",
		scope: "weekly",
		title: "Campaign Deployment",
		description: "Complete 15 matches across any arenas.",
		metric: "matches_played",
		target: 15,
		reward: {
			xp: 260,
			scrap: 180
		}
	},
	{
		id: "weekly_win_5",
		scope: "weekly",
		title: "Arena Champion",
		description: "Win 5 matches.",
		metric: "wins",
		target: 5,
		reward: {
			xp: 350,
			scrap: 240
		}
	},
	{
		id: "weekly_elims_40",
		scope: "weekly",
		title: "Heavy Barrage",
		description: "Eliminate 40 enemy tanks.",
		metric: "eliminations",
		target: 40,
		reward: {
			xp: 320,
			scrap: 220
		}
	},
	{
		id: "weekly_powerups_25",
		scope: "weekly",
		title: "Field Logistics",
		description: "Collect 25 power-ups.",
		metric: "powerups_collected",
		target: 25,
		reward: {
			xp: 250,
			scrap: 170
		}
	},
	{
		id: "weekly_diff_tanks_5",
		scope: "weekly",
		title: "Versatile Commander",
		description: "Play matches using 5 different tanks.",
		metric: "unique_tanks_played",
		target: 5,
		reward: {
			xp: 300,
			scrap: 200
		}
	},
	{
		id: "weekly_wasteland_10",
		scope: "weekly",
		title: "Dune Warfare",
		description: "Complete 10 matches in Wasteland.",
		metric: "arena_matches",
		target: 10,
		arenaId: "wasteland",
		reward: {
			xp: 300,
			scrap: 210
		}
	},
	{
		id: "weekly_obstacles_50",
		scope: "weekly",
		title: "Siege Breaker",
		description: "Destroy 50 destructible obstacles.",
		metric: "obstacles_destroyed",
		target: 50,
		reward: {
			xp: 280,
			scrap: 190
		}
	}
];
var ACHIEVEMENT_DEFINITIONS = [
	{
		id: "ach_first_elim",
		category: "Combat",
		title: "First Elimination",
		description: "Get your first opponent elimination.",
		metric: "eliminations",
		target: 1,
		reward: {
			xp: 60,
			scrap: 0
		}
	},
	{
		id: "ach_sharpshooter",
		category: "Combat",
		title: "Sharpshooter",
		description: "Reach 50 total opponent eliminations.",
		metric: "eliminations",
		target: 50,
		reward: {
			xp: 180,
			scrap: 0,
			cosmeticId: "crimson_vanguard"
		}
	},
	{
		id: "ach_veteran_fighter",
		category: "Combat",
		title: "Veteran Fighter",
		description: "Reach 250 total opponent eliminations.",
		metric: "eliminations",
		target: 250,
		reward: {
			xp: 350,
			scrap: 0
		}
	},
	{
		id: "ach_dominator",
		category: "Combat",
		title: "Dominator",
		description: "Reach 500 total opponent eliminations.",
		metric: "eliminations",
		target: 500,
		reward: {
			xp: 600,
			scrap: 0,
			cosmeticId: "warlord_crimson"
		}
	},
	{
		id: "ach_survivor",
		category: "Survival",
		title: "Survivor",
		description: "Win your first arena match.",
		metric: "wins",
		target: 1,
		reward: {
			xp: 100,
			scrap: 0
		}
	},
	{
		id: "ach_last_tank",
		category: "Survival",
		title: "Last Tank Standing",
		description: "Win 10 arena matches.",
		metric: "wins",
		target: 10,
		reward: {
			xp: 250,
			scrap: 0,
			cosmeticId: "desert_phantom"
		}
	},
	{
		id: "ach_unstoppable",
		category: "Survival",
		title: "Unstoppable",
		description: "Win 50 arena matches.",
		metric: "wins",
		target: 50,
		reward: {
			xp: 550,
			scrap: 0
		}
	},
	{
		id: "ach_collector",
		category: "Collection",
		title: "Collector",
		description: "Collect 50 power-ups across matches.",
		metric: "powerups_collected",
		target: 50,
		reward: {
			xp: 180,
			scrap: 0
		}
	},
	{
		id: "ach_tank_enthusiast",
		category: "Collection",
		title: "Tank Enthusiast",
		description: "Play at least one match with each of the six tanks.",
		metric: "unique_tanks_played",
		target: 6,
		reward: {
			xp: 240,
			scrap: 0,
			cosmeticId: "emerald_squad"
		}
	},
	{
		id: "ach_arena_explorer",
		category: "Exploration",
		title: "Arena Explorer",
		description: "Play a match in all three arenas.",
		metric: "unique_arenas_played",
		target: 3,
		reward: {
			xp: 160,
			scrap: 0
		}
	},
	{
		id: "ach_demolition_expert",
		category: "Exploration",
		title: "Demolition Expert",
		description: "Destroy 100 destructible battlefield obstacles.",
		metric: "obstacles_destroyed",
		target: 100,
		reward: {
			xp: 220,
			scrap: 0,
			cosmeticId: "hazard_stripes"
		}
	}
];
var ALL_MISSION_DEFINITIONS = Object.fromEntries([...DAILY_MISSION_POOL, ...WEEKLY_MISSION_POOL].map((m) => [m.id, m]));
var ACHIEVEMENT_DEFINITION_MAP = Object.fromEntries(ACHIEVEMENT_DEFINITIONS.map((a) => [a.id, a]));
var WEEKDAY_MAP = {
	Sun: 0,
	Mon: 1,
	Tue: 2,
	Wed: 3,
	Thu: 4,
	Fri: 5,
	Sat: 6
};
function getZonedDateParts(nowMs, timezone = MISSION_RESET_CONFIG.timezone) {
	const parts = new Intl.DateTimeFormat("en-US", {
		timeZone: timezone,
		year: "numeric",
		month: "2-digit",
		day: "2-digit",
		hour: "2-digit",
		minute: "2-digit",
		second: "2-digit",
		hour12: false,
		weekday: "short"
	}).formatToParts(new Date(nowMs));
	const lookup = /* @__PURE__ */ new Map();
	for (const p of parts) lookup.set(p.type, p.value);
	const rawHour = Number(lookup.get("hour") ?? "0");
	const hour = rawHour === 24 ? 0 : rawHour;
	return {
		year: Number(lookup.get("year") ?? "2026"),
		month: Number(lookup.get("month") ?? "1"),
		day: Number(lookup.get("day") ?? "1"),
		hour,
		minute: Number(lookup.get("minute") ?? "0"),
		second: Number(lookup.get("second") ?? "0"),
		weekday: WEEKDAY_MAP[lookup.get("weekday") ?? "Mon"] ?? 1
	};
}
function formatUtcDateKey(utcDate) {
	return `${utcDate.getUTCFullYear()}-${String(utcDate.getUTCMonth() + 1).padStart(2, "0")}-${String(utcDate.getUTCDate()).padStart(2, "0")}`;
}
function getDailyPeriodKey(nowMs = Date.now(), config = MISSION_RESET_CONFIG) {
	const z = getZonedDateParts(nowMs, config.timezone);
	const shiftDay = z.hour < config.dailyResetHour ? 1 : 0;
	return formatUtcDateKey(new Date(Date.UTC(z.year, z.month - 1, z.day - shiftDay)));
}
function getWeeklyPeriodKey(nowMs = Date.now(), config = MISSION_RESET_CONFIG) {
	const z = getZonedDateParts(nowMs, config.timezone);
	let daysSinceReset = (z.weekday - config.weeklyResetDayOfWeek + 7) % 7;
	if (daysSinceReset === 0 && z.hour < config.weeklyResetHour) daysSinceReset = 7;
	return `W-${formatUtcDateKey(new Date(Date.UTC(z.year, z.month - 1, z.day - daysSinceReset)))}`;
}
/**
* Estimates remaining milliseconds until the next daily or weekly reset in the configured timezone.
*/
function getResetCountdowns(nowMs = Date.now(), config = MISSION_RESET_CONFIG) {
	const z = getZonedDateParts(nowMs, config.timezone);
	const secIntoDay = z.hour * 3600 + z.minute * 60 + z.second;
	let dailySecLeft = config.dailyResetHour * 3600 - secIntoDay;
	if (dailySecLeft <= 0) dailySecLeft += 86400;
	let daysUntilWeekly = (config.weeklyResetDayOfWeek - z.weekday + 7) % 7;
	const weeklyResetSecOfDay = config.weeklyResetHour * 3600;
	if (daysUntilWeekly === 0 && secIntoDay >= weeklyResetSecOfDay) daysUntilWeekly = 7;
	const weeklySecLeft = daysUntilWeekly * 86400 + (weeklyResetSecOfDay - secIntoDay);
	return {
		dailyMsLeft: Math.max(0, dailySecLeft * 1e3),
		weeklyMsLeft: Math.max(0, weeklySecLeft * 1e3)
	};
}
function formatCountdownDuration(ms) {
	const totalMinutes = Math.max(1, Math.ceil(ms / 6e4));
	const days = Math.floor(totalMinutes / 1440);
	const hours = Math.floor(totalMinutes % 1440 / 60);
	const mins = totalMinutes % 60;
	if (days > 0) return `${days}d ${hours}h`;
	if (hours > 0) return `${hours}h ${mins}m`;
	return `${mins}m`;
}
function hashSeed(input) {
	let h = 2166136261;
	for (let i = 0; i < input.length; i++) {
		h ^= input.charCodeAt(i);
		h = Math.imul(h, 16777619);
	}
	return h >>> 0;
}
/**
* Selects `count` varied missions deterministically for a given period key.
* Prefers distinct metrics across the selected missions and avoids repeating `avoidIds`.
*/
function selectMissionsForPeriod(periodKey, pool, count = 3, avoidIds = []) {
	if (pool.length <= count) return [...pool];
	const avoidSet = new Set(avoidIds);
	const scored = pool.map((mission) => ({
		mission,
		sortKey: hashSeed(`${periodKey}:${mission.id}`)
	}));
	scored.sort((a, b) => a.sortKey - b.sortKey);
	const chosen = [];
	const usedMetrics = /* @__PURE__ */ new Set();
	for (const item of scored) {
		if (chosen.length >= count) break;
		if (avoidSet.has(item.mission.id)) continue;
		if (usedMetrics.has(item.mission.metric)) continue;
		chosen.push(item.mission);
		usedMetrics.add(item.mission.metric);
	}
	for (const item of scored) {
		if (chosen.length >= count) break;
		if (chosen.some((m) => m.id === item.mission.id)) continue;
		if (usedMetrics.has(item.mission.metric)) continue;
		chosen.push(item.mission);
		usedMetrics.add(item.mission.metric);
	}
	for (const item of scored) {
		if (chosen.length >= count) break;
		if (chosen.some((m) => m.id === item.mission.id)) continue;
		chosen.push(item.mission);
	}
	return chosen;
}
function toInitialMissionProgress(missions) {
	return missions.map((m) => ({
		missionId: m.id,
		progress: 0,
		completed: false,
		claimed: false,
		claimedAtMs: null
	}));
}
function createEmptyPeriodTracking() {
	return {
		uniqueTanks: [],
		uniqueArenas: []
	};
}
function createEmptyPermanentTracking() {
	return {
		matchesStarted: 0,
		matchesCompleted: 0,
		wins: 0,
		eliminations: 0,
		powerupsCollected: 0,
		abilitiesActivated: 0,
		obstaclesDestroyed: 0,
		uniqueTanks: [],
		uniqueArenas: []
	};
}
function createInitialAchievementsRecord(defs = ACHIEVEMENT_DEFINITIONS, seedProgression) {
	const record = {};
	const seedElims = Math.max(0, seedProgression?.totalEliminations ?? 0);
	const seedWins = Math.max(0, seedProgression?.wins ?? 0);
	for (const def of defs) {
		let initialProgress = 0;
		if (def.metric === "eliminations") initialProgress = Math.min(def.target, seedElims);
		else if (def.metric === "wins") initialProgress = Math.min(def.target, seedWins);
		const completed = initialProgress >= def.target;
		record[def.id] = {
			achievementId: def.id,
			progress: initialProgress,
			completed,
			unlockedAtMs: completed ? Date.now() : null,
			claimed: false,
			claimedAtMs: null
		};
	}
	return record;
}
function createInitialMissionsState(nowMs = Date.now(), options = {}, seedProgression) {
	const resetConfig = options.resetConfig ?? MISSION_RESET_CONFIG;
	const dailyPool = options.dailyPool ?? DAILY_MISSION_POOL;
	const weeklyPool = options.weeklyPool ?? WEEKLY_MISSION_POOL;
	const dailyCount = options.dailyCount ?? 3;
	const weeklyCount = options.weeklyCount ?? 3;
	const achDefs = options.achievements ?? ACHIEVEMENT_DEFINITIONS;
	const dailyPeriodKey = getDailyPeriodKey(nowMs, resetConfig);
	const weeklyPeriodKey = getWeeklyPeriodKey(nowMs, resetConfig);
	const selectedDaily = selectMissionsForPeriod(dailyPeriodKey, dailyPool, dailyCount);
	const selectedWeekly = selectMissionsForPeriod(weeklyPeriodKey, weeklyPool, weeklyCount);
	const permanentTracking = createEmptyPermanentTracking();
	if (seedProgression) {
		permanentTracking.eliminations = Math.max(0, seedProgression.totalEliminations ?? 0);
		permanentTracking.wins = Math.max(0, seedProgression.wins ?? 0);
		permanentTracking.matchesCompleted = Math.max(0, seedProgression.matchesPlayed ?? 0);
	}
	return {
		saveVersion: 1,
		dailyPeriodKey,
		dailyMissions: toInitialMissionProgress(selectedDaily),
		dailyTracking: createEmptyPeriodTracking(),
		weeklyPeriodKey,
		weeklyMissions: toInitialMissionProgress(selectedWeekly),
		weeklyTracking: createEmptyPeriodTracking(),
		achievements: createInitialAchievementsRecord(achDefs, seedProgression),
		permanentTracking,
		processedEventIds: []
	};
}
/**
* Checks daily and weekly reset boundaries in the configured timezone.
* Resets only the expired period(s); never resets permanent achievements.
*/
function ensureMissionPeriodsCurrent(state, nowMs = Date.now(), options = {}) {
	const resetConfig = options.resetConfig ?? MISSION_RESET_CONFIG;
	const dailyPool = options.dailyPool ?? DAILY_MISSION_POOL;
	const weeklyPool = options.weeklyPool ?? WEEKLY_MISSION_POOL;
	const dailyCount = options.dailyCount ?? 3;
	const weeklyCount = options.weeklyCount ?? 3;
	const achDefs = options.achievements ?? ACHIEVEMENT_DEFINITIONS;
	const currentDailyKey = getDailyPeriodKey(nowMs, resetConfig);
	const currentWeeklyKey = getWeeklyPeriodKey(nowMs, resetConfig);
	let next = state;
	let dailyReset = false;
	let weeklyReset = false;
	if (state.dailyPeriodKey !== currentDailyKey) {
		const freshDaily = selectMissionsForPeriod(currentDailyKey, dailyPool, dailyCount, state.dailyMissions.map((m) => m.missionId));
		next = {
			...next,
			dailyPeriodKey: currentDailyKey,
			dailyMissions: toInitialMissionProgress(freshDaily),
			dailyTracking: createEmptyPeriodTracking()
		};
		dailyReset = true;
	}
	if (state.weeklyPeriodKey !== currentWeeklyKey) {
		const freshWeekly = selectMissionsForPeriod(currentWeeklyKey, weeklyPool, weeklyCount, state.weeklyMissions.map((m) => m.missionId));
		next = {
			...next,
			weeklyPeriodKey: currentWeeklyKey,
			weeklyMissions: toInitialMissionProgress(freshWeekly),
			weeklyTracking: createEmptyPeriodTracking()
		};
		weeklyReset = true;
	}
	let achMap = next.achievements;
	let achChanged = false;
	for (const def of achDefs) if (!achMap[def.id]) {
		if (!achChanged) {
			achMap = { ...achMap };
			achChanged = true;
		}
		achMap[def.id] = {
			achievementId: def.id,
			progress: 0,
			completed: false,
			unlockedAtMs: null,
			claimed: false,
			claimedAtMs: null
		};
	}
	if (achChanged) next = {
		...next,
		achievements: achMap
	};
	return {
		state: next,
		dailyReset,
		weeklyReset
	};
}
function resolveMissionDefinition(missionId, options) {
	if (options.dailyPool) {
		const found = options.dailyPool.find((m) => m.id === missionId);
		if (found) return found;
	}
	if (options.weeklyPool) {
		const found = options.weeklyPool.find((m) => m.id === missionId);
		if (found) return found;
	}
	return ALL_MISSION_DEFINITIONS[missionId];
}
function advanceMissionList(entries, tracking, event, options) {
	return entries.map((entry) => {
		const def = resolveMissionDefinition(entry.missionId, options);
		if (!def || entry.completed) return entry;
		let nextProgress = entry.progress;
		switch (event.type) {
			case "match_completed":
				if (def.metric === "matches_played") nextProgress += 1;
				else if (def.metric === "tank_matches" && def.tankId === event.tankId) nextProgress += 1;
				else if (def.metric === "arena_matches" && def.arenaId === event.arenaId) nextProgress += 1;
				else if (def.metric === "top_three_finishes" && event.placement <= 3) nextProgress += 1;
				else if (def.metric === "unique_tanks_played") nextProgress = tracking.uniqueTanks.length;
				else if (def.metric === "unique_arenas_played") nextProgress = tracking.uniqueArenas.length;
				break;
			case "match_victory":
				if (def.metric === "wins") nextProgress += 1;
				break;
			case "tank_elimination":
				if (def.metric === "eliminations") nextProgress += 1;
				break;
			case "powerup_collected":
				if (def.metric === "powerups_collected") nextProgress += 1;
				break;
			case "ability_activated":
				if (def.metric === "abilities_activated") nextProgress += 1;
				break;
			case "obstacle_destroyed": if (def.metric === "obstacles_destroyed") nextProgress += 1;
		}
		const clamped = Math.min(def.target, Math.max(0, nextProgress));
		if (clamped === entry.progress) return entry;
		return {
			...entry,
			progress: clamped,
			completed: clamped >= def.target
		};
	});
}
function updatePeriodTracking(tracking, event) {
	if (event.type !== "match_completed") return tracking;
	const nextTanks = tracking.uniqueTanks.includes(event.tankId) ? tracking.uniqueTanks : [...tracking.uniqueTanks, event.tankId];
	const nextArenas = tracking.uniqueArenas.includes(event.arenaId) ? tracking.uniqueArenas : [...tracking.uniqueArenas, event.arenaId];
	if (nextTanks === tracking.uniqueTanks && nextArenas === tracking.uniqueArenas) return tracking;
	return {
		uniqueTanks: nextTanks,
		uniqueArenas: nextArenas
	};
}
function updatePermanentTracking(tracking, event) {
	switch (event.type) {
		case "match_started": return {
			...tracking,
			matchesStarted: tracking.matchesStarted + 1
		};
		case "match_completed": return {
			...tracking,
			matchesCompleted: tracking.matchesCompleted + 1,
			uniqueTanks: tracking.uniqueTanks.includes(event.tankId) ? tracking.uniqueTanks : [...tracking.uniqueTanks, event.tankId],
			uniqueArenas: tracking.uniqueArenas.includes(event.arenaId) ? tracking.uniqueArenas : [...tracking.uniqueArenas, event.arenaId]
		};
		case "match_victory": return {
			...tracking,
			wins: tracking.wins + 1
		};
		case "tank_elimination": return {
			...tracking,
			eliminations: tracking.eliminations + 1
		};
		case "powerup_collected": return {
			...tracking,
			powerupsCollected: tracking.powerupsCollected + 1
		};
		case "ability_activated": return {
			...tracking,
			abilitiesActivated: tracking.abilitiesActivated + 1
		};
		case "obstacle_destroyed": return {
			...tracking,
			obstaclesDestroyed: tracking.obstaclesDestroyed + 1
		};
		default: return tracking;
	}
}
function computePermanentMetricValue(metric, tracking) {
	switch (metric) {
		case "eliminations": return tracking.eliminations;
		case "wins": return tracking.wins;
		case "powerups_collected": return tracking.powerupsCollected;
		case "matches_played": return tracking.matchesCompleted;
		case "abilities_activated": return tracking.abilitiesActivated;
		case "obstacles_destroyed": return tracking.obstaclesDestroyed;
		case "unique_tanks_played": return tracking.uniqueTanks.length;
		case "unique_arenas_played": return tracking.uniqueArenas.length;
		default: return 0;
	}
}
/**
* Processes a single player gameplay event across Daily Missions, Weekly Missions, and Achievements.
* Strictly idempotent per `event.eventId` so no event can ever be counted more than once.
*/
function applyGameplayEvent(prevState, event, nowMs = Date.now(), options = {}) {
	const { state: currentState } = ensureMissionPeriodsCurrent(prevState, nowMs, options);
	const eventId = event.eventId?.trim();
	if (eventId && currentState.processedEventIds.includes(eventId)) return {
		nextState: currentState,
		applied: false
	};
	const nextDailyTracking = updatePeriodTracking(currentState.dailyTracking, event);
	const nextWeeklyTracking = updatePeriodTracking(currentState.weeklyTracking, event);
	const nextPermanentTracking = updatePermanentTracking(currentState.permanentTracking, event);
	const nextDailyMissions = advanceMissionList(currentState.dailyMissions, nextDailyTracking, event, options);
	const nextWeeklyMissions = advanceMissionList(currentState.weeklyMissions, nextWeeklyTracking, event, options);
	const achDefs = options.achievements ?? ACHIEVEMENT_DEFINITIONS;
	const nextAchievements = { ...currentState.achievements };
	for (const def of achDefs) {
		const existing = nextAchievements[def.id] ?? {
			achievementId: def.id,
			progress: 0,
			completed: false,
			unlockedAtMs: null,
			claimed: false,
			claimedAtMs: null
		};
		const metricVal = computePermanentMetricValue(def.metric, nextPermanentTracking);
		const nextProgress = Math.min(def.target, Math.max(existing.progress, metricVal));
		const completed = existing.completed || nextProgress >= def.target;
		if (nextProgress !== existing.progress || completed !== existing.completed) nextAchievements[def.id] = {
			...existing,
			progress: nextProgress,
			completed,
			unlockedAtMs: existing.unlockedAtMs ?? (completed ? nowMs : null)
		};
	}
	const nextProcessedIds = eventId ? [eventId, ...currentState.processedEventIds].slice(0, 250) : currentState.processedEventIds;
	return {
		applied: true,
		nextState: {
			...currentState,
			dailyMissions: nextDailyMissions,
			dailyTracking: nextDailyTracking,
			weeklyMissions: nextWeeklyMissions,
			weeklyTracking: nextWeeklyTracking,
			achievements: nextAchievements,
			permanentTracking: nextPermanentTracking,
			processedEventIds: nextProcessedIds
		}
	};
}
/**
* Centralized reward claim service for Daily Missions, Weekly Missions, and Achievements.
* Prevents duplicate claims and awards XP/Scrap/Cosmetics via `grantProgressionRewards`.
*/
function claimMissionOrAchievementReward(prevProgression, prevMissions, scope, id, nowMs = Date.now(), options = {}, progressionOverrides = {}) {
	const emptyFail = (reason) => ({
		claimed: false,
		reason,
		xpAwarded: 0,
		scrapAwarded: 0,
		cosmeticUnlocked: null,
		previousLevel: prevProgression.level,
		newLevel: prevProgression.level,
		levelsGained: 0,
		unlockedMilestones: []
	});
	if (scope === "daily" || scope === "weekly") {
		const list = scope === "daily" ? prevMissions.dailyMissions : prevMissions.weeklyMissions;
		const idx = list.findIndex((m) => m.missionId === id);
		if (idx === -1) return {
			nextProgression: prevProgression,
			nextMissions: prevMissions,
			outcome: emptyFail("not_found")
		};
		const entry = list[idx];
		if (!entry.completed) return {
			nextProgression: prevProgression,
			nextMissions: prevMissions,
			outcome: emptyFail("not_completed")
		};
		if (entry.claimed) return {
			nextProgression: prevProgression,
			nextMissions: prevMissions,
			outcome: emptyFail("already_claimed")
		};
		const def = resolveMissionDefinition(id, options);
		if (!def) return {
			nextProgression: prevProgression,
			nextMissions: prevMissions,
			outcome: emptyFail("not_found")
		};
		const rewardRes = grantProgressionRewards(prevProgression, {
			xp: def.reward.xp,
			scrap: def.reward.scrap,
			cosmeticId: def.reward.cosmeticId
		}, progressionOverrides);
		const updatedList = list.map((item, i) => i === idx ? {
			...item,
			claimed: true,
			claimedAtMs: nowMs
		} : item);
		const nextMissions = scope === "daily" ? {
			...prevMissions,
			dailyMissions: updatedList
		} : {
			...prevMissions,
			weeklyMissions: updatedList
		};
		return {
			nextProgression: rewardRes.nextProgression,
			nextMissions,
			outcome: {
				claimed: true,
				xpAwarded: rewardRes.xpAwarded,
				scrapAwarded: rewardRes.scrapAwarded,
				cosmeticUnlocked: rewardRes.cosmeticUnlocked,
				previousLevel: rewardRes.previousLevel,
				newLevel: rewardRes.newLevel,
				levelsGained: rewardRes.levelsGained,
				unlockedMilestones: rewardRes.unlockedMilestones
			}
		};
	}
	const achDef = (options.achievements ?? ACHIEVEMENT_DEFINITIONS).find((a) => a.id === id) ?? ACHIEVEMENT_DEFINITION_MAP[id];
	const achEntry = prevMissions.achievements[id];
	if (!achDef || !achEntry) return {
		nextProgression: prevProgression,
		nextMissions: prevMissions,
		outcome: emptyFail("not_found")
	};
	if (!achEntry.completed) return {
		nextProgression: prevProgression,
		nextMissions: prevMissions,
		outcome: emptyFail("not_completed")
	};
	if (achEntry.claimed) return {
		nextProgression: prevProgression,
		nextMissions: prevMissions,
		outcome: emptyFail("already_claimed")
	};
	const rewardRes = grantProgressionRewards(prevProgression, {
		xp: achDef.reward.xp,
		scrap: achDef.reward.scrap,
		cosmeticId: achDef.reward.cosmeticId
	}, progressionOverrides);
	const nextMissions = {
		...prevMissions,
		achievements: {
			...prevMissions.achievements,
			[id]: {
				...achEntry,
				claimed: true,
				claimedAtMs: nowMs
			}
		}
	};
	return {
		nextProgression: rewardRes.nextProgression,
		nextMissions,
		outcome: {
			claimed: true,
			xpAwarded: rewardRes.xpAwarded,
			scrapAwarded: rewardRes.scrapAwarded,
			cosmeticUnlocked: rewardRes.cosmeticUnlocked,
			previousLevel: rewardRes.previousLevel,
			newLevel: rewardRes.newLevel,
			levelsGained: rewardRes.levelsGained,
			unlockedMilestones: rewardRes.unlockedMilestones
		}
	};
}
function countUnclaimedRewards(state) {
	const daily = state.dailyMissions.filter((m) => m.completed && !m.claimed).length;
	const weekly = state.weeklyMissions.filter((m) => m.completed && !m.claimed).length;
	const achievements = Object.values(state.achievements).filter((a) => a.completed && !a.claimed).length;
	return {
		daily,
		weekly,
		achievements,
		total: daily + weekly + achievements
	};
}
// node_modules/@playgama/bridge/dist/constants.esm.mjs
var E = {
	d: (_, A) => {
		for (var e in A) E.o(A, e) && !E.o(_, e) && Object.defineProperty(_, e, {
			enumerable: !0,
			get: A[e]
		});
	},
	o: (E, _) => Object.prototype.hasOwnProperty.call(E, _)
};
var _ = {};
E.d(_, {
	Cb: () => n,
	Kk: () => M,
	Hd: () => T,
	cr: () => p,
	AR: () => l,
	Lh: () => s,
	me: () => r,
	Bq: () => i,
	W1: () => S,
	WA: () => d,
	LS: () => D,
	Z: () => C,
	oF: () => o,
	ti: () => Y,
	xR: () => m,
	Qx: () => G,
	Lb: () => R,
	Dt: () => t,
	TJ: () => U,
	b3: () => P,
	Jt: () => g,
	AQ: () => c,
	YU: () => N
});
var A = {
	SDK_NOT_INITIALIZED: "SDK_NOT_INITIALIZED",
	INITIALIZATION_FAILED: "INITIALIZATION_FAILED",
	CONFIG_LOAD_FAILED: "CONFIG_LOAD_FAILED",
	CONFIG_PARSE_FAILED: "CONFIG_PARSE_FAILED",
	STORAGE_NOT_SUPPORTED: "STORAGE_NOT_SUPPORTED",
	STORAGE_NOT_AVAILABLE: "STORAGE_NOT_AVAILABLE",
	STORAGE_QUOTA_EXCEEDED: "STORAGE_QUOTA_EXCEEDED",
	GAME_PARAMS_NOT_FOUND: "GAME_PARAMS_NOT_FOUND",
	INVITE_FRIENDS_MESSAGE_LENGTH_ERROR: "INVITE_FRIENDS_MESSAGE_LENGTH_ERROR",
	NOTIFICATIONS_NOT_SUPPORTED: "NOTIFICATIONS_NOT_SUPPORTED",
	NOTIFICATION_INVALID_PARAMETERS: "NOTIFICATION_INVALID_PARAMETERS",
	MULTIPLAYER_NOT_SUPPORTED: "MULTIPLAYER_NOT_SUPPORTED",
	MULTIPLAYER_ALREADY_IN_ROOM: "MULTIPLAYER_ALREADY_IN_ROOM",
	MULTIPLAYER_NOT_IN_ROOM: "MULTIPLAYER_NOT_IN_ROOM",
	MULTIPLAYER_ROOM_NOT_FOUND: "MULTIPLAYER_ROOM_NOT_FOUND",
	MULTIPLAYER_ROOM_FULL: "MULTIPLAYER_ROOM_FULL",
	MULTIPLAYER_ROOM_CLOSED: "MULTIPLAYER_ROOM_CLOSED",
	MULTIPLAYER_CONNECTION_FAILED: "MULTIPLAYER_CONNECTION_FAILED"
};
var e = {
	SDK_NOT_INITIALIZED: "Before using the SDK you must initialize it",
	INITIALIZATION_FAILED: "SDK initialization failed",
	CONFIG_LOAD_FAILED: "Failed to load the bridge config file",
	CONFIG_PARSE_FAILED: "Failed to parse the bridge config file",
	STORAGE_NOT_SUPPORTED: "Storage not supported",
	STORAGE_NOT_AVAILABLE: "Storage not available",
	STORAGE_QUOTA_EXCEEDED: "Storage quota exceeded",
	GAME_PARAMS_NOT_FOUND: "Game params are not found",
	INVITE_FRIENDS_MESSAGE_LENGTH_ERROR: "Message is too long",
	NOTIFICATIONS_NOT_SUPPORTED: "Notifications not supported",
	NOTIFICATION_INVALID_PARAMETERS: "Invalid notification parameters",
	MULTIPLAYER_NOT_SUPPORTED: "Multiplayer is not supported on this platform",
	MULTIPLAYER_ALREADY_IN_ROOM: "Already in a multiplayer room",
	MULTIPLAYER_NOT_IN_ROOM: "Not in a multiplayer room",
	MULTIPLAYER_ROOM_NOT_FOUND: "Multiplayer room not found",
	MULTIPLAYER_ROOM_FULL: "Multiplayer room is full",
	MULTIPLAYER_ROOM_CLOSED: "Multiplayer room is closed for new players",
	MULTIPLAYER_CONNECTION_FAILED: "Failed to connect to the multiplayer room"
};
var T = class extends Error {
	code;
	originalError;
	constructor(E, _) {
		super(e[E]), this.name = "BridgeError", this.code = E, this.originalError = _;
	}
};
Object.fromEntries(Object.keys(A).map(((E) => [E, {
	code: E,
	message: e[E]
}])));
var O = {
	VK: "vk",
	OK: "ok",
	YANDEX: "yandex",
	CRAZY_GAMES: "crazy_games",
	GAME_DISTRIBUTION: "game_distribution",
	PLAYGAMA: "playgama",
	STANDALONE: "standalone",
	PLAYGAMA_SANDBOX: "playgama_sandbox",
	TELEGRAM: "telegram",
	Y8: "y8",
	LAGGED: "lagged",
	FACEBOOK: "facebook",
	POKI: "poki",
	MOCK: "mock",
	QA_TOOL: "qa_tool",
	MSN: "msn",
	MICROSOFT_STORE: "microsoft_store",
	HUAWEI: "huawei",
	GAMEPUSH: "gamepush",
	DISCORD: "discord",
	JIO_GAMES: "jio_games",
	YOUTUBE: "youtube",
	PORTAL: "portal",
	REDDIT: "reddit",
	XIAOMI: "xiaomi",
	TIKTOK: "tiktok",
	DLIGHTEK: "dlightek",
	GAMESNACKS: "gamesnacks",
	SAMSUNG: "samsung"
};
var a = {
	DESKTOP: "desktop",
	MOBILE: "mobile",
	TABLET: "tablet",
	TV: "tv"
};
var I = {
	PORTRAIT: "portrait",
	LANDSCAPE: "landscape"
};
var L = (new Set(Object.values(a)), new Set(Object.values(I)), { RELAY: "relay" });
var R = O;
var t = {
	GAME_READY: "game_ready",
	LEVEL_STARTED: "level_started",
	LEVEL_COMPLETED: "level_completed",
	LEVEL_FAILED: "level_failed",
	LEVEL_PAUSED: "level_paused",
	LEVEL_RESUMED: "level_resumed",
	IN_GAME_LOADING_STARTED: "in_game_loading_started",
	IN_GAME_LOADING_STOPPED: "in_game_loading_stopped",
	GAMEPLAY_STARTED: "gameplay_started",
	GAMEPLAY_STOPPED: "gameplay_stopped",
	PLAYER_GOT_ACHIEVEMENT: "player_got_achievement"
};
var N = {
	VISIBLE: "visible",
	HIDDEN: "hidden"
};
var o = {
	CORE: "core",
	PLATFORM: "platform",
	PLAYER: "player",
	STORAGE: "storage",
	ADVERTISEMENT: "advertisement",
	SOCIAL: "social",
	DEVICE: "device",
	LEADERBOARDS: "leaderboards",
	PAYMENTS: "payments",
	REMOTE_CONFIG: "remote_config",
	CLIPBOARD: "clipboard",
	ACHIEVEMENTS: "achievements",
	ANALYTICS: "analytics",
	NOTIFICATIONS: "notifications",
	DAILY_REWARDS: "daily_rewards",
	TASKS: "tasks",
	CROSS_PROMO: "cross_promo",
	MULTIPLAYER: "multiplayer"
};
var S = {
	INTERSTITIAL_STATE_CHANGED: "interstitial_state_changed",
	REWARDED_STATE_CHANGED: "rewarded_state_changed",
	BANNER_STATE_CHANGED: "banner_state_changed",
	ADVANCED_BANNERS_STATE_CHANGED: "advanced_banners_state_changed",
	AUDIO_STATE_CHANGED: "audio_state_changed",
	PAUSE_STATE_CHANGED: "pause_state_changed",
	ORIENTATION_STATE_CHANGED: "orientation_state_changed",
	SCREEN_SIZE_CHANGED: "screen_size_changed",
	PLATFORM_MESSAGE_SENT: "platform_message_sent",
	PLATFORM_STORAGE_AVAILABILITY_CHANGED: "platform_storage_availability_changed",
	VISIBILITY_STATE_CHANGED: "visibility_state_changed",
	STORAGE_SET: "storage_set",
	CROSS_PROMO_SHOWN: "cross_promo_shown",
	DAILY_REWARDS_CLAIMED: "daily_rewards_claimed",
	DAILY_REWARDS_STREAK_RESET: "daily_rewards_streak_reset",
	TASKS_REWARD_CLAIMED: "tasks_reward_claimed",
	TASKS_PERIOD_ROLLED_OVER: "tasks_period_rolled_over",
	MULTIPLAYER_STATE_CHANGED: "multiplayer_state_changed",
	MULTIPLAYER_ROOM_LEFT: "multiplayer_room_left",
	MULTIPLAYER_ROOM_UPDATED: "multiplayer_room_updated",
	MULTIPLAYER_PLAYER_JOINED: "multiplayer_player_joined",
	MULTIPLAYER_PLAYER_LEFT: "multiplayer_player_left",
	MULTIPLAYER_PLAYER_UPDATED: "multiplayer_player_updated",
	MULTIPLAYER_HOST_CHANGED: "multiplayer_host_changed",
	MULTIPLAYER_MESSAGE_RECEIVED: "multiplayer_message_received",
	MULTIPLAYER_SYNC_STATE_RECEIVED: "multiplayer_sync_state_received"
};
var D = {
	NOTIFICATION: "notification",
	POST: "post"
};
var i = A;
var r = a;
var s = {
	WINDOWS: "windows",
	MACOS: "macos",
	LINUX: "linux",
	ANDROID: "android",
	IOS: "ios",
	OTHER: "other"
};
var l = I;
var n = {
	TOP: "top",
	BOTTOM: "bottom"
};
var M = {
	LOADING: "loading",
	SHOWN: "shown",
	HIDDEN: "hidden",
	FAILED: "failed"
};
var d = {
	LOADING: "loading",
	OPENED: "opened",
	CLOSED: "closed",
	FAILED: "failed"
};
var P = {
	LOADING: "loading",
	OPENED: "opened",
	CLOSED: "closed",
	FAILED: "failed",
	REWARDED: "rewarded"
};
var C = {
	NOT_AVAILABLE: "not_available",
	IN_GAME: "in_game",
	NATIVE: "native",
	NATIVE_POPUP: "native_popup"
};
var c = {
	DAILY: "daily",
	WEEKLY: "weekly",
	PERMANENT: "permanent"
};
var p = {
	CONFIG: "config",
	PLATFORM: "platform"
};
var U = {
	VISIT: "visit",
	AUTHOR: "author"
};
var m = {
	ALL: "all",
	OTHERS: "others",
	HOST: "host"
};
var G = L;
var Y = {
	DISCONNECTED: "disconnected",
	CONNECTING: "connecting",
	CONNECTED: "connected",
	RECONNECTING: "reconnecting"
};
var g = {
	LEFT: "left",
	CONNECTION_LOST: "connection_lost",
	ROOM_CLOSED: "room_closed"
};
_.Cb;
_.Kk;
_.Hd;
_.cr;
_.AR;
_.Lh;
_.me;
_.Bq;
var v = _.W1;
var B = _.WA;
_.LS;
_.Z;
_.oF;
_.ti;
_.xR;
_.Qx;
var j = _.Lb;
var Q = _.Dt;
_.TJ;
var J = _.b3;
_.Jt;
_.AQ;
var $ = _.YU;
// src/services/bridge/PlaygamaBridgeAdapter.ts
var LOCAL_ONLY_PLATFORM_IDS = /* @__PURE__ */ new Set([
	"local_offline",
	j.MOCK,
	j.STANDALONE
]);
var INTERSTITIAL_MIN_COOLDOWN_MS = 9e4;
var INTERSTITIAL_FAILURE_BACKOFF_MS = 15e3;
var INTERSTITIAL_MATCHES_INTERVAL = 2;
var INIT_TIMEOUT_MS = 6e3;
var AD_COMPLETION_TIMEOUT_MS = 45e3;
function resolveGlobalSdk() {
	try {
		if (typeof window !== "undefined") {
			const win = window;
			const candidate = win.bridge ?? win.playgamaBridge;
			if (candidate && typeof candidate === "object") return candidate;
		}
		if (typeof globalThis !== "undefined" && "bridge" in globalThis) {
			const candidate = globalThis.bridge;
			if (candidate && typeof candidate === "object") return candidate;
		}
	} catch {}
	return null;
}
function sanitizeAnalyticsData(data) {
	if (!data) return void 0;
	const blockedKeys = /* @__PURE__ */ new Set([
		"playerName",
		"player_name",
		"name",
		"email",
		"userId",
		"user_id",
		"token"
	]);
	const safe = {};
	for (const [key, val] of Object.entries(data)) {
		if (blockedKeys.has(key)) continue;
		if (typeof val === "string" || typeof val === "number" || typeof val === "boolean" || val === null) safe[key] = val;
	}
	return safe;
}
function sanitizeDiagnosticDetails(details) {
	if (!details) return void 0;
	const blockedKeys = /* @__PURE__ */ new Set([
		"playerName",
		"player_name",
		"name",
		"email",
		"userId",
		"user_id",
		"token",
		"grantId"
	]);
	const safe = {};
	for (const [key, val] of Object.entries(details)) {
		if (blockedKeys.has(key)) continue;
		safe[key] = val;
	}
	return safe;
}
var PlaygamaCompatibleBridgeAdapter = class {
	constructor(options = {}) {
		this.initialized = false;
		this.initPending = false;
		this.initPromise = null;
		this.sdkInitPromise = null;
		this.sdkInitInFlight = false;
		this.sdkInitTimedOut = false;
		this.sdkInitFailed = false;
		this.sdkReady = false;
		this.listenersAttached = false;
		this.attachedSdk = null;
		this.documentVisibilityBound = false;
		this.gameReadySent = false;
		this.gameplayActive = false;
		this.detectedPlatformId = "local_offline";
		this.platformPaused = false;
		this.audioEnabled = true;
		this.pageVisible = true;
		this.adPlaying = false;
		this.completedMatchesTotal = 0;
		this.completedMatchesSinceAd = 0;
		this.lastInterstitialAtMs = 0;
		this.lastInterstitialFailureAtMs = 0;
		this.rewardedRequestInFlight = false;
		this.interstitialRequestInFlight = false;
		this.stateListeners = /* @__PURE__ */ new Set();
		this.onPauseStateChanged = (paused) => {
			this.platformPaused = Boolean(paused);
			this.emitState();
		};
		this.onAudioStateChanged = (enabled) => {
			this.audioEnabled = Boolean(enabled);
			this.emitState();
		};
		this.onVisibilityStateChanged = (visibility) => {
			this.pageVisible = visibility !== $.HIDDEN;
			this.emitState();
		};
		this.onRewardedStateDiagnostic = (rawState) => {
			const state = typeof rawState === "string" ? rawState : "unknown";
			this.logDiagnostic(state === J.FAILED ? "warn" : "info", "rewarded_state_changed", {
				state,
				platformId: this.detectedPlatformId
			});
		};
		this.onInterstitialStateDiagnostic = (rawState) => {
			const state = typeof rawState === "string" ? rawState : "unknown";
			this.logDiagnostic(state === B.FAILED ? "warn" : "info", "interstitial_state_changed", {
				state,
				platformId: this.detectedPlatformId
			});
		};
		this.onDocumentVisibilityChange = () => {
			if (typeof document === "undefined") return;
			this.pageVisible = document.visibilityState !== "hidden";
			if (!this.pageVisible) this.flushStorage();
			this.emitState();
		};
		this.getSdkFn = options.getSdk ?? resolveGlobalSdk;
		this.nowFn = options.now ?? (() => Date.now());
		this.initTimeoutMs = options.initTimeoutMs ?? INIT_TIMEOUT_MS;
		this.adTimeoutMs = options.adTimeoutMs ?? AD_COMPLETION_TIMEOUT_MS;
		this.interstitialCooldownMs = options.interstitialCooldownMs ?? INTERSTITIAL_MIN_COOLDOWN_MS;
		this.interstitialFailureBackoffMs = options.interstitialFailureBackoffMs ?? INTERSTITIAL_FAILURE_BACKOFF_MS;
		this.interstitialMatchesInterval = options.interstitialMatchesInterval ?? INTERSTITIAL_MATCHES_INTERVAL;
		this.diagnosticHandler = options.onDiagnostic;
		if (typeof document !== "undefined") this.pageVisible = document.visibilityState !== "hidden";
	}
	getSdk() {
		return this.getSdkFn();
	}
	logDiagnostic(level, event, details) {
		const safeDetails = sanitizeDiagnosticDetails(details);
		if (this.diagnosticHandler) {
			try {
				this.diagnosticHandler({
					event,
					level,
					details: safeDetails
				});
			} catch {}
			return;
		}
		if (typeof console !== "undefined") {
			const fn = level === "warn" ? console.warn : console.info;
			if (typeof fn === "function") {
				if (safeDetails && Object.keys(safeDetails).length > 0) fn(`[PlaygamaBridge] ${event}`, safeDetails);
				else fn(`[PlaygamaBridge] ${event}`);
			}
		}
	}
	get isInitialized() {
		return this.initialized;
	}
	get platformId() {
		return this.detectedPlatformId;
	}
	get isPlaygamaPlatform() {
		return this.sdkReady && this.detectedPlatformId.length > 0 && !LOCAL_ONLY_PLATFORM_IDS.has(this.detectedPlatformId);
	}
	canAccessSdkModules(sdk) {
		if (!sdk) return false;
		if (typeof sdk.isInitialized === "boolean") return sdk.isInitialized;
		return typeof sdk.initialize !== "function" || this.sdkReady;
	}
	get supportsPlatformStorage() {
		const sdk = this.getSdk();
		if (!this.canAccessSdkModules(sdk)) return false;
		if (!sdk.storage?.get || !sdk.storage?.set) return false;
		const pid = sdk.platform?.id ?? this.detectedPlatformId;
		if (LOCAL_ONLY_PLATFORM_IDS.has(pid)) return false;
		try {
			if (typeof sdk.storage.isSupported === "function") return Boolean(sdk.storage.isSupported(sdk.storage.defaultType));
			if (typeof sdk.platform?.isPlatformStorageAvailable === "boolean") return sdk.platform.isPlatformStorageAvailable;
			return Boolean(pid && !LOCAL_ONLY_PLATFORM_IDS.has(pid));
		} catch {
			return false;
		}
	}
	get isRewardedAdSupported() {
		if (!this.sdkReady) return false;
		const sdk = this.getSdk();
		if (!this.canAccessSdkModules(sdk)) return false;
		try {
			return Boolean(sdk.advertisement?.isRewardedSupported);
		} catch {
			return false;
		}
	}
	get isInterstitialAdSupported() {
		if (!this.sdkReady) return false;
		const sdk = this.getSdk();
		if (!this.canAccessSdkModules(sdk)) return false;
		try {
			return Boolean(sdk.advertisement?.isInterstitialSupported);
		} catch {
			return false;
		}
	}
	get isAdPlaying() {
		return this.adPlaying;
	}
	get isPlatformPaused() {
		return this.platformPaused;
	}
	get isAudioEnabled() {
		return this.audioEnabled;
	}
	getState() {
		return {
			isInitialized: this.initialized,
			isInitPending: this.initPending,
			platformId: this.detectedPlatformId,
			isPlaygamaPlatform: this.isPlaygamaPlatform,
			isPlatformPaused: this.platformPaused,
			isAudioEnabled: this.audioEnabled,
			isPageVisible: this.pageVisible,
			isAdPlaying: this.adPlaying,
			isRewardedSupported: this.isRewardedAdSupported,
			isInterstitialSupported: this.isInterstitialAdSupported,
			supportsPlatformStorage: this.supportsPlatformStorage
		};
	}
	subscribeState(listener) {
		this.stateListeners.add(listener);
		try {
			listener(this.getState());
		} catch {}
		return () => {
			this.stateListeners.delete(listener);
		};
	}
	emitState() {
		const snap = this.getState();
		this.stateListeners.forEach((listener) => {
			try {
				listener(snap);
			} catch {}
		});
	}
	detachSdkListeners(sdk) {
		if (!sdk) return;
		const platformEmitter = sdk.platform?.on ? sdk.platform : sdk;
		try {
			platformEmitter?.off?.(v.PAUSE_STATE_CHANGED, this.onPauseStateChanged);
			platformEmitter?.off?.(v.AUDIO_STATE_CHANGED, this.onAudioStateChanged);
			platformEmitter?.off?.(v.VISIBILITY_STATE_CHANGED, this.onVisibilityStateChanged);
			sdk.advertisement?.off?.(v.REWARDED_STATE_CHANGED, this.onRewardedStateDiagnostic);
			sdk.advertisement?.off?.(v.INTERSTITIAL_STATE_CHANGED, this.onInterstitialStateDiagnostic);
		} catch {}
	}
	attachSdkListeners(sdk) {
		if (this.listenersAttached && this.attachedSdk === sdk) return;
		if (this.attachedSdk && this.attachedSdk !== sdk) this.detachSdkListeners(this.attachedSdk);
		this.listenersAttached = true;
		this.attachedSdk = sdk;
		const platformEmitter = sdk.platform?.on ? sdk.platform : sdk;
		try {
			platformEmitter?.on?.(v.PAUSE_STATE_CHANGED, this.onPauseStateChanged);
			platformEmitter?.on?.(v.AUDIO_STATE_CHANGED, this.onAudioStateChanged);
			platformEmitter?.on?.(v.VISIBILITY_STATE_CHANGED, this.onVisibilityStateChanged);
		} catch {}
		try {
			sdk.advertisement?.on?.(v.REWARDED_STATE_CHANGED, this.onRewardedStateDiagnostic);
			sdk.advertisement?.on?.(v.INTERSTITIAL_STATE_CHANGED, this.onInterstitialStateDiagnostic);
		} catch {}
		if (!this.documentVisibilityBound && typeof document !== "undefined" && typeof document.addEventListener === "function") {
			this.documentVisibilityBound = true;
			document.addEventListener("visibilitychange", this.onDocumentVisibilityChange);
		}
	}
	finalizeSdkReady(sdk, isLateRecovery) {
		if (sdk.isInitialized === false) return false;
		this.sdkReady = true;
		if (!this.canAccessSdkModules(sdk)) {
			this.sdkReady = false;
			return false;
		}
		this.sdkInitTimedOut = false;
		this.sdkInitFailed = false;
		this.initialized = true;
		this.initPending = false;
		this.detectedPlatformId = sdk.platform?.id || "playgama";
		if (typeof sdk.platform?.isAudioEnabled === "boolean") this.audioEnabled = sdk.platform.isAudioEnabled;
		if (typeof sdk.platform?.isPaused === "boolean") this.platformPaused = sdk.platform.isPaused;
		try {
			sdk.advertisement?.setMinimumDelayBetweenInterstitial?.(60);
		} catch {}
		try {
			sdk.setGameLoadingProgress?.(100);
		} catch {}
		this.attachSdkListeners(sdk);
		if (isLateRecovery) this.logDiagnostic("info", "sdk_late_init_recovery", { platformId: this.detectedPlatformId });
		const rewardedSupported = this.isRewardedAdSupported;
		const interstitialSupported = this.isInterstitialAdSupported;
		this.logDiagnostic("info", "sdk_init_completed", {
			platformId: this.detectedPlatformId,
			isPlaygamaPlatform: this.isPlaygamaPlatform,
			isRewardedSupported: rewardedSupported,
			isInterstitialSupported: interstitialSupported,
			lateRecovery: isLateRecovery
		});
		if (isLateRecovery) this.notifyGameReady();
		this.emitState();
		return true;
	}
	enterOfflineFallback(options) {
		this.sdkReady = false;
		this.sdkInitTimedOut = options.timedOut;
		this.sdkInitFailed = options.failed;
		this.detectedPlatformId = "local_offline";
		this.initialized = true;
		this.initPending = false;
		this.emitState();
	}
	tryRecoverFromReadySdk() {
		if (this.sdkReady) return true;
		const sdk = this.getSdk();
		if (sdk && sdk.isInitialized === true && this.canAccessSdkModules(sdk)) return this.finalizeSdkReady(sdk, true);
		return false;
	}
	async init() {
		if (this.sdkReady) return;
		if (this.initPromise) return this.initPromise;
		if (this.initialized) {
			this.tryRecoverFromReadySdk();
			return;
		}
		this.initPending = true;
		this.emitState();
		this.logDiagnostic("info", "sdk_init_started", { timeoutMs: this.initTimeoutMs });
		this.initPromise = (async () => {
			const sdk = this.getSdk();
			if (!sdk) {
				this.logDiagnostic("warn", "sdk_init_failed", {
					reason: "sdk_not_found",
					platformId: "local_offline"
				});
				this.enterOfflineFallback({
					timedOut: false,
					failed: true
				});
				return;
			}
			if (typeof sdk.initialize !== "function" || sdk.isInitialized === true) {
				if (!this.finalizeSdkReady(sdk, false)) {
					this.logDiagnostic("warn", "sdk_init_failed", {
						reason: "sdk_not_ready",
						platformId: "local_offline"
					});
					this.enterOfflineFallback({
						timedOut: false,
						failed: true
					});
				}
				return;
			}
			if (!this.sdkInitPromise) {
				this.sdkInitInFlight = true;
				this.sdkInitFailed = false;
				this.sdkInitPromise = Promise.resolve(sdk.initialize()).then(() => {
					this.sdkInitInFlight = false;
					const wasTimedOut = this.sdkInitTimedOut;
					if (!this.finalizeSdkReady(sdk, wasTimedOut)) {
						this.sdkInitPromise = null;
						this.logDiagnostic("warn", "sdk_init_failed", {
							reason: "sdk_isInitialized_false",
							platformId: "local_offline"
						});
						this.enterOfflineFallback({
							timedOut: false,
							failed: true
						});
					}
				}).catch(() => {
					this.sdkInitInFlight = false;
					this.sdkInitPromise = null;
					this.logDiagnostic("warn", "sdk_init_failed", {
						reason: "sdk_initialize_rejected",
						platformId: "local_offline"
					});
					this.enterOfflineFallback({
						timedOut: false,
						failed: true
					});
				});
			}
			let timerId = null;
			const timeoutResult = await Promise.race([this.sdkInitPromise.then(() => "settled"), new Promise((resolve) => {
				timerId = setTimeout(() => resolve("timeout"), this.initTimeoutMs);
			})]);
			if (timerId !== null) clearTimeout(timerId);
			if (timeoutResult === "timeout" && !this.sdkReady) {
				this.logDiagnostic("warn", "sdk_init_timed_out", {
					timeoutMs: this.initTimeoutMs,
					fallbackPlatformId: "local_offline"
				});
				this.enterOfflineFallback({
					timedOut: true,
					failed: false
				});
			}
		})();
		try {
			await this.initPromise;
		} finally {
			this.initPromise = null;
		}
	}
	async retryInit() {
		if (this.sdkReady) return;
		if (this.initPromise) return this.initPromise;
		if (this.tryRecoverFromReadySdk()) return;
		if (this.sdkInitInFlight && this.sdkInitPromise) {
			let timerId = null;
			await Promise.race([this.sdkInitPromise, new Promise((resolve) => {
				timerId = setTimeout(resolve, this.initTimeoutMs);
			})]);
			if (timerId !== null) clearTimeout(timerId);
			return;
		}
		this.initialized = false;
		this.sdkInitFailed = false;
		this.sdkInitTimedOut = false;
		return this.init();
	}
	notifyGameReady() {
		if (this.gameReadySent) return;
		const sdk = this.getSdk();
		if (!this.sdkReady || !this.canAccessSdkModules(sdk)) return;
		this.gameReadySent = true;
		try {
			sdk.platform?.sendMessage?.(Q.GAME_READY);
		} catch {}
	}
	notifyGameplayStart() {
		if (this.gameplayActive) return;
		this.gameplayActive = true;
		const sdk = this.getSdk();
		if (!this.sdkReady || !this.canAccessSdkModules(sdk)) return;
		try {
			sdk.platform?.sendMessage?.(Q.GAMEPLAY_STARTED);
		} catch {}
	}
	notifyGameplayStop() {
		if (!this.gameplayActive) return;
		this.gameplayActive = false;
		const sdk = this.getSdk();
		if (!this.sdkReady || !this.canAccessSdkModules(sdk)) return;
		try {
			sdk.platform?.sendMessage?.(Q.GAMEPLAY_STOPPED);
		} catch {}
	}
	notifyHappyTime() {
		const sdk = this.getSdk();
		if (!this.sdkReady || !this.canAccessSdkModules(sdk)) return;
		try {
			sdk.platform?.sendMessage?.(Q.PLAYER_GOT_ACHIEVEMENT);
		} catch {}
	}
	recordCompletedMatch() {
		this.completedMatchesTotal += 1;
		this.completedMatchesSinceAd += 1;
	}
	async showRewardedAd(grantId) {
		if (!this.initialized) await this.init();
		else if (!this.sdkReady) this.tryRecoverFromReadySdk();
		const sdk = this.getSdk();
		if (!this.sdkReady || !sdk?.advertisement?.showRewarded || !this.isRewardedAdSupported) {
			this.logDiagnostic("warn", "ad_unavailable", {
				adType: "rewarded",
				platformId: this.detectedPlatformId,
				sdkReady: this.sdkReady,
				isRewardedSupported: this.isRewardedAdSupported
			});
			return {
				status: "unavailable",
				granted: false,
				grantId
			};
		}
		const currentRewardedState = sdk.advertisement.rewardedState;
		if (this.rewardedRequestInFlight || this.interstitialRequestInFlight || currentRewardedState === J.LOADING || currentRewardedState === J.OPENED) {
			this.logDiagnostic("warn", "ad_failed", {
				adType: "rewarded",
				platformId: this.detectedPlatformId,
				reason: "busy"
			});
			return {
				status: "failed",
				granted: false,
				grantId
			};
		}
		this.rewardedRequestInFlight = true;
		this.adPlaying = true;
		this.emitState();
		this.logDiagnostic("info", "ad_request_started", {
			adType: "rewarded",
			platformId: this.detectedPlatformId,
			isRewardedSupported: this.isRewardedAdSupported
		});
		this.trackEvent("advertisement_requested", { ad_type: "rewarded" });
		return new Promise((resolve) => {
			let settled = false;
			let sawRewarded = false;
			let timerId = null;
			const finish = (outcome) => {
				if (settled) return;
				settled = true;
				if (timerId !== null) clearTimeout(timerId);
				try {
					sdk.advertisement?.off?.(v.REWARDED_STATE_CHANGED, onState);
				} catch {}
				this.rewardedRequestInFlight = false;
				this.adPlaying = false;
				this.emitState();
				if (outcome.status === "failed") this.logDiagnostic("warn", "ad_failed", {
					adType: "rewarded",
					platformId: this.detectedPlatformId,
					status: outcome.status,
					granted: false
				});
				else this.logDiagnostic("info", "ad_completed", {
					adType: "rewarded",
					platformId: this.detectedPlatformId,
					status: outcome.status,
					granted: outcome.granted
				});
				this.trackEvent("advertisement_completed", {
					ad_type: "rewarded",
					status: outcome.status,
					granted: outcome.granted
				});
				resolve(outcome);
			};
			const onState = (rawState) => {
				const state = typeof rawState === "string" ? rawState : "";
				if (state === J.REWARDED) {
					sawRewarded = true;
					return;
				}
				if (state === J.CLOSED) {
					finish({
						status: sawRewarded ? "rewarded" : "skipped",
						granted: sawRewarded,
						grantId
					});
					return;
				}
				if (state === J.FAILED) finish({
					status: "failed",
					granted: false,
					grantId
				});
			};
			try {
				sdk.advertisement?.on?.(v.REWARDED_STATE_CHANGED, onState);
			} catch {}
			timerId = setTimeout(() => {
				finish({
					status: "failed",
					granted: false,
					grantId
				});
			}, this.adTimeoutMs);
			try {
				sdk.advertisement?.showRewarded?.();
			} catch {
				finish({
					status: "failed",
					granted: false,
					grantId
				});
			}
		});
	}
	async maybeShowInterstitial(trigger, options = {}) {
		if (options.inActiveMatch || this.gameplayActive) {
			this.logDiagnostic("info", "ad_unavailable", {
				adType: "interstitial",
				trigger,
				reason: "in_match"
			});
			return {
				shown: false,
				reason: "in_match"
			};
		}
		if (this.rewardedRequestInFlight || this.interstitialRequestInFlight) {
			this.logDiagnostic("warn", "ad_failed", {
				adType: "interstitial",
				trigger,
				reason: "busy"
			});
			return {
				shown: false,
				reason: "busy"
			};
		}
		if (!this.initialized) await this.init();
		else if (!this.sdkReady) this.tryRecoverFromReadySdk();
		const sdk = this.getSdk();
		if (!this.sdkReady || !sdk?.advertisement?.showInterstitial || !this.isInterstitialAdSupported) {
			this.logDiagnostic("warn", "ad_unavailable", {
				adType: "interstitial",
				trigger,
				platformId: this.detectedPlatformId,
				sdkReady: this.sdkReady,
				isInterstitialSupported: this.isInterstitialAdSupported
			});
			return {
				shown: false,
				reason: "unavailable"
			};
		}
		const currentInterstitialState = sdk.advertisement.interstitialState;
		if (currentInterstitialState === B.LOADING || currentInterstitialState === B.OPENED) {
			this.logDiagnostic("warn", "ad_failed", {
				adType: "interstitial",
				trigger,
				reason: "busy"
			});
			return {
				shown: false,
				reason: "busy"
			};
		}
		const nowMs = this.nowFn();
		const enoughMatches = this.completedMatchesTotal >= 2 && this.completedMatchesSinceAd >= this.interstitialMatchesInterval;
		const cooldownElapsed = this.lastInterstitialAtMs === 0 || nowMs - this.lastInterstitialAtMs >= this.interstitialCooldownMs;
		const failureBackoffElapsed = this.lastInterstitialFailureAtMs === 0 || nowMs - this.lastInterstitialFailureAtMs >= this.interstitialFailureBackoffMs;
		if (!enoughMatches || !cooldownElapsed || !failureBackoffElapsed) {
			this.logDiagnostic("info", "interstitial_cooldown_active", {
				trigger,
				enoughMatches,
				cooldownElapsed,
				failureBackoffElapsed,
				completedMatchesTotal: this.completedMatchesTotal,
				completedMatchesSinceAd: this.completedMatchesSinceAd
			});
			return {
				shown: false,
				reason: "cooldown"
			};
		}
		this.interstitialRequestInFlight = true;
		this.adPlaying = true;
		this.emitState();
		this.logDiagnostic("info", "ad_request_started", {
			adType: "interstitial",
			trigger,
			platformId: this.detectedPlatformId,
			isInterstitialSupported: this.isInterstitialAdSupported
		});
		this.trackEvent("advertisement_requested", {
			ad_type: "interstitial",
			trigger
		});
		return new Promise((resolve) => {
			let settled = false;
			let timerId = null;
			const finish = (outcome) => {
				if (settled) return;
				settled = true;
				if (timerId !== null) clearTimeout(timerId);
				try {
					sdk.advertisement?.off?.(v.INTERSTITIAL_STATE_CHANGED, onState);
				} catch {}
				this.interstitialRequestInFlight = false;
				this.adPlaying = false;
				if (outcome.shown) {
					this.completedMatchesSinceAd = 0;
					this.lastInterstitialAtMs = this.nowFn();
					this.lastInterstitialFailureAtMs = 0;
					this.logDiagnostic("info", "ad_completed", {
						adType: "interstitial",
						trigger,
						platformId: this.detectedPlatformId,
						reason: outcome.reason
					});
				} else {
					this.lastInterstitialFailureAtMs = this.nowFn();
					this.logDiagnostic("warn", "ad_failed", {
						adType: "interstitial",
						trigger,
						platformId: this.detectedPlatformId,
						reason: outcome.reason
					});
				}
				this.emitState();
				this.trackEvent("advertisement_completed", {
					ad_type: "interstitial",
					trigger,
					status: outcome.reason
				});
				resolve(outcome);
			};
			const onState = (rawState) => {
				const state = typeof rawState === "string" ? rawState : "";
				if (state === B.CLOSED) finish({
					shown: true,
					reason: "completed"
				});
				else if (state === B.FAILED) finish({
					shown: false,
					reason: "failed"
				});
			};
			try {
				sdk.advertisement?.on?.(v.INTERSTITIAL_STATE_CHANGED, onState);
			} catch {}
			timerId = setTimeout(() => {
				finish({
					shown: false,
					reason: "failed"
				});
			}, this.adTimeoutMs);
			try {
				sdk.advertisement?.showInterstitial?.();
			} catch {
				finish({
					shown: false,
					reason: "failed"
				});
			}
		});
	}
	trackEvent(eventName, data) {
		const sdk = this.getSdk();
		if (!this.sdkReady || !this.canAccessSdkModules(sdk) || !sdk.analytics?.send) return;
		try {
			sdk.analytics.send(eventName, sanitizeAnalyticsData(data));
		} catch {}
	}
	syncSaveKey(key, serializedValue) {
		const sdk = this.getSdk();
		if (!this.canAccessSdkModules(sdk) || !sdk.storage?.set || !this.supportsPlatformStorage) return;
		try {
			Promise.resolve(sdk.storage.set([key], [serializedValue])).then(() => sdk.storage?.flush?.()).catch(() => {});
		} catch {}
	}
	async loadSaveKeys(keys) {
		const result = {};
		const sdk = this.getSdk();
		if (!this.canAccessSdkModules(sdk) || !sdk.storage?.get || !this.supportsPlatformStorage || keys.length === 0) return result;
		try {
			const raw = await sdk.storage.get(keys, false);
			if (Array.isArray(raw)) keys.forEach((key, idx) => {
				const val = raw[idx];
				if (typeof val === "string" && val.trim().length > 0) result[key] = val;
				else if (val && typeof val === "object") result[key] = JSON.stringify(val);
			});
			else if (raw && typeof raw === "object") {
				const record = raw;
				for (const key of keys) {
					const val = record[key];
					if (typeof val === "string" && val.trim().length > 0) result[key] = val;
					else if (val && typeof val === "object") result[key] = JSON.stringify(val);
				}
			}
		} catch {}
		return result;
	}
	async flushStorage() {
		const sdk = this.getSdk();
		if (!this.canAccessSdkModules(sdk) || !sdk.storage?.flush || !this.supportsPlatformStorage) return;
		try {
			await sdk.storage.flush();
		} catch {}
	}
};
var platformBridge = new PlaygamaCompatibleBridgeAdapter();
// src/data/storage.ts
var PROGRESSION_KEY = "tankbound_arena_progression_v1";
var PROGRESSION_BACKUP_KEY = "tankbound_arena_progression_backup_v1";
var MISSIONS_KEY = "tankbound_arena_missions_v1";
var MISSIONS_BACKUP_KEY = "tankbound_arena_missions_backup_v1";
var SETTINGS_KEY = "tankbound_arena_settings_v1";
var sessionFallbackMap = /* @__PURE__ */ new Map();
var sessionFallbackStorage = {
	getItem(key) {
		return sessionFallbackMap.has(key) ? sessionFallbackMap.get(key) : null;
	},
	setItem(key, value) {
		sessionFallbackMap.set(key, value);
	},
	removeItem(key) {
		sessionFallbackMap.delete(key);
	}
};
function getDefaultStorage() {
	try {
		if (typeof globalThis !== "undefined" && "localStorage" in globalThis && globalThis.localStorage) {
			const testKey = "__tankbound_storage_probe__";
			globalThis.localStorage.setItem(testKey, "1");
			globalThis.localStorage.removeItem(testKey);
			return globalThis.localStorage;
		}
	} catch {
		return sessionFallbackStorage;
	}
	return sessionFallbackStorage;
}
var saveListeners = /* @__PURE__ */ new Set();
function subscribeSaveEvents(listener) {
	saveListeners.add(listener);
	return () => {
		saveListeners.delete(listener);
	};
}
function emitSaveEvent(event) {
	for (const listener of saveListeners) try {
		listener(event);
	} catch {}
}
function createDefaultProgression() {
	const level = 1;
	const starterTanks = TANK_LIST.filter((t) => t.isStarter && t.implemented).map((t) => t.id);
	return {
		saveVersion: 4,
		playerName: "Commander",
		level,
		xp: 0,
		xpToNext: getXpRequiredForLevel(level),
		totalXpEarned: 0,
		unlockedTanks: starterTanks.length > 0 ? starterTanks : ["assault"],
		selectedTank: "assault",
		selectedArena: "training_grounds",
		scrap: 0,
		totalScrapEarned: 0,
		totalScrapSpent: 0,
		matchesPlayed: 0,
		wins: 0,
		defeats: 0,
		totalEliminations: 0,
		totalPlaytimeSec: 0,
		bestPlacement: null,
		claimedMilestoneLevels: [],
		unlockedCosmetics: ["default"],
		equippedCosmetic: "default",
		unlockedPaintColors: [...STARTER_PAINT_COLORS],
		unlockedDecals: [...STARTER_DECAL_IDS],
		unlockedPresets: [],
		customPaintUnlocked: false,
		tankCustomizations: {},
		processedMatchIds: [],
		processedRewardedAdIds: []
	};
}
createDefaultProgression();
var DEFAULT_SETTINGS = {
	soundEnabled: true,
	soundVolume: .65,
	musicEnabled: true,
	musicVolume: .4,
	graphicsQuality: "high",
	screenShakeEnabled: true,
	vibrationEnabled: true,
	controlSensitivity: 1,
	showTouchControls: "always",
	autoFireOnAim: false,
	lowDetailMode: false,
	matchDurationSec: 150,
	landscapePromptEnabled: true
};
function isPlainRecord(value) {
	return typeof value === "object" && value !== null && !Array.isArray(value);
}
function estimateCumulativeXpForLevel(level, currentXp) {
	let sum = Math.max(0, currentXp);
	for (let l = 1; l < level; l++) sum += getXpRequiredForLevel(l);
	return sum;
}
var VALID_DECAL_POSITIONS = DECAL_POSITION_OPTIONS.map((p) => p.id);
function normalizeTankCustomizationEntry(tankId, raw) {
	if (!isPlainRecord(raw)) return null;
	const def = TANK_DEFINITIONS[tankId];
	if (!def) return null;
	const decalId = typeof raw.decalId === "string" && raw.decalId in TANK_DECAL_MAP ? raw.decalId : "none";
	const decalPosition = typeof raw.decalPosition === "string" && VALID_DECAL_POSITIONS.includes(raw.decalPosition) ? raw.decalPosition : "turret_top";
	const presetId = typeof raw.presetId === "string" && raw.presetId in TANK_PRESET_MAP ? raw.presetId : null;
	return {
		primaryColor: normalizeHexColor(typeof raw.primaryColor === "string" ? raw.primaryColor : void 0, def.visual.hullPrimary),
		secondaryColor: normalizeHexColor(typeof raw.secondaryColor === "string" ? raw.secondaryColor : void 0, def.visual.hullSecondary),
		turretColor: normalizeHexColor(typeof raw.turretColor === "string" ? raw.turretColor : void 0, def.visual.turretColor),
		barrelColor: normalizeHexColor(typeof raw.barrelColor === "string" ? raw.barrelColor : void 0, def.visual.barrelColor ?? def.visual.hullSecondary),
		decalId,
		decalPosition,
		decalColor: normalizeHexColor(typeof raw.decalColor === "string" ? raw.decalColor : void 0, def.visual.accentColor),
		presetId
	};
}
function normalizeProgression(parsed) {
	const defaults = createDefaultProgression();
	const parsedVersion = typeof parsed.saveVersion === "number" && Number.isFinite(parsed.saveVersion) ? Math.floor(parsed.saveVersion) : 1;
	const rawUnlocked = Array.isArray(parsed.unlockedTanks) ? Array.from(new Set(parsed.unlockedTanks.filter((id) => typeof id === "string" && Boolean(TANK_DEFINITIONS[id]?.implemented)))) : [...defaults.unlockedTanks];
	for (const def of TANK_LIST) if (def.implemented && def.isStarter && !rawUnlocked.includes(def.id)) rawUnlocked.push(def.id);
	if (parsedVersion < 3 && typeof parsed.selectedTank === "string" && TANK_DEFINITIONS[parsed.selectedTank]?.implemented && !rawUnlocked.includes(parsed.selectedTank)) rawUnlocked.push(parsed.selectedTank);
	const selectedTank = typeof parsed.selectedTank === "string" && rawUnlocked.includes(parsed.selectedTank) && TANK_DEFINITIONS[parsed.selectedTank]?.implemented ? parsed.selectedTank : defaults.selectedTank;
	const selectedArena = typeof parsed.selectedArena === "string" && [
		"training_grounds",
		"industrial_zone",
		"wasteland"
	].includes(parsed.selectedArena) ? parsed.selectedArena : defaults.selectedArena;
	const rawName = typeof parsed.playerName === "string" ? parsed.playerName.trim() : "";
	const playerName = rawName.length > 0 ? rawName.slice(0, 20) : defaults.playerName;
	const level = typeof parsed.level === "number" && Number.isFinite(parsed.level) && parsed.level >= 1 ? Math.floor(parsed.level) : defaults.level;
	const xp = typeof parsed.xp === "number" && Number.isFinite(parsed.xp) && parsed.xp >= 0 ? Math.floor(parsed.xp) : defaults.xp;
	const xpToNext = getXpRequiredForLevel(level);
	const totalXpEarned = typeof parsed.totalXpEarned === "number" && Number.isFinite(parsed.totalXpEarned) && parsed.totalXpEarned >= 0 ? Math.floor(parsed.totalXpEarned) : estimateCumulativeXpForLevel(level, xp);
	const claimedMilestoneLevels = Array.isArray(parsed.claimedMilestoneLevels) ? Array.from(new Set(parsed.claimedMilestoneLevels.filter((lvl) => typeof lvl === "number" && Number.isFinite(lvl) && lvl >= 1))).sort((a, b) => a - b) : [];
	const unlockedCosmeticsSet = /* @__PURE__ */ new Set(["default"]);
	if (Array.isArray(parsed.unlockedCosmetics)) {
		for (const item of parsed.unlockedCosmetics) if (typeof item === "string" && item in COSMETIC_DEFINITIONS) unlockedCosmeticsSet.add(item);
	}
	const unlockedCosmetics = Array.from(unlockedCosmeticsSet);
	const equippedCosmetic = typeof parsed.equippedCosmetic === "string" && unlockedCosmetics.includes(parsed.equippedCosmetic) ? parsed.equippedCosmetic : "default";
	const processedMatchIds = Array.isArray(parsed.processedMatchIds) ? parsed.processedMatchIds.filter((id) => typeof id === "string" && id.trim().length > 0).slice(0, 50) : [];
	const processedRewardedAdIds = Array.isArray(parsed.processedRewardedAdIds) ? parsed.processedRewardedAdIds.filter((id) => typeof id === "string" && id.trim().length > 0).slice(0, 50) : [];
	const unlockedPaintSet = new Set(STARTER_PAINT_COLORS);
	if (Array.isArray(parsed.unlockedPaintColors)) {
		for (const hex of parsed.unlockedPaintColors) if (typeof hex === "string" && /^#[0-9a-fA-F]{6}$/.test(hex.trim())) unlockedPaintSet.add(hex.trim().toUpperCase());
	}
	const unlockedDecalSet = new Set(STARTER_DECAL_IDS);
	if (Array.isArray(parsed.unlockedDecals)) {
		for (const id of parsed.unlockedDecals) if (typeof id === "string" && id in TANK_DECAL_MAP) unlockedDecalSet.add(id);
	}
	const unlockedPresetSet = /* @__PURE__ */ new Set();
	if (Array.isArray(parsed.unlockedPresets)) {
		for (const id of parsed.unlockedPresets) if (typeof id === "string" && id in TANK_PRESET_MAP) unlockedPresetSet.add(id);
	}
	const customPaintUnlocked = Boolean(parsed.customPaintUnlocked);
	const tankCustomizations = {};
	if (isPlainRecord(parsed.tankCustomizations)) for (const def of TANK_LIST) {
		const normalizedCustom = normalizeTankCustomizationEntry(def.id, parsed.tankCustomizations[def.id]);
		if (normalizedCustom) tankCustomizations[def.id] = normalizedCustom;
	}
	const scrap = typeof parsed.scrap === "number" && Number.isFinite(parsed.scrap) ? Math.max(0, Math.floor(parsed.scrap)) : 0;
	const totalScrapEarned = typeof parsed.totalScrapEarned === "number" && Number.isFinite(parsed.totalScrapEarned) && parsed.totalScrapEarned >= 0 ? Math.floor(parsed.totalScrapEarned) : scrap;
	const totalScrapSpent = typeof parsed.totalScrapSpent === "number" && Number.isFinite(parsed.totalScrapSpent) && parsed.totalScrapSpent >= 0 ? Math.floor(parsed.totalScrapSpent) : 0;
	const wins = typeof parsed.wins === "number" && Number.isFinite(parsed.wins) ? Math.max(0, Math.floor(parsed.wins)) : 0;
	const rawMatchesPlayed = typeof parsed.matchesPlayed === "number" && Number.isFinite(parsed.matchesPlayed) ? Math.max(0, Math.floor(parsed.matchesPlayed)) : 0;
	const defeats = typeof parsed.defeats === "number" && Number.isFinite(parsed.defeats) && parsed.defeats >= 0 ? Math.floor(parsed.defeats) : Math.max(0, rawMatchesPlayed - wins);
	return {
		saveVersion: 4,
		playerName,
		level,
		xp,
		xpToNext,
		totalXpEarned,
		unlockedTanks: rawUnlocked,
		selectedTank,
		selectedArena,
		scrap,
		totalScrapEarned,
		totalScrapSpent,
		matchesPlayed: Math.max(rawMatchesPlayed, wins + defeats),
		wins,
		defeats,
		totalEliminations: typeof parsed.totalEliminations === "number" && Number.isFinite(parsed.totalEliminations) ? Math.max(0, Math.floor(parsed.totalEliminations)) : 0,
		totalPlaytimeSec: typeof parsed.totalPlaytimeSec === "number" && Number.isFinite(parsed.totalPlaytimeSec) ? Math.max(0, Math.floor(parsed.totalPlaytimeSec)) : 0,
		bestPlacement: typeof parsed.bestPlacement === "number" && Number.isFinite(parsed.bestPlacement) && parsed.bestPlacement >= 1 ? Math.floor(parsed.bestPlacement) : null,
		claimedMilestoneLevels,
		unlockedCosmetics,
		equippedCosmetic,
		unlockedPaintColors: Array.from(unlockedPaintSet),
		unlockedDecals: Array.from(unlockedDecalSet),
		unlockedPresets: Array.from(unlockedPresetSet),
		customPaintUnlocked,
		tankCustomizations,
		processedMatchIds,
		processedRewardedAdIds
	};
}
function tryParseProgressionRaw(raw) {
	if (!raw) return null;
	const parsed = JSON.parse(raw);
	if (!isPlainRecord(parsed)) return null;
	return normalizeProgression(parsed);
}
/**
* Loads player progression safely without ever overwriting stored data on load failure.
*/
function loadProgressionSafe(storage = getDefaultStorage()) {
	if (!storage) return {
		progression: createDefaultProgression(),
		status: "storage_error"
	};
	let rawPrimary = null;
	try {
		rawPrimary = storage.getItem(PROGRESSION_KEY);
	} catch {
		return {
			progression: createDefaultProgression(),
			status: "storage_error"
		};
	}
	if (rawPrimary === null) {
		try {
			const backup = tryParseProgressionRaw(storage.getItem(PROGRESSION_BACKUP_KEY));
			if (backup) return {
				progression: backup,
				status: "recovered_backup"
			};
		} catch {}
		return {
			progression: createDefaultProgression(),
			status: "new"
		};
	}
	try {
		const primary = tryParseProgressionRaw(rawPrimary);
		if (primary) return {
			progression: primary,
			status: "loaded"
		};
	} catch {}
	try {
		const backup = tryParseProgressionRaw(storage.getItem(PROGRESSION_BACKUP_KEY));
		if (backup) return {
			progression: backup,
			status: "recovered_backup"
		};
	} catch {}
	return {
		progression: createDefaultProgression(),
		status: "corrupt_fallback"
	};
}
function loadProgression(storage = getDefaultStorage()) {
	return loadProgressionSafe(storage).progression;
}
function saveProgression(progression, storage = getDefaultStorage()) {
	if (!storage) {
		emitSaveEvent({
			status: "error",
			scope: "progression",
			timestampMs: Date.now()
		});
		return false;
	}
	try {
		const normalized = normalizeProgression({
			...progression,
			saveVersion: 4,
			xpToNext: getXpRequiredForLevel(progression.level)
		});
		const serialized = JSON.stringify(normalized);
		JSON.parse(serialized);
		storage.setItem(PROGRESSION_KEY, serialized);
		try {
			storage.setItem(PROGRESSION_BACKUP_KEY, serialized);
		} catch {}
		if (storage !== sessionFallbackStorage) platformBridge.syncSaveKey(PROGRESSION_KEY, serialized);
		emitSaveEvent({
			status: "saved",
			scope: "progression",
			timestampMs: Date.now()
		});
		return true;
	} catch {
		emitSaveEvent({
			status: "error",
			scope: "progression",
			timestampMs: Date.now()
		});
		return false;
	}
}
function applyMatchResultToProgression(prev, result, storage = getDefaultStorage(), overrides) {
	const { nextProgression, summary } = applyMatchProgression(prev, result, overrides);
	if (!summary.alreadyProcessed) saveProgression(nextProgression, storage);
	return {
		progression: nextProgression,
		summary
	};
}
function updatePlayerDisplayName(prev, rawName, storage = getDefaultStorage()) {
	const trimmed = rawName.trim().slice(0, 20);
	if (!trimmed) return prev;
	const next = {
		...prev,
		playerName: trimmed
	};
	saveProgression(next, storage);
	return next;
}
function equipPlayerCosmetic(prev, cosmeticId, storage = getDefaultStorage()) {
	if (cosmeticId !== "default" && !prev.unlockedCosmetics.includes(cosmeticId)) return prev;
	const next = {
		...prev,
		equippedCosmetic: cosmeticId
	};
	saveProgression(next, storage);
	return next;
}
function buyTankWithScrap(prev, tankId, storage = getDefaultStorage()) {
	const outcome = purchaseTankWithScrap(prev, tankId);
	if (outcome.success) saveProgression(outcome.nextProgression, storage);
	return outcome;
}
function buyPaintColorWithScrap(prev, hex, storage = getDefaultStorage()) {
	const outcome = purchasePaintColorWithScrap(prev, hex);
	if (outcome.success) saveProgression(outcome.nextProgression, storage);
	return outcome;
}
function buyCustomPaintStudioWithScrap(prev, storage = getDefaultStorage()) {
	const outcome = purchaseCustomPaintStudioWithScrap(prev);
	if (outcome.success) saveProgression(outcome.nextProgression, storage);
	return outcome;
}
function buyDecalWithScrap(prev, decalId, storage = getDefaultStorage()) {
	const outcome = purchaseDecalWithScrap(prev, decalId);
	if (outcome.success) saveProgression(outcome.nextProgression, storage);
	return outcome;
}
function buyPresetWithScrap(prev, presetId, storage = getDefaultStorage()) {
	const outcome = purchasePresetWithScrap(prev, presetId);
	if (outcome.success) saveProgression(outcome.nextProgression, storage);
	return outcome;
}
function buySpecialCosmeticWithScrap(prev, cosmeticId, storage = getDefaultStorage()) {
	const outcome = purchaseSpecialCosmeticWithScrap(prev, cosmeticId);
	if (outcome.success) saveProgression(outcome.nextProgression, storage);
	return outcome;
}
function grantRewardedAdScrap(prev, grantId, amount = 35, storage = getDefaultStorage()) {
	const res = applyRewardedAdScrap(prev, grantId, amount);
	if (res.granted) saveProgression(res.nextProgression, storage);
	return res;
}
function saveTankCustomization(prev, tankId, customization, storage = getDefaultStorage()) {
	if (!TANK_DEFINITIONS[tankId]?.implemented) return prev;
	const next = {
		...prev,
		tankCustomizations: {
			...prev.tankCustomizations,
			[tankId]: { ...customization }
		}
	};
	saveProgression(next, storage);
	return next;
}
function resetSavedTankCustomization(prev, tankId, storage = getDefaultStorage()) {
	if (!(tankId in prev.tankCustomizations)) return prev;
	const updated = { ...prev.tankCustomizations };
	delete updated[tankId];
	const next = {
		...prev,
		tankCustomizations: updated
	};
	saveProgression(next, storage);
	return next;
}
function loadSettings(storage = getDefaultStorage()) {
	if (!storage) return { ...DEFAULT_SETTINGS };
	try {
		const raw = storage.getItem(SETTINGS_KEY);
		if (!raw) return { ...DEFAULT_SETTINGS };
		const parsed = JSON.parse(raw);
		if (!isPlainRecord(parsed)) return { ...DEFAULT_SETTINGS };
		const graphicsQuality = parsed.graphicsQuality && [
			"low",
			"medium",
			"high"
		].includes(parsed.graphicsQuality) ? parsed.graphicsQuality : parsed.lowDetailMode === true ? "low" : DEFAULT_SETTINGS.graphicsQuality;
		return {
			soundEnabled: typeof parsed.soundEnabled === "boolean" ? parsed.soundEnabled : DEFAULT_SETTINGS.soundEnabled,
			soundVolume: typeof parsed.soundVolume === "number" ? Math.min(1, Math.max(0, parsed.soundVolume)) : DEFAULT_SETTINGS.soundVolume,
			musicEnabled: typeof parsed.musicEnabled === "boolean" ? parsed.musicEnabled : DEFAULT_SETTINGS.musicEnabled,
			musicVolume: typeof parsed.musicVolume === "number" ? Math.min(1, Math.max(0, parsed.musicVolume)) : DEFAULT_SETTINGS.musicVolume,
			graphicsQuality,
			screenShakeEnabled: typeof parsed.screenShakeEnabled === "boolean" ? parsed.screenShakeEnabled : DEFAULT_SETTINGS.screenShakeEnabled,
			vibrationEnabled: typeof parsed.vibrationEnabled === "boolean" ? parsed.vibrationEnabled : DEFAULT_SETTINGS.vibrationEnabled,
			controlSensitivity: typeof parsed.controlSensitivity === "number" ? Math.min(1.5, Math.max(.6, parsed.controlSensitivity)) : DEFAULT_SETTINGS.controlSensitivity,
			showTouchControls: parsed.showTouchControls === "auto" || parsed.showTouchControls === "always" ? parsed.showTouchControls : DEFAULT_SETTINGS.showTouchControls,
			autoFireOnAim: typeof parsed.autoFireOnAim === "boolean" ? parsed.autoFireOnAim : DEFAULT_SETTINGS.autoFireOnAim,
			lowDetailMode: graphicsQuality === "low",
			matchDurationSec: typeof parsed.matchDurationSec === "number" && parsed.matchDurationSec >= 60 && parsed.matchDurationSec <= 300 ? parsed.matchDurationSec : DEFAULT_SETTINGS.matchDurationSec,
			landscapePromptEnabled: typeof parsed.landscapePromptEnabled === "boolean" ? parsed.landscapePromptEnabled : DEFAULT_SETTINGS.landscapePromptEnabled
		};
	} catch {
		return { ...DEFAULT_SETTINGS };
	}
}
function saveSettings(settings, storage = getDefaultStorage()) {
	if (!storage) return;
	try {
		const normalized = {
			...settings,
			lowDetailMode: settings.graphicsQuality === "low"
		};
		const serialized = JSON.stringify(normalized);
		storage.setItem(SETTINGS_KEY, serialized);
		if (storage !== sessionFallbackStorage) platformBridge.syncSaveKey(SETTINGS_KEY, serialized);
		emitSaveEvent({
			status: "saved",
			scope: "settings",
			timestampMs: Date.now()
		});
	} catch {
		emitSaveEvent({
			status: "error",
			scope: "settings",
			timestampMs: Date.now()
		});
	}
}
function resetSettingsToDefault(storage = getDefaultStorage()) {
	const defaults = { ...DEFAULT_SETTINGS };
	saveSettings(defaults, storage);
	return defaults;
}
var VALID_ARENA_IDS = [
	"training_grounds",
	"industrial_zone",
	"wasteland"
];
function normalizePeriodTracking(raw) {
	if (!isPlainRecord(raw)) return createEmptyPeriodTracking();
	return {
		uniqueTanks: Array.isArray(raw.uniqueTanks) ? Array.from(new Set(raw.uniqueTanks.filter((id) => typeof id === "string" && Boolean(TANK_DEFINITIONS[id]?.implemented)))) : [],
		uniqueArenas: Array.isArray(raw.uniqueArenas) ? Array.from(new Set(raw.uniqueArenas.filter((id) => typeof id === "string" && VALID_ARENA_IDS.includes(id)))) : []
	};
}
function normalizePermanentTracking(raw, seedProgression) {
	const base = createEmptyPermanentTracking();
	if (!isPlainRecord(raw)) {
		if (seedProgression) {
			base.eliminations = Math.max(0, seedProgression.totalEliminations ?? 0);
			base.wins = Math.max(0, seedProgression.wins ?? 0);
			base.matchesCompleted = Math.max(0, seedProgression.matchesPlayed ?? 0);
		}
		return base;
	}
	const readCount = (v, fallback = 0) => typeof v === "number" && Number.isFinite(v) && v >= 0 ? Math.floor(v) : fallback;
	const uniqueTanks = Array.isArray(raw.uniqueTanks) ? Array.from(new Set(raw.uniqueTanks.filter((id) => typeof id === "string" && Boolean(TANK_DEFINITIONS[id]?.implemented)))) : [];
	const uniqueArenas = Array.isArray(raw.uniqueArenas) ? Array.from(new Set(raw.uniqueArenas.filter((id) => typeof id === "string" && VALID_ARENA_IDS.includes(id)))) : [];
	return {
		matchesStarted: readCount(raw.matchesStarted),
		matchesCompleted: readCount(raw.matchesCompleted, seedProgression?.matchesPlayed ?? 0),
		wins: readCount(raw.wins, seedProgression?.wins ?? 0),
		eliminations: readCount(raw.eliminations, seedProgression?.totalEliminations ?? 0),
		powerupsCollected: readCount(raw.powerupsCollected),
		abilitiesActivated: readCount(raw.abilitiesActivated),
		obstaclesDestroyed: readCount(raw.obstaclesDestroyed),
		uniqueTanks,
		uniqueArenas
	};
}
function normalizeMissionEntries(raw, scope, fallbackEntries) {
	if (!Array.isArray(raw)) return fallbackEntries;
	const parsed = [];
	const seen = /* @__PURE__ */ new Set();
	for (const item of raw) {
		if (!isPlainRecord(item) || typeof item.missionId !== "string") continue;
		const def = ALL_MISSION_DEFINITIONS[item.missionId];
		if (!def || def.scope !== scope || seen.has(def.id)) continue;
		seen.add(def.id);
		const progress = typeof item.progress === "number" && Number.isFinite(item.progress) && item.progress >= 0 ? Math.min(def.target, Math.floor(item.progress)) : 0;
		const completed = Boolean(item.completed) || progress >= def.target;
		const claimed = completed && Boolean(item.claimed);
		const claimedAtMs = claimed && typeof item.claimedAtMs === "number" && Number.isFinite(item.claimedAtMs) ? item.claimedAtMs : null;
		parsed.push({
			missionId: def.id,
			progress: completed ? def.target : progress,
			completed,
			claimed,
			claimedAtMs
		});
	}
	return parsed.length > 0 ? parsed : fallbackEntries;
}
function normalizeMissionsState(parsed, nowMs, options, seedProgression) {
	const fresh = createInitialMissionsState(nowMs, options, seedProgression);
	const dailyPeriodKey = typeof parsed.dailyPeriodKey === "string" && parsed.dailyPeriodKey.trim().length > 0 ? parsed.dailyPeriodKey.trim() : fresh.dailyPeriodKey;
	const weeklyPeriodKey = typeof parsed.weeklyPeriodKey === "string" && parsed.weeklyPeriodKey.trim().length > 0 ? parsed.weeklyPeriodKey.trim() : fresh.weeklyPeriodKey;
	const dailyMissions = normalizeMissionEntries(parsed.dailyMissions, "daily", fresh.dailyMissions);
	const weeklyMissions = normalizeMissionEntries(parsed.weeklyMissions, "weekly", fresh.weeklyMissions);
	const rawAch = isPlainRecord(parsed.achievements) ? parsed.achievements : {};
	const fallbackAch = createInitialAchievementsRecord(ACHIEVEMENT_DEFINITIONS, seedProgression);
	const achievements = {};
	for (const def of ACHIEVEMENT_DEFINITIONS) {
		const entry = rawAch[def.id];
		if (!isPlainRecord(entry)) {
			achievements[def.id] = fallbackAch[def.id];
			continue;
		}
		const progress = typeof entry.progress === "number" && Number.isFinite(entry.progress) && entry.progress >= 0 ? Math.min(def.target, Math.floor(entry.progress)) : 0;
		const completed = Boolean(entry.completed) || progress >= def.target;
		const claimed = completed && Boolean(entry.claimed);
		achievements[def.id] = {
			achievementId: def.id,
			progress: completed ? def.target : progress,
			completed,
			unlockedAtMs: completed && typeof entry.unlockedAtMs === "number" && Number.isFinite(entry.unlockedAtMs) ? entry.unlockedAtMs : completed ? nowMs : null,
			claimed,
			claimedAtMs: claimed && typeof entry.claimedAtMs === "number" && Number.isFinite(entry.claimedAtMs) ? entry.claimedAtMs : null
		};
	}
	const processedEventIds = Array.isArray(parsed.processedEventIds) ? parsed.processedEventIds.filter((id) => typeof id === "string" && id.trim().length > 0).slice(0, 250) : [];
	return ensureMissionPeriodsCurrent({
		saveVersion: 1,
		dailyPeriodKey,
		dailyMissions,
		dailyTracking: normalizePeriodTracking(parsed.dailyTracking),
		weeklyPeriodKey,
		weeklyMissions,
		weeklyTracking: normalizePeriodTracking(parsed.weeklyTracking),
		achievements,
		permanentTracking: normalizePermanentTracking(parsed.permanentTracking, seedProgression),
		processedEventIds
	}, nowMs, options).state;
}
function tryParseMissionsRaw(raw, nowMs, options, seedProgression) {
	if (!raw) return null;
	const parsed = JSON.parse(raw);
	if (!isPlainRecord(parsed)) return null;
	return normalizeMissionsState(parsed, nowMs, options, seedProgression);
}
/**
* Loads missions & achievements safely without overwriting corrupt storage data.
* Automatically refreshes expired daily/weekly missions while keeping permanent achievements intact.
*/
function loadMissionsSafe(storage = getDefaultStorage(), nowMs = Date.now(), seedProgression, options = {}) {
	if (!storage) return {
		missions: createInitialMissionsState(nowMs, options, seedProgression),
		status: "storage_error"
	};
	let rawPrimary = null;
	try {
		rawPrimary = storage.getItem(MISSIONS_KEY);
	} catch {
		return {
			missions: createInitialMissionsState(nowMs, options, seedProgression),
			status: "storage_error"
		};
	}
	if (rawPrimary === null) {
		try {
			const backup = tryParseMissionsRaw(storage.getItem(MISSIONS_BACKUP_KEY), nowMs, options, seedProgression);
			if (backup) return {
				missions: backup,
				status: "recovered_backup"
			};
		} catch {}
		return {
			missions: createInitialMissionsState(nowMs, options, seedProgression),
			status: "new"
		};
	}
	try {
		const primary = tryParseMissionsRaw(rawPrimary, nowMs, options, seedProgression);
		if (primary) return {
			missions: primary,
			status: "loaded"
		};
	} catch {}
	try {
		const backup = tryParseMissionsRaw(storage.getItem(MISSIONS_BACKUP_KEY), nowMs, options, seedProgression);
		if (backup) return {
			missions: backup,
			status: "recovered_backup"
		};
	} catch {}
	return {
		missions: createInitialMissionsState(nowMs, options, seedProgression),
		status: "corrupt_fallback"
	};
}
function loadMissions(storage = getDefaultStorage(), nowMs = Date.now(), seedProgression, options = {}) {
	return loadMissionsSafe(storage, nowMs, seedProgression, options).missions;
}
function saveMissions(missions, storage = getDefaultStorage()) {
	if (!storage) {
		emitSaveEvent({
			status: "error",
			scope: "missions",
			timestampMs: Date.now()
		});
		return false;
	}
	try {
		const payload = {
			...missions,
			saveVersion: 1
		};
		const serialized = JSON.stringify(payload);
		JSON.parse(serialized);
		storage.setItem(MISSIONS_KEY, serialized);
		try {
			storage.setItem(MISSIONS_BACKUP_KEY, serialized);
		} catch {}
		if (storage !== sessionFallbackStorage) platformBridge.syncSaveKey(MISSIONS_KEY, serialized);
		emitSaveEvent({
			status: "saved",
			scope: "missions",
			timestampMs: Date.now()
		});
		return true;
	} catch {
		emitSaveEvent({
			status: "error",
			scope: "missions",
			timestampMs: Date.now()
		});
		return false;
	}
}
/**
* Hydrates local storage from Playgama platform storage if running inside Playgama
* and local save keys do not yet exist (never overwrites existing local progress).
*/
async function hydrateFromPlatformStorage(storage = getDefaultStorage()) {
	if (!storage || !platformBridge.supportsPlatformStorage) return {
		progression: null,
		missions: null
	};
	const remote = await platformBridge.loadSaveKeys([PROGRESSION_KEY, MISSIONS_KEY]);
	let hydratedProgression = null;
	let hydratedMissions = null;
	if (!storage.getItem("tankbound_arena_progression_v1") && remote["tankbound_arena_progression_v1"]) {
		const parsed = tryParseProgressionRaw(remote[PROGRESSION_KEY]);
		if (parsed) {
			saveProgression(parsed, storage);
			hydratedProgression = parsed;
		}
	}
	if (!storage.getItem("tankbound_arena_missions_v1") && remote["tankbound_arena_missions_v1"]) {
		const seed = hydratedProgression ?? loadProgression(storage);
		const parsedMissions = tryParseMissionsRaw(remote[MISSIONS_KEY], Date.now(), {}, seed);
		if (parsedMissions) {
			saveMissions(parsedMissions, storage);
			hydratedMissions = parsedMissions;
		}
	}
	return {
		progression: hydratedProgression,
		missions: hydratedMissions
	};
}
function resetAllLocalData(storage = getDefaultStorage()) {
	if (storage) try {
		storage.removeItem(PROGRESSION_KEY);
		storage.removeItem(PROGRESSION_BACKUP_KEY);
		storage.removeItem(MISSIONS_KEY);
		storage.removeItem(MISSIONS_BACKUP_KEY);
		storage.removeItem(SETTINGS_KEY);
	} catch {}
	return {
		progression: createDefaultProgression(),
		settings: { ...DEFAULT_SETTINGS },
		missions: createInitialMissionsState()
	};
}
// src/game/GameBridge.ts
var GameBridgeBus = class {
	constructor() {
		this.input = {
			moveX: 0,
			moveY: 0,
			aimX: 0,
			aimY: 0,
			aimActive: false,
			mouseWorldX: 0,
			mouseWorldY: 0,
			mouseAimActive: false,
			firing: false,
			firePressed: false,
			abilityPressed: false,
			reloadPressed: false,
			deployMinePressed: false
		};
		this.hudListeners = /* @__PURE__ */ new Set();
		this.matchEndListeners = /* @__PURE__ */ new Set();
		this.commandListeners = /* @__PURE__ */ new Set();
		this.settingsListeners = /* @__PURE__ */ new Set();
		this.gameplayEventListeners = /* @__PURE__ */ new Set();
		this.lastHudSnapshot = null;
		this.activeLaunchConfig = null;
	}
	setLaunchConfig(config) {
		this.activeLaunchConfig = config;
	}
	getLaunchConfig() {
		return this.activeLaunchConfig;
	}
	resetInput() {
		this.input.moveX = 0;
		this.input.moveY = 0;
		this.input.aimX = 0;
		this.input.aimY = 0;
		this.input.aimActive = false;
		this.input.mouseAimActive = false;
		this.input.firing = false;
		this.input.firePressed = false;
		this.input.abilityPressed = false;
		this.input.reloadPressed = false;
		this.input.deployMinePressed = false;
	}
	getLastHudSnapshot() {
		return this.lastHudSnapshot;
	}
	clearLastHudSnapshot() {
		this.lastHudSnapshot = null;
	}
	onHudUpdate(cb) {
		this.hudListeners.add(cb);
		if (this.lastHudSnapshot) cb(this.lastHudSnapshot);
		return () => this.hudListeners.delete(cb);
	}
	emitHudUpdate(snapshot) {
		this.lastHudSnapshot = snapshot;
		this.hudListeners.forEach((cb) => cb(snapshot));
	}
	onMatchEnd(cb) {
		this.matchEndListeners.add(cb);
		return () => this.matchEndListeners.delete(cb);
	}
	emitMatchEnd(result) {
		this.matchEndListeners.forEach((cb) => cb(result));
	}
	onCommand(cb) {
		this.commandListeners.add(cb);
		return () => this.commandListeners.delete(cb);
	}
	sendCommand(cmd) {
		this.commandListeners.forEach((cb) => cb(cmd));
	}
	onSettingsChange(cb) {
		this.settingsListeners.add(cb);
		return () => this.settingsListeners.delete(cb);
	}
	emitSettingsChange(settings) {
		this.settingsListeners.forEach((cb) => cb(settings));
	}
	onGameplayEvent(cb) {
		this.gameplayEventListeners.add(cb);
		return () => this.gameplayEventListeners.delete(cb);
	}
	emitGameplayEvent(event) {
		this.gameplayEventListeners.forEach((cb) => cb(event));
	}
};
var gameBridge = new GameBridgeBus();
// src/components/TankDecalRenderer.ts
/**
* Shared placement solver used by both SVG preview (unit radius ~55) and Phaser Canvas2D textures.
* `coordScale` converts from canonical SVG hull/turret space into canvas texture space (~0.92).
*/
function getDecalPlacements(position, silhouette, layer, coordScale = 1) {
	if (position === "turret_top") {
		if (layer !== "turret") return [];
		const scale = silhouette === "heavy" ? 1.05 : silhouette === "sleek" ? .82 : .94;
		return [{
			x: 2.2 * coordScale,
			y: 1.4 * coordScale,
			scale: scale * coordScale,
			rotationDeg: 0
		}];
	}
	if (layer !== "hull") return [];
	if (position === "hull_rear") {
		const rx = silhouette === "heavy" ? -20.5 : silhouette === "angular" ? -13 : silhouette === "long_barrel" ? -18 : -18.5;
		const scale = silhouette === "sleek" ? .72 : silhouette === "heavy" ? .88 : .78;
		return [{
			x: rx * coordScale,
			y: 0,
			scale: scale * coordScale,
			rotationDeg: 0
		}];
	}
	if (position === "hull_front") {
		const fx = silhouette === "heavy" ? 15 : silhouette === "angular" ? 9 : silhouette === "sleek" ? 14 : 14;
		const fy = silhouette === "heavy" ? 11.5 : silhouette === "sleek" ? 7.5 : silhouette === "angular" ? 9.5 : 9.5;
		const scale = silhouette === "sleek" ? .56 : silhouette === "heavy" ? .68 : .62;
		return [{
			x: fx * coordScale,
			y: -fy * coordScale,
			scale: scale * coordScale,
			rotationDeg: 0
		}, {
			x: fx * coordScale,
			y: fy * coordScale,
			scale: scale * coordScale,
			rotationDeg: 0
		}];
	}
	const lx = silhouette === "heavy" ? -16.5 : silhouette === "angular" ? -11 : -14.5;
	const ly = silhouette === "heavy" ? 12 : silhouette === "sleek" ? 8.2 : 10.5;
	const scale = silhouette === "sleek" ? .54 : silhouette === "heavy" ? .68 : .6;
	return [{
		x: lx * coordScale,
		y: -ly * coordScale,
		scale: scale * coordScale,
		rotationDeg: -90
	}, {
		x: lx * coordScale,
		y: ly * coordScale,
		scale: scale * coordScale,
		rotationDeg: 90
	}];
}
function drawStarPath(ctx, rOuter, rInner) {
	ctx.beginPath();
	for (let i = 0; i < 10; i++) {
		const angle = -Math.PI / 2 + i * Math.PI / 5;
		const r = i % 2 === 0 ? rOuter : rInner;
		const px = Math.cos(angle) * r;
		const py = Math.sin(angle) * r;
		if (i === 0) ctx.moveTo(px, py);
		else ctx.lineTo(px, py);
	}
	ctx.closePath();
}
function drawCanvasDecal(ctx, centerX, centerY, decalId, decalColor, position, silhouette, layer, coordScale = .92) {
	if (decalId === "none") return;
	const placements = getDecalPlacements(position, silhouette, layer, coordScale);
	if (placements.length === 0) return;
	for (const p of placements) {
		ctx.save();
		ctx.translate(centerX + p.x, centerY + p.y);
		ctx.rotate(p.rotationDeg * Math.PI / 180);
		ctx.scale(p.scale, p.scale);
		ctx.fillStyle = decalColor;
		ctx.strokeStyle = decalColor;
		ctx.lineCap = "round";
		ctx.lineJoin = "round";
		switch (decalId) {
			case "chevron":
				ctx.lineWidth = 2.4;
				ctx.beginPath();
				ctx.moveTo(-4, -5);
				ctx.lineTo(4, 0);
				ctx.lineTo(-4, 5);
				ctx.stroke();
				ctx.beginPath();
				ctx.moveTo(-7.5, -3.8);
				ctx.lineTo(-1, 0);
				ctx.lineTo(-7.5, 3.8);
				ctx.stroke();
				break;
			case "iron_crosshair":
				ctx.lineWidth = 1.8;
				ctx.beginPath();
				ctx.arc(0, 0, 5.2, 0, Math.PI * 2);
				ctx.stroke();
				ctx.beginPath();
				ctx.moveTo(-7.2, 0);
				ctx.lineTo(-2.4, 0);
				ctx.moveTo(2.4, 0);
				ctx.lineTo(7.2, 0);
				ctx.moveTo(0, -7.2);
				ctx.lineTo(0, -2.4);
				ctx.moveTo(0, 2.4);
				ctx.lineTo(0, 7.2);
				ctx.stroke();
				ctx.beginPath();
				ctx.arc(0, 0, 1.4, 0, Math.PI * 2);
				ctx.fill();
				break;
			case "shield_crest":
				ctx.beginPath();
				ctx.moveTo(-5.2, -5.5);
				ctx.lineTo(5.2, -5.5);
				ctx.lineTo(5.2, .5);
				ctx.lineTo(0, 6.5);
				ctx.lineTo(-5.2, .5);
				ctx.closePath();
				ctx.lineWidth = 1.8;
				ctx.stroke();
				ctx.beginPath();
				ctx.moveTo(-2.5, -3);
				ctx.lineTo(2.5, -3);
				ctx.lineTo(0, 3);
				ctx.closePath();
				ctx.fill();
				break;
			case "command_star":
				drawStarPath(ctx, 6.8, 2.9);
				ctx.fill();
				break;
			case "num_01":
			case "num_07":
			case "num_42":
			case "num_99": {
				const text = decalId.slice(4);
				ctx.font = "800 9.5px \"Barlow Condensed\", sans-serif";
				ctx.textAlign = "center";
				ctx.textBaseline = "middle";
				ctx.lineWidth = 2.4;
				ctx.strokeStyle = "#161815";
				ctx.strokeText(text, 0, .5);
				ctx.fillStyle = decalColor;
				ctx.fillText(text, 0, .5);
				break;
			}
			case "twin_stripes":
				ctx.fillRect(-6.5, -4, 13, 2.6);
				ctx.fillRect(-6.5, 1.4, 13, 2.6);
				break;
			case "hazard_stripes":
				ctx.lineWidth = 2.5;
				for (const ox of [
					-4.5,
					0,
					4.5
				]) {
					ctx.beginPath();
					ctx.moveTo(ox - 2, -4.5);
					ctx.lineTo(ox + 2, 4.5);
					ctx.stroke();
				}
				break;
			case "apex_diamond":
				ctx.beginPath();
				ctx.moveTo(0, -6.5);
				ctx.lineTo(6.5, 0);
				ctx.lineTo(0, 6.5);
				ctx.lineTo(-6.5, 0);
				ctx.closePath();
				ctx.lineWidth = 1.8;
				ctx.stroke();
				ctx.beginPath();
				ctx.moveTo(0, -3);
				ctx.lineTo(3, 0);
				ctx.lineTo(0, 3);
				ctx.lineTo(-3, 0);
				ctx.closePath();
				ctx.fill();
				break;
			case "hex_core":
				ctx.beginPath();
				for (let i = 0; i < 6; i++) {
					const a = i * Math.PI / 3;
					const hx = Math.cos(a) * 6;
					const hy = Math.sin(a) * 6;
					if (i === 0) ctx.moveTo(hx, hy);
					else ctx.lineTo(hx, hy);
				}
				ctx.closePath();
				ctx.lineWidth = 1.8;
				ctx.stroke();
				ctx.beginPath();
				ctx.arc(0, 0, 2.2, 0, Math.PI * 2);
				ctx.fill();
				break;
			case "thunder_bolt":
				ctx.beginPath();
				ctx.moveTo(1.8, -6.8);
				ctx.lineTo(-4.2, .5);
				ctx.lineTo(-.3, .5);
				ctx.lineTo(-2.2, 6.8);
				ctx.lineTo(4.2, -.8);
				ctx.lineTo(.2, -.8);
				ctx.closePath();
				ctx.fill();
				break;
			case "apex_crown":
				ctx.beginPath();
				ctx.moveTo(-5.8, 4.5);
				ctx.lineTo(-5.8, -3.5);
				ctx.lineTo(-2.5, .5);
				ctx.lineTo(0, -5);
				ctx.lineTo(2.5, .5);
				ctx.lineTo(5.8, -3.5);
				ctx.lineTo(5.8, 4.5);
				ctx.closePath();
				ctx.fill();
				break;
			case "winged_crest":
				ctx.beginPath();
				ctx.moveTo(-7, -3.5);
				ctx.lineTo(-1.5, -1);
				ctx.lineTo(0, -5);
				ctx.lineTo(1.5, -1);
				ctx.lineTo(7, -3.5);
				ctx.lineTo(4.5, 3);
				ctx.lineTo(0, 5.2);
				ctx.lineTo(-4.5, 3);
				ctx.closePath();
				ctx.fill();
		}
		ctx.restore();
	}
}
// src/data/powerups.ts
var POWERUP_SPAWN_CONFIG = {
	maxActive: 3,
	spawnIntervalSec: 4.5,
	initialSpawnDelaySec: 2,
	despawnDurationSec: 22,
	minPickupSeparation: 360,
	spawnPointClearance: 95,
	obstacleClearance: 36,
	tankClearance: 60,
	collectionPadding: 22
};
var MINE_SYSTEM_CONFIG = {
	maxActiveGlobal: 10,
	maxActivePerTank: 3,
	maxCarriedCharges: 3,
	durationSec: 24,
	armDelaySec: .75,
	damage: 45,
	triggerPadding: 16,
	deployCooldownSec: .55
};
var MAX_TOTAL_SPEED_MULTIPLIER = 1.8;
var MAX_TOTAL_FIRERATE_MULTIPLIER = 2.3;
var POWERUP_DEFINITIONS = {
	repair_kit: {
		id: "repair_kit",
		name: "Repair Kit",
		shortLabel: "+HP",
		description: "Restores 45% of missing hull health (min 25 HP).",
		durationSec: 0,
		color: "#22C55E",
		accent: "#DCFCE7",
		duplicatePolicy: "instant",
		healMissingRatio: .45,
		healMinAmount: 25
	},
	rapid_fire: {
		id: "rapid_fire",
		name: "Rapid Fire",
		shortLabel: "ROF",
		description: "Increases fire rate by 45% for 8s (respects ammo & reload).",
		durationSec: 8,
		color: "#F59E0B",
		accent: "#FEF3C7",
		duplicatePolicy: "refresh",
		fireRateMultiplier: 1.45
	},
	heavy_shell: {
		id: "heavy_shell",
		name: "Heavy Shell",
		shortLabel: "DMG",
		description: "Boosts normal projectile damage by 45% for 8s.",
		durationSec: 8,
		color: "#EF4444",
		accent: "#FEE2E2",
		duplicatePolicy: "refresh",
		damageMultiplier: 1.45
	},
	speed_boost: {
		id: "speed_boost",
		name: "Speed Boost",
		shortLabel: "SPD",
		description: "Increases tank movement speed by 35% for 8s.",
		durationSec: 8,
		color: "#06B6D4",
		accent: "#CFFAFE",
		duplicatePolicy: "refresh",
		speedBonusMultiplier: .35
	},
	shield: {
		id: "shield",
		name: "Shield",
		shortLabel: "SHD",
		description: "Grants a 50 HP projectile barrier for 8s.",
		durationSec: 8,
		color: "#3B82F6",
		accent: "#DBEAFE",
		duplicatePolicy: "refresh",
		shieldAmount: 50
	},
	multi_shot: {
		id: "multi_shot",
		name: "Multi-Shot",
		shortLabel: "3X",
		description: "Fires 3-way spread projectiles for 8s.",
		durationSec: 8,
		color: "#EC4899",
		accent: "#FCE7F3",
		duplicatePolicy: "refresh",
		multiShotCount: 3,
		multiShotSpreadRad: .16
	},
	piercing_shell: {
		id: "piercing_shell",
		name: "Piercing Shell",
		shortLabel: "PRC",
		description: "Shells pierce through 1 target or destructible wall for 8s.",
		durationSec: 8,
		color: "#A855F7",
		accent: "#F3E8FF",
		duplicatePolicy: "refresh",
		pierceCount: 1
	},
	radar: {
		id: "radar",
		name: "Radar",
		shortLabel: "RDR",
		description: "Reveals nearby opponents (including concealed) for 10s.",
		durationSec: 10,
		color: "#10B981",
		accent: "#D1FAE5",
		duplicatePolicy: "refresh",
		radarRadius: 880
	},
	cooldown_boost: {
		id: "cooldown_boost",
		name: "Cooldown Boost",
		shortLabel: "CDR",
		description: "Ability recharges 2x faster for 10s.",
		durationSec: 10,
		color: "#EAB308",
		accent: "#FEF9C3",
		duplicatePolicy: "refresh",
		cooldownRecoveryMultiplier: 2
	},
	mine_kit: {
		id: "mine_kit",
		name: "Mine Kit",
		shortLabel: "MINE",
		description: "Grants 2 proximity mines (up to 3 held). Deploy with F/Q or HUD button.",
		durationSec: 0,
		color: "#F97316",
		accent: "#FFEDD5",
		duplicatePolicy: "stack_capped",
		minesGranted: 2,
		maxMineCharges: MINE_SYSTEM_CONFIG.maxCarriedCharges
	}
};
var POWERUP_IDS = Object.keys(POWERUP_DEFINITIONS);
// src/assets/ProceduralTextureGenerator.ts
var INK = "#161815";
function drawInkRect(ctx, x, y, w, h, fill, radius = 4, lineWidth = 3) {
	ctx.beginPath();
	ctx.roundRect(x, y, w, h, radius);
	ctx.fillStyle = fill;
	ctx.fill();
	ctx.lineWidth = lineWidth;
	ctx.strokeStyle = INK;
	ctx.stroke();
}
function makeCanvasTexture(scene, key, width, height, draw) {
	if (scene.textures.exists(key)) return;
	const tex = scene.textures.createCanvas(key, width, height);
	if (!tex) return;
	const ctx = tex.getContext();
	ctx.clearRect(0, 0, width, height);
	ctx.lineJoin = "round";
	ctx.lineCap = "round";
	draw(ctx, width, height);
	tex.refresh();
}
function drawTankHull(ctx, tank, visualOverride, customization) {
	const visual = visualOverride ?? tank.visual;
	const cx = 40;
	const cy = 40;
	ctx.fillStyle = "rgba(0,0,0,0.26)";
	ctx.beginPath();
	ctx.roundRect(cx - (visual.silhouette === "heavy" ? 25 : 23), cy - (visual.silhouette === "heavy" ? 22 : 19), visual.silhouette === "heavy" ? 54 : 50, visual.silhouette === "heavy" ? 48 : 42, 8);
	ctx.fill();
	const treadW = visual.silhouette === "heavy" ? 56 : visual.silhouette === "sleek" ? 46 : visual.silhouette === "long_barrel" ? 52 : 50;
	const treadH = visual.silhouette === "heavy" ? 12.5 : visual.silhouette === "sleek" ? 8 : 9.5;
	const treadOffset = visual.silhouette === "heavy" ? 17.5 : visual.silhouette === "sleek" ? 14 : 15;
	for (const side of [-1, 1]) {
		const ty = cy + side * treadOffset - treadH / 2;
		drawInkRect(ctx, cx - treadW / 2, ty, treadW, treadH, visual.treadColor, 3.5, 2.5);
		ctx.strokeStyle = "#4B5049";
		ctx.lineWidth = 1.5;
		for (let tx = cx - treadW / 2 + 5; tx < cx + treadW / 2 - 4; tx += 6.5) {
			ctx.beginPath();
			ctx.moveTo(tx, ty + 1.5);
			ctx.lineTo(tx, ty + treadH - 1.5);
			ctx.stroke();
		}
	}
	if (visual.silhouette === "angular") {
		ctx.beginPath();
		ctx.moveTo(66, cy);
		ctx.lineTo(52, 23);
		ctx.lineTo(18, 25);
		ctx.lineTo(23, cy);
		ctx.lineTo(18, 55);
		ctx.lineTo(52, 57);
		ctx.closePath();
		ctx.fillStyle = visual.hullPrimary;
		ctx.fill();
		ctx.lineWidth = 3;
		ctx.strokeStyle = INK;
		ctx.stroke();
		ctx.beginPath();
		ctx.moveTo(58, cy);
		ctx.lineTo(47, 29);
		ctx.lineTo(25, 31);
		ctx.lineTo(28, cy);
		ctx.lineTo(25, 49);
		ctx.lineTo(47, 51);
		ctx.closePath();
		ctx.fillStyle = visual.hullSecondary;
		ctx.fill();
		ctx.lineWidth = 1.8;
		ctx.strokeStyle = INK;
		ctx.stroke();
		drawInkRect(ctx, 23, 33, 5, 4, "#1B1822", 1, 1.2);
		drawInkRect(ctx, 23, 43, 5, 4, "#1B1822", 1, 1.2);
	} else if (visual.silhouette === "sleek") {
		ctx.beginPath();
		ctx.moveTo(63, 32);
		ctx.lineTo(63, 48);
		ctx.lineTo(46, 52);
		ctx.lineTo(18, 52);
		ctx.lineTo(18, 28);
		ctx.lineTo(46, 28);
		ctx.closePath();
		ctx.fillStyle = visual.hullPrimary;
		ctx.fill();
		ctx.lineWidth = 2.8;
		ctx.strokeStyle = INK;
		ctx.stroke();
		drawInkRect(ctx, 23, 32, 28, 16, visual.hullSecondary, 4, 1.8);
		drawInkRect(ctx, 18, 33, 4, 5, "#2A2520", 1, 1.4);
		drawInkRect(ctx, 18, 42, 4, 5, "#2A2520", 1, 1.4);
	} else if (visual.silhouette === "heavy") {
		drawInkRect(ctx, 15, 23, 50, 34, visual.hullPrimary, 6, 3);
		drawInkRect(ctx, 21, 28, 34, 24, visual.hullSecondary, 4, 2);
		for (const side of [-1, 1]) for (const ox of [
			-14,
			-2,
			10
		]) drawInkRect(ctx, cx + ox, cy + side * 14 - 2.5, 9, 5, visual.hullSecondary, 1.5, 1.6);
		drawInkRect(ctx, 17, 31, 5, 6, visual.accentColor, 1.5, 1.4);
		drawInkRect(ctx, 17, 43, 5, 6, visual.accentColor, 1.5, 1.4);
	} else if (visual.silhouette === "long_barrel") {
		drawInkRect(ctx, 15, 27, 6, 6, "#3B342C", 1.5, 1.8);
		drawInkRect(ctx, 15, 47, 6, 6, "#3B342C", 1.5, 1.8);
		drawInkRect(ctx, 17, 25, 46, 30, visual.hullPrimary, 6, 3);
		drawInkRect(ctx, 23, 30, 31, 20, visual.hullSecondary, 3, 2);
		for (const ry of [
			-6,
			0,
			6
		]) drawInkRect(ctx, 20, cy + ry - 2, 6, 4, visual.accentColor, 1, 1.2);
	} else if (visual.silhouette === "coil") {
		drawInkRect(ctx, 17, 25.5, 46, 29, visual.hullPrimary, 7, 3);
		drawInkRect(ctx, 23, 30.5, 31, 19, visual.hullSecondary, 4, 2);
		for (const side of [-1, 1]) drawInkRect(ctx, 28, cy + side * 12.5 - 3, 22, 6, visual.accentColor, 2, 1.6);
	} else {
		drawInkRect(ctx, 17, 25.5, 46, 29, visual.hullPrimary, 7, 3);
		drawInkRect(ctx, 24, 30.5, 30, 19, visual.hullSecondary, 4, 2);
		ctx.strokeStyle = INK;
		ctx.lineWidth = 1.6;
		for (const lx of [
			-13,
			-9,
			-5
		]) {
			ctx.beginPath();
			ctx.moveTo(cx + lx, 34);
			ctx.lineTo(cx + lx, 46);
			ctx.stroke();
		}
	}
	ctx.fillStyle = visual.accentColor;
	ctx.beginPath();
	ctx.roundRect(52, 33, 5.5, 14, 2);
	ctx.fill();
	ctx.lineWidth = 1.8;
	ctx.strokeStyle = INK;
	ctx.stroke();
	if (customization && customization.decalId !== "none") drawCanvasDecal(ctx, cx, cy, customization.decalId, customization.decalColor, customization.decalPosition, visual.silhouette, "hull", .92);
}
function drawTankTurret(ctx, tank, visualOverride, customization) {
	const visual = visualOverride ?? tank.visual;
	const barrelColor = visual.barrelColor ?? visual.hullSecondary;
	const cx = 36;
	const cy = 32;
	if (visual.silhouette === "heavy") {
		drawInkRect(ctx, 42, 24.5, 12, 15, visual.hullPrimary, 3, 2.2);
		drawInkRect(ctx, 46, 26.5, 27, 11, barrelColor, 2.5, 2.5);
		drawInkRect(ctx, 68, 25, 7.5, 14, visual.accentColor, 2, 2);
	} else if (visual.silhouette === "long_barrel") {
		drawInkRect(ctx, 43, 25.5, 14, 13, visual.hullPrimary, 3, 2.2);
		drawInkRect(ctx, 48, 28, 41, 8, barrelColor, 2, 2.5);
		drawInkRect(ctx, 84, 26, 8, 12, visual.accentColor, 2, 2);
	} else if (visual.silhouette === "coil") {
		drawInkRect(ctx, 44, 27, 29, 10, barrelColor, 3, 2.5);
		ctx.strokeStyle = INK;
		ctx.lineWidth = 4.5;
		ctx.beginPath();
		ctx.moveTo(69, 28);
		ctx.lineTo(79, 23.5);
		ctx.moveTo(69, 36);
		ctx.lineTo(79, 40.5);
		ctx.stroke();
		ctx.strokeStyle = visual.accentColor;
		ctx.lineWidth = 2.2;
		ctx.beginPath();
		ctx.moveTo(69, 28);
		ctx.lineTo(79, 23.5);
		ctx.moveTo(69, 36);
		ctx.lineTo(79, 40.5);
		ctx.stroke();
		for (const ox of [
			15,
			22,
			29
		]) {
			ctx.beginPath();
			ctx.moveTo(cx + ox, 24);
			ctx.lineTo(cx + ox, 40);
			ctx.lineWidth = 3.2;
			ctx.strokeStyle = visual.accentColor;
			ctx.stroke();
		}
	} else if (visual.silhouette === "sleek") {
		drawInkRect(ctx, 42, 28.5, 29, 7, barrelColor, 2, 2.5);
		drawInkRect(ctx, 67, 27.5, 5, 9, visual.accentColor, 1.5, 1.8);
	} else if (visual.silhouette === "angular") {
		drawInkRect(ctx, 42, 28.5, 32, 7, barrelColor, 2, 2.5);
		drawInkRect(ctx, 69, 27.5, 6, 9, visual.accentColor, 2, 2);
	} else {
		drawInkRect(ctx, 46, 36, 15, 3.5, "#2A2F26", 1, 1.4);
		drawInkRect(ctx, 42, 27.5, 33, 9, barrelColor, 3, 2.5);
		drawInkRect(ctx, 70, 26.5, 6, 11, visual.accentColor, 2, 2);
	}
	const radius = visual.silhouette === "heavy" ? 16.5 : visual.silhouette === "sleek" ? 12 : 14;
	ctx.beginPath();
	if (visual.silhouette === "angular") {
		ctx.moveTo(51, cy);
		ctx.lineTo(38, 19);
		ctx.lineTo(22, 23);
		ctx.lineTo(22, 41);
		ctx.lineTo(38, 45);
		ctx.closePath();
	} else if (visual.silhouette === "heavy") {
		ctx.moveTo(52, 24);
		ctx.lineTo(52, 40);
		ctx.lineTo(42, 48);
		ctx.lineTo(25, 47);
		ctx.lineTo(20, 40);
		ctx.lineTo(20, 24);
		ctx.lineTo(25, 17);
		ctx.lineTo(42, 16);
		ctx.closePath();
	} else ctx.arc(cx, cy, radius, 0, Math.PI * 2);
	ctx.fillStyle = visual.turretColor;
	ctx.fill();
	ctx.lineWidth = 3;
	ctx.strokeStyle = INK;
	ctx.stroke();
	if (visual.silhouette === "sleek") {
		ctx.strokeStyle = visual.accentColor;
		ctx.lineWidth = 2;
		ctx.beginPath();
		ctx.moveTo(28, 26);
		ctx.lineTo(18, 20);
		ctx.stroke();
	}
	ctx.beginPath();
	ctx.arc(33, 30, 5, 0, Math.PI * 2);
	ctx.fillStyle = visual.silhouette === "coil" || visual.silhouette === "angular" ? visual.accentColor : visual.hullSecondary;
	ctx.fill();
	ctx.lineWidth = 2;
	ctx.strokeStyle = INK;
	ctx.stroke();
	if (customization && customization.decalId !== "none") drawCanvasDecal(ctx, cx, cy, customization.decalId, customization.decalColor, customization.decalPosition, visual.silhouette, "turret", .92);
}
function ensurePlayerTankTextures(scene, tankId, cosmeticId = "default", customization) {
	const tank = TANK_DEFINITIONS[tankId] || TANK_LIST[0];
	if (!customization && cosmeticId === "default") return {
		hullKey: `tank_hull_${tank.id}`,
		turretKey: `tank_turret_${tank.id}`
	};
	const sig = getCustomizationSignature(tank.id, cosmeticId, customization);
	const hullKey = `tank_hull_${sig}`;
	const turretKey = `tank_turret_${sig}`;
	const visual = resolveEffectiveTankVisual(tank, cosmeticId, customization);
	makeCanvasTexture(scene, hullKey, 80, 80, (ctx) => drawTankHull(ctx, tank, visual, customization));
	makeCanvasTexture(scene, turretKey, 96, 64, (ctx) => drawTankTurret(ctx, tank, visual, customization));
	return {
		hullKey,
		turretKey
	};
}
function ensureProceduralTextures(scene, playerCosmeticId = "default") {
	for (const tank of TANK_LIST) {
		makeCanvasTexture(scene, `tank_hull_${tank.id}`, 80, 80, (ctx) => drawTankHull(ctx, tank));
		makeCanvasTexture(scene, `tank_turret_${tank.id}`, 96, 64, (ctx) => drawTankTurret(ctx, tank));
		if (playerCosmeticId !== "default") {
			const cosmeticVisual = getEffectiveTankVisual(tank, playerCosmeticId);
			makeCanvasTexture(scene, `tank_hull_${tank.id}_${playerCosmeticId}`, 80, 80, (ctx) => drawTankHull(ctx, tank, cosmeticVisual));
			makeCanvasTexture(scene, `tank_turret_${tank.id}_${playerCosmeticId}`, 96, 64, (ctx) => drawTankTurret(ctx, tank, cosmeticVisual));
		}
	}
	makeCanvasTexture(scene, "obs_brick", 64, 64, (ctx, w, h) => {
		drawInkRect(ctx, 2, 2, w - 4, h - 4, "#A84B36", 4, 3);
		ctx.strokeStyle = "#D9C5B2";
		ctx.lineWidth = 2;
		for (const rowY of [
			16,
			32,
			48
		]) {
			ctx.beginPath();
			ctx.moveTo(4, rowY);
			ctx.lineTo(w - 4, rowY);
			ctx.stroke();
		}
		ctx.strokeStyle = INK;
		ctx.lineWidth = 1.8;
		for (const [x, y] of [
			[22, 4],
			[44, 4],
			[14, 16],
			[38, 16],
			[24, 32],
			[48, 32],
			[16, 48],
			[40, 48]
		]) {
			ctx.beginPath();
			ctx.moveTo(x, y);
			ctx.lineTo(x, y + 14);
			ctx.stroke();
		}
	});
	makeCanvasTexture(scene, "obs_steel", 64, 64, (ctx, w, h) => {
		drawInkRect(ctx, 2, 2, w - 4, h - 4, "#646D75", 5, 3);
		drawInkRect(ctx, 8, 8, w - 16, h - 16, "#7C868F", 3, 2);
		ctx.strokeStyle = "#B8C2CC";
		ctx.lineWidth = 3;
		ctx.beginPath();
		ctx.moveTo(14, 24);
		ctx.lineTo(24, 14);
		ctx.moveTo(14, 38);
		ctx.lineTo(38, 14);
		ctx.stroke();
		ctx.fillStyle = INK;
		for (const [rx, ry] of [
			[12, 12],
			[w - 12, 12],
			[12, h - 12],
			[w - 12, h - 12]
		]) {
			ctx.beginPath();
			ctx.arc(rx, ry, 2.5, 0, Math.PI * 2);
			ctx.fill();
		}
	});
	makeCanvasTexture(scene, "obs_crate", 64, 64, (ctx, w, h) => {
		drawInkRect(ctx, 2, 2, w - 4, h - 4, "#B57B42", 4, 3);
		drawInkRect(ctx, 9, 9, w - 18, h - 18, "#CC9256", 2, 2);
		ctx.strokeStyle = INK;
		ctx.lineWidth = 2.5;
		ctx.beginPath();
		ctx.moveTo(10, 10);
		ctx.lineTo(w - 10, h - 10);
		ctx.moveTo(w - 10, 10);
		ctx.lineTo(10, h - 10);
		ctx.stroke();
	});
	makeCanvasTexture(scene, "obs_bush", 96, 96, (ctx) => {
		for (const [bx, by, br, col] of [
			[
				48,
				48,
				28,
				"#3B6E38"
			],
			[
				30,
				40,
				20,
				"#4A8544"
			],
			[
				64,
				42,
				21,
				"#4A8544"
			],
			[
				40,
				62,
				20,
				"#366533"
			],
			[
				58,
				60,
				19,
				"#53944C"
			],
			[
				48,
				34,
				18,
				"#5E9E56"
			]
		]) {
			ctx.beginPath();
			ctx.arc(bx, by, br, 0, Math.PI * 2);
			ctx.fillStyle = col;
			ctx.fill();
			ctx.lineWidth = 2.8;
			ctx.strokeStyle = INK;
			ctx.stroke();
		}
	});
	makeCanvasTexture(scene, "obs_water", 128, 96, (ctx, w, h) => {
		ctx.beginPath();
		ctx.roundRect(3, 3, w - 6, h - 6, 22);
		ctx.fillStyle = "#387D9C";
		ctx.fill();
		ctx.lineWidth = 3;
		ctx.strokeStyle = "#1E4659";
		ctx.stroke();
		ctx.beginPath();
		ctx.roundRect(10, 10, w - 20, h - 20, 16);
		ctx.fillStyle = "#4B95B5";
		ctx.fill();
		ctx.strokeStyle = "#CBEAF7";
		ctx.lineWidth = 2.2;
		for (const [rx, ry, rw] of [
			[
				28,
				30,
				28
			],
			[
				68,
				46,
				32
			],
			[
				38,
				64,
				24
			]
		]) {
			ctx.beginPath();
			ctx.moveTo(rx, ry);
			ctx.quadraticCurveTo(rx + rw / 2, ry - 4, rx + rw, ry);
			ctx.stroke();
		}
	});
	makeCanvasTexture(scene, "obs_barrel", 48, 48, (ctx) => {
		ctx.fillStyle = "rgba(0,0,0,0.22)";
		ctx.beginPath();
		ctx.arc(26, 26, 17, 0, Math.PI * 2);
		ctx.fill();
		ctx.beginPath();
		ctx.arc(24, 24, 17, 0, Math.PI * 2);
		ctx.fillStyle = "#C93A2B";
		ctx.fill();
		ctx.lineWidth = 3;
		ctx.strokeStyle = INK;
		ctx.stroke();
		ctx.beginPath();
		ctx.arc(24, 24, 10, 0, Math.PI * 2);
		ctx.fillStyle = "#F59E0B";
		ctx.fill();
		ctx.lineWidth = 2;
		ctx.stroke();
		ctx.beginPath();
		ctx.arc(24, 24, 3.5, 0, Math.PI * 2);
		ctx.fillStyle = INK;
		ctx.fill();
	});
	makeCanvasTexture(scene, "proj_standard", 26, 16, (ctx) => {
		ctx.fillStyle = "rgba(254, 240, 138, 0.5)";
		ctx.beginPath();
		ctx.ellipse(7, 8, 5, 2.8, 0, 0, Math.PI * 2);
		ctx.fill();
		ctx.beginPath();
		ctx.moveTo(23, 8);
		ctx.lineTo(12, 3);
		ctx.lineTo(5, 4);
		ctx.lineTo(5, 12);
		ctx.lineTo(12, 13);
		ctx.closePath();
		ctx.fillStyle = "#FCD34D";
		ctx.fill();
		ctx.lineWidth = 2.2;
		ctx.strokeStyle = INK;
		ctx.stroke();
	});
	makeCanvasTexture(scene, "proj_heavy", 30, 20, (ctx) => {
		ctx.fillStyle = "rgba(251, 146, 60, 0.45)";
		ctx.beginPath();
		ctx.ellipse(8, 10, 6, 4.5, 0, 0, Math.PI * 2);
		ctx.fill();
		ctx.beginPath();
		ctx.moveTo(27, 10);
		ctx.lineTo(15, 3);
		ctx.lineTo(5, 5);
		ctx.lineTo(5, 15);
		ctx.lineTo(15, 17);
		ctx.closePath();
		ctx.fillStyle = "#EF4444";
		ctx.fill();
		ctx.lineWidth = 2.4;
		ctx.strokeStyle = INK;
		ctx.stroke();
		ctx.beginPath();
		ctx.ellipse(16, 10, 4.5, 2.5, 0, 0, Math.PI * 2);
		ctx.fillStyle = "#FDE047";
		ctx.fill();
	});
	makeCanvasTexture(scene, "proj_pierce", 32, 18, (ctx) => {
		ctx.beginPath();
		ctx.moveTo(29, 9);
		ctx.lineTo(6, 2);
		ctx.lineTo(11, 9);
		ctx.lineTo(6, 16);
		ctx.closePath();
		ctx.fillStyle = "#C084FC";
		ctx.fill();
		ctx.lineWidth = 2.2;
		ctx.strokeStyle = INK;
		ctx.stroke();
		ctx.beginPath();
		ctx.moveTo(24, 9);
		ctx.lineTo(12, 9);
		ctx.strokeStyle = "#F3E8FF";
		ctx.lineWidth = 2;
		ctx.stroke();
	});
	makeCanvasTexture(scene, "proj_electric", 30, 22, (ctx) => {
		ctx.beginPath();
		ctx.ellipse(15, 11, 11, 8, 0, 0, Math.PI * 2);
		ctx.fillStyle = "rgba(34, 211, 238, 0.35)";
		ctx.fill();
		ctx.beginPath();
		ctx.ellipse(15, 11, 8.5, 5.5, 0, 0, Math.PI * 2);
		ctx.fillStyle = "#22D3EE";
		ctx.fill();
		ctx.lineWidth = 2.4;
		ctx.strokeStyle = INK;
		ctx.stroke();
		ctx.beginPath();
		ctx.ellipse(16, 11, 4.2, 2.5, 0, 0, Math.PI * 2);
		ctx.fillStyle = "#ECFEFF";
		ctx.fill();
		ctx.strokeStyle = "#A5F3FC";
		ctx.lineWidth = 1.8;
		ctx.beginPath();
		ctx.moveTo(3, 8);
		ctx.lineTo(7, 11);
		ctx.lineTo(4, 14);
		ctx.stroke();
	});
	makeCanvasTexture(scene, "proj_artillery", 34, 22, (ctx) => {
		ctx.beginPath();
		ctx.moveTo(31, 11);
		ctx.lineTo(16, 3);
		ctx.lineTo(4, 5);
		ctx.lineTo(4, 17);
		ctx.lineTo(16, 19);
		ctx.closePath();
		ctx.fillStyle = "#EF4444";
		ctx.fill();
		ctx.lineWidth = 2.4;
		ctx.strokeStyle = INK;
		ctx.stroke();
		ctx.beginPath();
		ctx.ellipse(19, 11, 5.5, 3, 0, 0, Math.PI * 2);
		ctx.fillStyle = "#FCD34D";
		ctx.fill();
	});
	makeCanvasTexture(scene, "entity_mine", 38, 38, (ctx) => {
		ctx.strokeStyle = INK;
		ctx.lineWidth = 3;
		for (let i = 0; i < 8; i++) {
			const a = Math.PI * 2 * i / 8;
			ctx.beginPath();
			ctx.moveTo(19 + Math.cos(a) * 11, 19 + Math.sin(a) * 11);
			ctx.lineTo(19 + Math.cos(a) * 16.5, 19 + Math.sin(a) * 16.5);
			ctx.stroke();
		}
		ctx.beginPath();
		ctx.arc(19, 19, 12.5, 0, Math.PI * 2);
		ctx.fillStyle = "#333834";
		ctx.fill();
		ctx.lineWidth = 2.5;
		ctx.strokeStyle = INK;
		ctx.stroke();
		ctx.beginPath();
		ctx.arc(19, 19, 6.5, 0, Math.PI * 2);
		ctx.fillStyle = "#F97316";
		ctx.fill();
		ctx.beginPath();
		ctx.arc(19, 19, 2.5, 0, Math.PI * 2);
		ctx.fillStyle = "#FEF08A";
		ctx.fill();
	});
	for (const id of POWERUP_IDS) {
		const def = POWERUP_DEFINITIONS[id];
		makeCanvasTexture(scene, `pwr_${id}`, 48, 48, (ctx) => {
			ctx.fillStyle = "rgba(0,0,0,0.26)";
			ctx.beginPath();
			ctx.roundRect(5, 7, 38, 38, 10);
			ctx.fill();
			drawInkRect(ctx, 4, 4, 38, 38, def.color, 9, 2.8);
			drawInkRect(ctx, 8, 8, 30, 30, def.accent, 6, 1.5);
			ctx.save();
			ctx.strokeStyle = def.color;
			ctx.fillStyle = def.color;
			ctx.globalAlpha = .28;
			ctx.lineWidth = 2.5;
			if (id === "repair_kit") {
				ctx.fillRect(20, 12, 6, 22);
				ctx.fillRect(12, 20, 22, 6);
			} else if (id === "shield") {
				ctx.beginPath();
				ctx.moveTo(23, 12);
				ctx.lineTo(32, 16);
				ctx.lineTo(30, 26);
				ctx.lineTo(23, 33);
				ctx.lineTo(16, 26);
				ctx.lineTo(14, 16);
				ctx.closePath();
				ctx.stroke();
			} else if (id === "radar") {
				ctx.beginPath();
				ctx.arc(23, 23, 10, 0, Math.PI * 2);
				ctx.stroke();
				ctx.beginPath();
				ctx.arc(23, 23, 5, 0, Math.PI * 2);
				ctx.stroke();
			} else if (id === "multi_shot") {
				ctx.beginPath();
				ctx.moveTo(23, 28);
				ctx.lineTo(13, 14);
				ctx.moveTo(23, 28);
				ctx.lineTo(23, 12);
				ctx.moveTo(23, 28);
				ctx.lineTo(33, 14);
				ctx.stroke();
			} else if (id === "piercing_shell") {
				ctx.beginPath();
				ctx.moveTo(14, 30);
				ctx.lineTo(32, 15);
				ctx.stroke();
			} else if (id === "mine_kit") {
				ctx.beginPath();
				ctx.arc(23, 23, 8, 0, Math.PI * 2);
				ctx.fill();
			}
			ctx.restore();
			ctx.fillStyle = INK;
			ctx.font = "bold 12px \"Barlow Condensed\", sans-serif";
			ctx.textAlign = "center";
			ctx.textBaseline = "middle";
			ctx.fillText(def.shortLabel, 23, 24);
		});
	}
	makeCanvasTexture(scene, "fx_puff", 32, 32, (ctx) => {
		ctx.beginPath();
		ctx.arc(16, 16, 12, 0, Math.PI * 2);
		ctx.fillStyle = "#FFFFFF";
		ctx.fill();
		ctx.lineWidth = 2;
		ctx.strokeStyle = INK;
		ctx.stroke();
	});
	makeCanvasTexture(scene, "fx_tread", 16, 36, (ctx) => {
		ctx.fillStyle = "rgba(26, 24, 20, 0.34)";
		ctx.fillRect(2, 2, 12, 7);
		ctx.fillRect(2, 27, 12, 7);
	});
	makeCanvasTexture(scene, "fx_scorch", 64, 64, (ctx) => {
		const grad = ctx.createRadialGradient(32, 32, 4, 32, 32, 30);
		grad.addColorStop(0, "rgba(22, 20, 18, 0.65)");
		grad.addColorStop(.6, "rgba(28, 25, 22, 0.32)");
		grad.addColorStop(1, "rgba(28, 25, 22, 0)");
		ctx.fillStyle = grad;
		ctx.beginPath();
		ctx.arc(32, 32, 30, 0, Math.PI * 2);
		ctx.fill();
	});
}
// src/game/systems/SoundFX.ts
var SoundFXManager = class {
	constructor() {
		this.ctx = null;
		this.sfxGain = null;
		this.musicGain = null;
		this.soundEnabled = true;
		this.soundVolume = .65;
		this.musicEnabled = true;
		this.musicVolume = .4;
		this.platformMuted = false;
		this.adPaused = false;
		this.unlocked = false;
		this.gestureHooked = false;
		this.activeVoices = 0;
		this.maxVoices = 14;
		this.lastPlayedAt = /* @__PURE__ */ new Map();
		this.engineOsc = null;
		this.engineGain = null;
		this.engineFilter = null;
		this.musicMode = "none";
		this.musicTimer = null;
		this.musicStep = 0;
		this.registerGestureUnlock();
	}
	registerGestureUnlock() {
		if (this.gestureHooked || typeof window === "undefined") return;
		if (typeof window.addEventListener !== "function") return;
		this.gestureHooked = true;
		const onGesture = () => {
			this.unlockFromUserGesture();
		};
		window.addEventListener("pointerdown", onGesture, { passive: true });
		window.addEventListener("keydown", onGesture, { passive: true });
		window.addEventListener("touchstart", onGesture, { passive: true });
		if (typeof document !== "undefined" && typeof document.addEventListener === "function") document.addEventListener("visibilitychange", () => {
			if (document.visibilityState === "hidden") {
				this.stopAllLoops();
				if (this.ctx && this.ctx.state === "running") this.ctx.suspend().catch(() => {});
			} else if (document.visibilityState === "visible") {
				if (this.unlocked && this.ctx && this.ctx.state === "suspended") this.ctx.resume().catch(() => {});
				this.syncMusicLoop();
			}
		});
		window.addEventListener("pagehide", () => {
			this.stopAllLoops();
		});
	}
	unlockFromUserGesture() {
		this.unlocked = true;
		const ctx = this.ensureContext(true);
		if (!ctx) return;
		if (ctx.state === "suspended") ctx.resume().catch(() => {});
		this.syncMusicLoop();
	}
	configure(soundEnabled, soundVolume, musicEnabled = this.musicEnabled, musicVolume = this.musicVolume) {
		this.soundEnabled = soundEnabled;
		this.soundVolume = Math.min(1, Math.max(0, soundVolume));
		this.musicEnabled = musicEnabled;
		this.musicVolume = Math.min(1, Math.max(0, musicVolume));
		if (this.ctx && this.sfxGain) this.sfxGain.gain.setTargetAtTime(this.isEffectivelySfxMuted() ? 0 : this.soundVolume, this.ctx.currentTime, .02);
		if (this.ctx && this.musicGain) this.musicGain.gain.setTargetAtTime(this.isEffectivelyMusicMuted() ? 0 : this.musicVolume * .24, this.ctx.currentTime, .04);
		if (this.isEffectivelySfxMuted()) this.stopEngineLoop();
		this.syncMusicLoop();
	}
	isEffectivelySfxMuted() {
		return !this.soundEnabled || this.soundVolume <= .01 || this.platformMuted || this.adPaused;
	}
	isEffectivelyMusicMuted() {
		return !this.musicEnabled || this.musicVolume <= .01 || this.platformMuted || this.adPaused;
	}
	setPlatformMuted(muted) {
		if (this.platformMuted === muted) return;
		this.platformMuted = muted;
		this.applyEffectiveAudioState();
	}
	setAdPaused(paused) {
		if (this.adPaused === paused) return;
		this.adPaused = paused;
		this.applyEffectiveAudioState();
	}
	applyEffectiveAudioState() {
		if (this.ctx && this.sfxGain) this.sfxGain.gain.setTargetAtTime(this.isEffectivelySfxMuted() ? 0 : this.soundVolume, this.ctx.currentTime, .02);
		if (this.ctx && this.musicGain) this.musicGain.gain.setTargetAtTime(this.isEffectivelyMusicMuted() ? 0 : this.musicVolume * .24, this.ctx.currentTime, .03);
		if (this.platformMuted || this.adPaused) {
			this.stopAllLoops();
			if (this.ctx && this.ctx.state === "running") this.ctx.suspend().catch(() => {});
		} else {
			if ((typeof document === "undefined" || document.visibilityState !== "hidden") && this.unlocked && this.ctx && this.ctx.state === "suspended") this.ctx.resume().catch(() => {});
			if (this.isEffectivelySfxMuted()) this.stopEngineLoop();
			this.syncMusicLoop();
		}
	}
	setMusicMode(mode) {
		if (this.musicMode === mode) return;
		this.musicMode = mode;
		this.musicStep = 0;
		this.syncMusicLoop();
	}
	stopAllLoops() {
		this.stopEngineLoop();
		this.stopMusicTimer();
	}
	ensureContext(fromUserGesture = false) {
		if (typeof window === "undefined") return null;
		if (!this.unlocked && !fromUserGesture) return null;
		if (!this.ctx) {
			const AudioCtx = window.AudioContext || window.webkitAudioContext;
			if (!AudioCtx) return null;
			this.ctx = new AudioCtx();
			this.sfxGain = this.ctx.createGain();
			this.sfxGain.gain.value = this.soundEnabled ? this.soundVolume : 0;
			this.sfxGain.connect(this.ctx.destination);
			this.musicGain = this.ctx.createGain();
			this.musicGain.gain.value = this.musicEnabled ? this.musicVolume * .24 : 0;
			this.musicGain.connect(this.ctx.destination);
		}
		if (this.ctx.state === "suspended" && fromUserGesture) this.ctx.resume().catch(() => {});
		return this.ctx;
	}
	canPlaySfx(tag, minIntervalMs = 45) {
		if (this.isEffectivelySfxMuted()) return null;
		if (this.activeVoices >= this.maxVoices) return null;
		const nowMs = typeof performance !== "undefined" ? performance.now() : Date.now();
		if (nowMs - (this.lastPlayedAt.get(tag) ?? 0) < minIntervalMs) return null;
		const ctx = this.ensureContext(false);
		if (!ctx || ctx.state !== "running") return null;
		this.lastPlayedAt.set(tag, nowMs);
		return ctx;
	}
	playTone(ctx, type, startFreq, endFreq, durationSec, amp, delaySec = 0, target = "sfx") {
		const dest = target === "music" ? this.musicGain : this.sfxGain;
		if (!dest) return;
		if (target === "sfx" && this.activeVoices >= this.maxVoices) return;
		const t0 = ctx.currentTime + delaySec;
		const osc = ctx.createOscillator();
		const gain = ctx.createGain();
		osc.type = type;
		osc.frequency.setValueAtTime(Math.max(20, startFreq), t0);
		if (endFreq !== null && endFreq !== startFreq) osc.frequency.exponentialRampToValueAtTime(Math.max(20, endFreq), t0 + durationSec);
		gain.gain.setValueAtTime(1e-4, t0);
		gain.gain.linearRampToValueAtTime(Math.max(.001, amp), t0 + Math.min(.015, durationSec * .25));
		gain.gain.exponentialRampToValueAtTime(1e-4, t0 + durationSec);
		osc.connect(gain);
		gain.connect(dest);
		if (target === "sfx") this.activeVoices += 1;
		osc.onended = () => {
			if (target === "sfx") this.activeVoices = Math.max(0, this.activeVoices - 1);
			try {
				osc.disconnect();
				gain.disconnect();
			} catch {}
		};
		osc.start(t0);
		osc.stop(t0 + durationSec + .02);
	}
	updateMovementAudio(speedRatio, active) {
		const clamped = active ? Math.min(1.4, Math.max(0, speedRatio)) : 0;
		if (this.isEffectivelySfxMuted() || clamped < .08) {
			if (this.ctx && this.engineGain) this.engineGain.gain.setTargetAtTime(0, this.ctx.currentTime, .06);
			return;
		}
		const ctx = this.ensureContext(false);
		if (!ctx || ctx.state !== "running" || !this.sfxGain) return;
		if (!this.engineOsc || !this.engineGain || !this.engineFilter) {
			this.engineOsc = ctx.createOscillator();
			this.engineOsc.type = "triangle";
			this.engineOsc.frequency.value = 54;
			this.engineFilter = ctx.createBiquadFilter();
			this.engineFilter.type = "lowpass";
			this.engineFilter.frequency.value = 135;
			this.engineGain = ctx.createGain();
			this.engineGain.gain.value = 0;
			this.engineOsc.connect(this.engineFilter);
			this.engineFilter.connect(this.engineGain);
			this.engineGain.connect(this.sfxGain);
			this.engineOsc.start();
		}
		const now = ctx.currentTime;
		const freq = 48 + clamped * 26;
		const targetVol = .048 * Math.min(1, clamped);
		this.engineOsc.frequency.setTargetAtTime(freq, now, .08);
		this.engineGain.gain.setTargetAtTime(targetVol, now, .07);
	}
	stopEngineLoop() {
		if (this.ctx && this.engineGain) try {
			this.engineGain.gain.setTargetAtTime(0, this.ctx.currentTime, .02);
		} catch {}
		if (this.engineOsc) {
			try {
				this.engineOsc.stop();
				this.engineOsc.disconnect();
			} catch {}
			this.engineOsc = null;
		}
		if (this.engineFilter) {
			try {
				this.engineFilter.disconnect();
			} catch {}
			this.engineFilter = null;
		}
		if (this.engineGain) {
			try {
				this.engineGain.disconnect();
			} catch {}
			this.engineGain = null;
		}
	}
	syncMusicLoop() {
		if (!(!(typeof document !== "undefined" && document.visibilityState === "hidden") && this.unlocked && this.musicMode !== "none" && !this.isEffectivelyMusicMuted())) {
			this.stopMusicTimer();
			return;
		}
		if (!this.ensureContext(false)) return;
		if (this.musicTimer === null && typeof window !== "undefined") {
			const stepMs = this.musicMode === "battle" ? 420 : 620;
			this.musicTimer = window.setInterval(() => {
				this.tickMusicNote();
			}, stepMs);
		}
	}
	stopMusicTimer() {
		if (this.musicTimer !== null && typeof window !== "undefined") {
			window.clearInterval(this.musicTimer);
			this.musicTimer = null;
		}
	}
	tickMusicNote() {
		if (this.isEffectivelyMusicMuted() || this.musicMode === "none") return;
		const ctx = this.ensureContext(false);
		if (!ctx || ctx.state !== "running" || !this.musicGain) return;
		const battleBass = [
			73.42,
			73.42,
			87.31,
			73.42,
			98,
			110,
			87.31,
			130.81
		];
		const battlePad = [
			293.66,
			0,
			349.23,
			0,
			392,
			0,
			440,
			349.23
		];
		const menuPad = [
			146.83,
			220,
			174.61,
			261.63,
			196,
			220,
			174.61,
			146.83
		];
		const idx = this.musicStep % 8;
		this.musicStep += 1;
		if (this.musicMode === "battle") {
			const bass = battleBass[idx];
			this.playTone(ctx, "triangle", bass, bass * .98, .34, .32, 0, "music");
			const lead = battlePad[idx];
			if (lead > 0) this.playTone(ctx, "sine", lead, lead, .38, .14, .04, "music");
		} else {
			const pad = menuPad[idx];
			this.playTone(ctx, "sine", pad, pad, .54, .18, 0, "music");
		}
	}
	playShot(isPlayer) {
		const ctx = this.canPlaySfx(isPlayer ? "shot_p" : "shot_ai", isPlayer ? 40 : 75);
		if (!ctx) return;
		this.playTone(ctx, "triangle", isPlayer ? 245 : 190, 55, .11, isPlayer ? .22 : .08);
	}
	playArtilleryShot(isPlayer) {
		const ctx = this.canPlaySfx(isPlayer ? "art_p" : "art_ai", isPlayer ? 60 : 90);
		if (!ctx) return;
		this.playTone(ctx, "sawtooth", isPlayer ? 155 : 128, 36, .2, isPlayer ? .24 : .095);
	}
	playBarrageLaunch() {
		const ctx = this.canPlaySfx("barrage", 120);
		if (!ctx) return;
		this.playTone(ctx, "triangle", 210, 480, .14, .16);
		this.playTone(ctx, "triangle", 480, 140, .2, .15, .14);
	}
	playElectricShot(isPlayer) {
		const ctx = this.canPlaySfx(isPlayer ? "elec_p" : "elec_ai", isPlayer ? 45 : 80);
		if (!ctx) return;
		this.playTone(ctx, "sawtooth", isPlayer ? 690 : 540, 175, .11, isPlayer ? .16 : .07);
	}
	playEmpPulse() {
		const ctx = this.canPlaySfx("emp", 140);
		if (!ctx) return;
		this.playTone(ctx, "sine", 540, 95, .36, .24);
		this.playTone(ctx, "triangle", 920, 240, .22, .12);
	}
	playImpact(kindOrHeavy = false) {
		const kind = typeof kindOrHeavy === "boolean" ? kindOrHeavy ? "tank" : "wall" : kindOrHeavy;
		const ctx = this.canPlaySfx(`imp_${kind}`, 45);
		if (!ctx) return;
		switch (kind) {
			case "shield":
				this.playTone(ctx, "sine", 640, 320, .1, .14);
				break;
			case "steel":
				this.playTone(ctx, "triangle", 760, 480, .075, .09);
				break;
			case "destructible":
				this.playTone(ctx, "sawtooth", 220, 72, .085, .11);
				break;
			case "tank":
				this.playTone(ctx, "sawtooth", 165, 42, .1, .19);
				break;
			default: this.playTone(ctx, "triangle", 260, 85, .065, .08);
		}
	}
	playShieldBreak() {
		const ctx = this.canPlaySfx("shd_break", 120);
		if (!ctx) return;
		this.playTone(ctx, "sine", 780, 210, .2, .18);
		this.playTone(ctx, "triangle", 520, 140, .18, .14, .04);
	}
	playExplosion() {
		const ctx = this.canPlaySfx("explosion", 95);
		if (!ctx) return;
		this.playTone(ctx, "sawtooth", 118, 28, .34, .3);
		this.playTone(ctx, "triangle", 84, 24, .32, .22, .02);
	}
	playElimination(isPlayerInvolved) {
		const ctx = this.canPlaySfx("elim", 110);
		if (!ctx) return;
		const amp = isPlayerInvolved ? .28 : .15;
		this.playTone(ctx, "sawtooth", 140, 30, .36, amp);
		this.playTone(ctx, "triangle", 310, 88, .22, amp * .7, .04);
	}
	playBarrelPrime() {
		const ctx = this.canPlaySfx("barrel_prime", 150);
		if (!ctx) return;
		this.playTone(ctx, "triangle", 540, 560, .11, .11, 0);
		this.playTone(ctx, "triangle", 720, 740, .11, .11, .14);
	}
	playPowerup() {
		const ctx = this.canPlaySfx("powerup", 100);
		if (!ctx) return;
		[
			523.25,
			659.25,
			783.99
		].forEach((freq, idx) => {
			this.playTone(ctx, "sine", freq, freq * 1.02, .14, .15, idx * .045);
		});
	}
	playMineDeploy() {
		const ctx = this.canPlaySfx("mine", 100);
		if (!ctx) return;
		this.playTone(ctx, "triangle", 220, 115, .12, .16);
	}
	playAbility() {
		const ctx = this.canPlaySfx("ability", 120);
		if (!ctx) return;
		this.playTone(ctx, "square", 320, 640, .16, .13);
	}
	playAbilityExpire(tankId) {
		const ctx = this.canPlaySfx(`abil_exp_${tankId}`, 150);
		if (!ctx) return;
		if (tankId === "fortress") this.playTone(ctx, "sine", 420, 180, .16, .1);
		else if (tankId === "scout") this.playTone(ctx, "triangle", 340, 130, .18, .09);
		else if (tankId === "assault") this.playTone(ctx, "triangle", 460, 210, .14, .09);
	}
	playAfterburner() {
		const ctx = this.canPlaySfx("afterburner", 120);
		if (!ctx) return;
		this.playTone(ctx, "sawtooth", 165, 520, .17, .16);
		this.playTone(ctx, "sawtooth", 520, 310, .14, .12, .16);
	}
	playPhaseShift() {
		const ctx = this.canPlaySfx("phase", 120);
		if (!ctx) return;
		this.playTone(ctx, "sine", 280, 760, .18, .16);
		this.playTone(ctx, "sine", 760, 420, .14, .12, .17);
	}
	playPhaseEnd() {
		const ctx = this.canPlaySfx("phase_end", 120);
		if (!ctx) return;
		this.playTone(ctx, "sine", 520, 220, .16, .1);
	}
	playMatchEnd(victory) {
		this.stopEngineLoop();
		const ctx = this.canPlaySfx("match_end", 300);
		if (!ctx) return;
		(victory ? [
			440,
			554.37,
			659.25,
			880
		] : [
			330,
			293.66,
			246.94,
			196
		]).forEach((freq, i) => {
			this.playTone(ctx, "triangle", freq, freq, .25, .18, i * .1);
		});
	}
	playCountdown(isGo) {
		const ctx = this.canPlaySfx("countdown", 120);
		if (!ctx) return;
		this.playTone(ctx, "triangle", isGo ? 784 : 440, isGo ? 880 : 440, isGo ? .24 : .12, isGo ? .2 : .14);
	}
	playEmptyClick() {
		const ctx = this.canPlaySfx("empty", 140);
		if (!ctx) return;
		this.playTone(ctx, "square", 175, 85, .045, .09);
	}
	playReloadStart() {
		const ctx = this.canPlaySfx("reload_start", 150);
		if (!ctx) return;
		this.playTone(ctx, "triangle", 290, 190, .09, .11);
	}
	playReloadComplete() {
		const ctx = this.canPlaySfx("reload_done", 150);
		if (!ctx) return;
		[410, 620].forEach((freq, i) => {
			this.playTone(ctx, "triangle", freq, freq, .1, .12, i * .055);
		});
	}
};
var soundFX = new SoundFXManager();
// src/game/abilities/AbilitySystem.ts
function fireTankWeapon(tank, projectiles, effects) {
	if (!tank.alive) return "dead";
	if (tank.isReloading) return "reloading";
	if (tank.ammo <= 0) {
		if (tank.startReload() && tank.isPlayer) soundFX.playReloadStart();
		return "empty";
	}
	if (tank.fireCooldownTimer > 0) return "cooldown";
	tank.ammo = Math.max(0, tank.ammo - 1);
	tank.fireCooldownTimer = tank.getEffectiveFireIntervalSec();
	tank.recentAttackTimer = 1.6;
	const tip = tank.getBarrelTip();
	const spawnPos = tank.getMuzzleSpawnPoint();
	const damage = tank.getEffectiveDamage();
	const speed = tank.definition.stats.projectileSpeed;
	const range = tank.getEffectiveProjectileRange();
	const radius = tank.definition.stats.projectileRadius;
	const pierceCount = tank.effectsManager.getPierceCount();
	const slowStrength = tank.definition.passiveAbility.slowStrength ?? 0;
	const slowDurationSec = tank.definition.passiveAbility.slowDurationSec ?? 0;
	const appliesSlow = slowStrength > 0 && slowDurationSec > 0;
	const slowFactor = Math.max(.1, 1 - slowStrength);
	let textureKey = "proj_standard";
	if (pierceCount > 0) textureKey = "proj_pierce";
	else if (tank.definition.id === "tesla") textureKey = "proj_electric";
	else if (tank.definition.id === "artillery") textureKey = "proj_artillery";
	else if (tank.hasBuff("heavy_shell")) textureKey = "proj_heavy";
	const multi = tank.effectsManager.getMultiShotConfig();
	const angles = [];
	if (multi.count <= 1) angles.push(tank.turretAngle);
	else {
		const mid = (multi.count - 1) / 2;
		for (let i = 0; i < multi.count; i++) angles.push(tank.turretAngle + (i - mid) * multi.spreadRad);
	}
	for (const angle of angles) projectiles.spawn({
		owner: tank,
		x: spawnPos.x,
		y: spawnPos.y,
		angle,
		speed,
		damage,
		range,
		radius,
		pierceCount,
		appliesSlow,
		slowFactor,
		slowDurationSec,
		textureKey
	});
	tank.triggerFireRecoil();
	if (tank.definition.id === "tesla") {
		effects.spawnElectricMuzzleFlash(tip.x, tip.y, tank.turretAngle);
		soundFX.playElectricShot(tank.isPlayer);
	} else {
		effects.spawnMuzzleFlash(tip.x, tip.y, tank.turretAngle);
		if (tank.definition.id === "artillery") soundFX.playArtilleryShot(tank.isPlayer);
		else soundFX.playShot(tank.isPlayer);
	}
	if (tank.ammo <= 0) {
		if (tank.startReload() && tank.isPlayer) soundFX.playReloadStart();
	}
	return "fired";
}
function deployTankMine(tank, allTanks, obstacles, projectiles, effects, arenaWidth, arenaHeight) {
	if (!tank.alive || tank.mineCharges <= 0 || tank.mineDeployCooldown > 0) return false;
	if (projectiles.getActiveMineCount(tank.id) >= MINE_SYSTEM_CONFIG.maxActivePerTank || projectiles.getActiveMineCount() >= MINE_SYSTEM_CONFIG.maxActiveGlobal) return false;
	const dropDist = tank.radius + 20;
	const candidateOffsets = [
		0,
		.55,
		-.55,
		1.15,
		-1.15,
		1.75,
		-1.75,
		Math.PI
	];
	for (const offset of candidateOffsets) {
		const ang = tank.hullAngle + Math.PI + offset;
		const mx = tank.x + Math.cos(ang) * dropDist;
		const my = tank.y + Math.sin(ang) * dropDist;
		if (mx < 34 || mx > arenaWidth - 34 || my < 34 || my > arenaHeight - 34) continue;
		let blocked = false;
		for (const obs of obstacles) {
			if (!obs.alive || !obs.blocksMovement) continue;
			if (obs.containsPoint(mx, my, 18)) {
				blocked = true;
				break;
			}
		}
		if (blocked) continue;
		for (const other of allTanks) {
			if (!other.alive) continue;
			if (Math.hypot(other.x - mx, other.y - my) <= other.radius + 18) {
				blocked = true;
				break;
			}
		}
		if (blocked) continue;
		if (!projectiles.canSpawnMine(tank.id)) return false;
		if (!tank.consumeMineCharge()) return false;
		if (!projectiles.spawnMine(tank.id, mx, my, MINE_SYSTEM_CONFIG.durationSec, MINE_SYSTEM_CONFIG.armDelaySec, MINE_SYSTEM_CONFIG.damage)) return false;
		effects.spawnRing(mx, my, 28, 16347926, .25);
		if (tank.isPlayer) {
			soundFX.playMineDeploy();
			effects.spawnFloatingLabel(mx, my, `MINE SET (${tank.mineCharges})`, "#F97316");
		}
		return true;
	}
	return false;
}
function activateTankAbility(tank, allTanks, projectiles, effects, onTankEliminated, context) {
	if (!tank.alive || tank.abilityCooldownTimer > 0 || tank.abilityActiveTimer > 0 || tank.phaseCloaked) return false;
	const spec = tank.definition.activeAbility;
	tank.abilityCooldownTimer = spec.cooldownSec;
	tank.abilityActiveTimer = spec.durationSec;
	if (tank.definition.id === "scout") soundFX.playAfterburner();
	else if (tank.definition.id === "artillery") soundFX.playBarrageLaunch();
	else if (tank.definition.id === "tesla") soundFX.playEmpPulse();
	else if (tank.definition.id === "phantom") soundFX.playPhaseShift();
	else soundFX.playAbility();
	switch (tank.definition.id) {
		case "assault":
			effects.spawnRing(tank.x, tank.y, 48, 14716454, .28);
			if (tank.isPlayer) effects.spawnFloatingLabel(tank.x, tank.y, "RAPID FIRE!", "#F59E0B");
			break;
		case "fortress": {
			const shieldAmount = spec.shieldAmount ?? 80;
			tank.activateShield(shieldAmount, "ability");
			effects.spawnRing(tank.x, tank.y, tank.radius + 26, 3718648, .34);
			if (tank.isPlayer) effects.spawnFloatingLabel(tank.x, tank.y, "FORTRESS SHIELD!", "#38BDF8");
			break;
		}
		case "scout":
			effects.spawnRing(tank.x, tank.y, tank.radius + 28, 16436245, .3);
			effects.spawnAfterburnerExhaust(tank.x - Math.cos(tank.hullAngle) * 18, tank.y - Math.sin(tank.hullAngle) * 18, tank.hullAngle, true);
			if (tank.isPlayer) effects.spawnFloatingLabel(tank.x, tank.y, "AFTERBURNER!", "#FACC15");
			break;
		case "artillery": {
			const tip = tank.getBarrelTip();
			const maxRange = tank.getEffectiveProjectileRange();
			const arenaW = context?.arenaWidth ?? 2200;
			const arenaH = context?.arenaHeight ?? 1600;
			let targetX;
			let targetY;
			if (typeof context?.targetX === "number" && typeof context?.targetY === "number") {
				const dx = context.targetX - tank.x;
				const dy = context.targetY - tank.y;
				const dist = Math.hypot(dx, dy);
				const clampedDist = Math.min(maxRange, Math.max(95, dist));
				const ang = dist > .01 ? Math.atan2(dy, dx) : tank.turretAngle;
				targetX = tank.x + Math.cos(ang) * clampedDist;
				targetY = tank.y + Math.sin(ang) * clampedDist;
			} else {
				const defaultDist = Math.min(440, maxRange * .6);
				targetX = tank.x + Math.cos(tank.turretAngle) * defaultDist;
				targetY = tank.y + Math.sin(tank.turretAngle) * defaultDist;
			}
			targetX = Math.min(arenaW - 32, Math.max(32, targetX));
			targetY = Math.min(arenaH - 32, Math.max(32, targetY));
			projectiles.spawnBarrage({
				owner: tank,
				startX: tip.x,
				startY: tip.y,
				targetX,
				targetY,
				shellCount: spec.barrageShellCount ?? 4,
				impactIntervalSec: spec.barrageImpactIntervalSec ?? .45,
				flightSec: spec.barrageFlightSec ?? .65,
				aoeRadius: spec.barrageAoERadius ?? 88,
				damage: spec.barrageShellDamage ?? tank.getEffectiveDamage(),
				scatterRadius: spec.barrageScatterRadius ?? 68,
				arenaWidth: arenaW,
				arenaHeight: arenaH
			});
			effects.spawnRing(tank.x, tank.y, tank.radius + 26, 15680580, .3);
			effects.spawnMuzzleFlash(tip.x, tip.y, tank.turretAngle);
			if (tank.isPlayer) effects.spawnFloatingLabel(tank.x, tank.y, "SHELL BARRAGE!", "#EF4444");
			break;
		}
		case "tesla": {
			const empRadius = spec.empRadius ?? 220;
			const empSlowStrength = spec.empSlowStrength ?? .45;
			const empSlowDuration = spec.empSlowDurationSec ?? 2.5;
			const empDamage = spec.empDamage ?? 12;
			const empSlowFactor = Math.max(.15, 1 - empSlowStrength);
			effects.spawnEmpPulse(tank.x, tank.y, empRadius);
			for (const other of allTanks) {
				if (!other.alive || other.id === tank.id) continue;
				if (Math.hypot(other.x - tank.x, other.y - tank.y) <= empRadius + other.radius) {
					other.applySlow(empSlowFactor, empSlowDuration, "emp");
					const interrupted = other.interruptMovementAbilities(effects);
					effects.spawnElectricImpact(other.x, other.y);
					let empActualDmg = 0;
					if (empDamage > 0) {
						const res = other.takeDamage(empDamage, "ability");
						tank.damageDealt += res.actualDamage;
						empActualDmg = res.actualDamage;
						if (res.killed) {
							onTankEliminated(other, tank.id);
							continue;
						}
					}
					if (tank.isPlayer || other.isPlayer) {
						if (empActualDmg > 0) effects.spawnDamageNumber(other.x, other.y + 12, empActualDmg, "electric");
						effects.spawnFloatingLabel(other.x, other.y - 10, interrupted ? "INTERRUPTED!" : "EMP DISRUPTED!", "#67E8F9");
					}
				}
			}
			if (tank.isPlayer) effects.spawnFloatingLabel(tank.x, tank.y, "EMP PULSE!", "#22D3EE");
			break;
		}
		case "phantom":
			tank.phaseCloaked = true;
			effects.spawnPhaseShift(tank.x, tank.y, true);
			if (tank.isPlayer) effects.spawnFloatingLabel(tank.x, tank.y, "PHASE SHIFT!", "#A78BFA");
	}
	return true;
}
// src/game/ai/lineOfSight.ts
/**
* Analytical Liang-Barsky slab intersection between segment (x1,y1)->(x2,y2)
* and axis-aligned rectangle [left, right] x [top, bottom]. Zero allocations.
*/
function segmentIntersectsAabb(x1, y1, x2, y2, left, top, right, bottom) {
	if ((x1 > x2 ? x1 : x2) < left || (x1 < x2 ? x1 : x2) > right) return false;
	if ((y1 > y2 ? y1 : y2) < top || (y1 < y2 ? y1 : y2) > bottom) return false;
	const dx = x2 - x1;
	const dy = y2 - y1;
	let tMin = 0;
	let tMax = 1;
	if (Math.abs(dx) < 1e-8) {
		if (x1 < left || x1 > right) return false;
	} else {
		const invDx = 1 / dx;
		let t1 = (left - x1) * invDx;
		let t2 = (right - x1) * invDx;
		if (t1 > t2) {
			const tmp = t1;
			t1 = t2;
			t2 = tmp;
		}
		if (t1 > tMin) tMin = t1;
		if (t2 < tMax) tMax = t2;
		if (tMin > tMax) return false;
	}
	if (Math.abs(dy) < 1e-8) {
		if (y1 < top || y1 > bottom) return false;
	} else {
		const invDy = 1 / dy;
		let t1 = (top - y1) * invDy;
		let t2 = (bottom - y1) * invDy;
		if (t1 > t2) {
			const tmp = t1;
			t1 = t2;
			t2 = tmp;
		}
		if (t1 > tMin) tMin = t1;
		if (t2 < tMax) tMax = t2;
		if (tMin > tMax) return false;
	}
	return tMin <= tMax;
}
function hasLineOfSightObstacles(x1, y1, x2, y2, obstacles, padding = 2) {
	for (let i = 0; i < obstacles.length; i++) {
		const obs = obstacles[i];
		if (!obs.alive || !obs.blocksProjectiles) continue;
		if (segmentIntersectsAabb(x1, y1, x2, y2, obs.left - padding, obs.top - padding, obs.right + padding, obs.bottom + padding)) return false;
	}
	return true;
}
// src/game/ai/AIController.ts
/**
* Modular AI Controller
* Uses periodic decision updates (~150ms) to keep mobile CPU cost low
* while interacting with the exact same game rules as the human player.
*/
var AIController = class {
	constructor() {
		this.decisionTimer = Math.random() * .15;
		this.wanderAngle = Math.random() * Math.PI * 2;
		this.wanderTimer = 1 + Math.random() * 1.5;
		this.strafeSign = Math.random() > .5 ? 1 : -1;
		this.lastX = 0;
		this.lastY = 0;
		this.stuckTimer = 0;
		this.cachedMoveX = 0;
		this.cachedMoveY = 0;
		this.cachedAimAngle = 0;
		this.cachedFire = false;
		this.cachedAbility = false;
		this.engageGraceTimer = 1.2 + Math.random() * .8;
		this.aimJitter = 0;
		this.currentTargetId = null;
		this.postShotCooldown = 0;
		this.detourTimer = 0;
		this.detourAngle = 0;
	}
	update(dt, self, allTanks, obstacles, powerups, projectiles, arenaWidth, arenaHeight) {
		if (!self.alive) {
			this.currentTargetId = null;
			this.detourTimer = 0;
			return {
				moveX: 0,
				moveY: 0,
				aimAngle: self.turretAngle,
				shouldFire: false,
				shouldUseAbility: false,
				shouldDeployMine: false
			};
		}
		if (this.engageGraceTimer > 0) this.engageGraceTimer = Math.max(0, this.engageGraceTimer - dt);
		if (this.postShotCooldown > 0) this.postShotCooldown = Math.max(0, this.postShotCooldown - dt);
		if (this.detourTimer > 0) this.detourTimer = Math.max(0, this.detourTimer - dt);
		this.decisionTimer -= dt;
		if (this.decisionTimer > 0) return {
			moveX: this.cachedMoveX,
			moveY: this.cachedMoveY,
			aimAngle: this.cachedAimAngle,
			shouldFire: false,
			shouldUseAbility: false,
			shouldDeployMine: false
		};
		const stepDt = .15;
		this.decisionTimer = stepDt + Math.random() * .05;
		this.aimJitter = (Math.random() - .5) * .34;
		const stuckThreshold = self.definition.id === "scout" || self.definition.id === "phantom" || self.personality === "mobile" ? .34 : .48;
		if (Math.hypot(this.cachedMoveX, this.cachedMoveY) > .25 && Math.hypot(self.x - this.lastX, self.y - this.lastY) < 7) {
			this.stuckTimer += stepDt;
			if (this.stuckTimer >= stuckThreshold) {
				const baseAng = Math.atan2(this.cachedMoveY, this.cachedMoveX);
				this.detourAngle = this.pickClearDetourAngle(self, baseAng, obstacles, arenaWidth, arenaHeight);
				this.wanderAngle = this.detourAngle;
				this.detourTimer = .82;
				this.strafeSign *= -1;
				this.stuckTimer = 0;
			}
		} else this.stuckTimer = 0;
		this.lastX = self.x;
		this.lastY = self.y;
		const selfRadarRadius = self.effectsManager.getRadarRadius();
		const selfHasRadar = selfRadarRadius > 0;
		const baseDetectRange = selfHasRadar ? Math.max(860, selfRadarRadius) : self.definition.id === "artillery" ? Math.max(620, self.getEffectiveProjectileRange() * .96) : 620;
		let bestTarget = null;
		let bestHasLos = false;
		let bestTargetDist = Infinity;
		let bestScore = -Infinity;
		for (const other of allTanks) {
			if (!other.alive || other.id === self.id) continue;
			const dist = Math.hypot(other.x - self.x, other.y - self.y);
			let effectiveRange = baseDetectRange * other.getEffectiveDetectionMultiplier();
			if (other.recentAttackTimer > 0) effectiveRange = Math.max(effectiveRange, baseDetectRange * .92);
			if (selfHasRadar && dist <= selfRadarRadius) effectiveRange = Math.max(effectiveRange, selfRadarRadius);
			else {
				if (other.concealed) effectiveRange *= .42;
				if (other.phaseCloaked) effectiveRange *= .55;
			}
			if (dist > effectiveRange) continue;
			const hasLos = this.hasLineOfSight(self.x, self.y, other.x, other.y, obstacles);
			let score = (750 - dist) * .55;
			if (hasLos) score += 260;
			if (other.id === this.currentTargetId && hasLos) score += 140;
			let otherAttackers = 0;
			const peerRangeSq = 211600;
			for (const peer of allTanks) {
				if (!peer.alive || peer.id === self.id || peer.id === other.id || peer.isPlayer) continue;
				const pdx = other.x - peer.x;
				const pdy = other.y - peer.y;
				if (pdx * pdx + pdy * pdy > peerRangeSq) continue;
				const angleToOther = Math.atan2(pdy, pdx);
				if (Math.abs(__webpack_exports__default.Math.Angle.Wrap(angleToOther - peer.turretAngle)) < .5) otherAttackers += 1;
			}
			score -= otherAttackers * 190;
			if (self.personality === "opportunistic" && other.hp < other.maxHp * .45) score += 110;
			if (self.personality === "aggressive") score += (600 - dist) * .25;
			if (score > bestScore) {
				bestScore = score;
				bestTarget = other;
				bestHasLos = hasLos;
				bestTargetDist = dist;
			}
		}
		this.currentTargetId = bestTarget ? bestTarget.id : null;
		let targetPowerup = null;
		let bestPwrDist = Infinity;
		let bestPwrUtility = 0;
		const maxSearchRadius = (self.personality === "opportunistic" ? 460 : 340) + (self.hp < self.maxHp * .5 ? 140 : 0);
		for (const pwr of powerups) {
			const d = Math.hypot(pwr.x - self.x, pwr.y - self.y);
			if (d > maxSearchRadius) continue;
			const utility = this.evaluatePowerupUtility(self, pwr, d, obstacles);
			if (utility > bestPwrUtility) {
				bestPwrUtility = utility;
				targetPowerup = pwr;
				bestPwrDist = d;
			}
		}
		const shouldSeekPowerup = Boolean(targetPowerup) && (!Boolean(bestTarget && bestHasLos && bestTargetDist < 290) || bestPwrDist < 145 || self.hp < self.maxHp * .42 && (targetPowerup?.id === "repair_kit" || targetPowerup?.id === "shield"));
		let steerX = 0;
		let steerY = 0;
		const threat = projectiles.getActiveThreatNear(self.x, self.y, 130, self.id);
		if (threat) {
			const perpX = -threat.vy;
			const perpY = threat.vx;
			const plen = Math.hypot(perpX, perpY) || 1;
			steerX += perpX / plen * 1.4 * this.strafeSign;
			steerY += perpY / plen * 1.4 * this.strafeSign;
		}
		if (this.detourTimer > 0) {
			steerX += Math.cos(this.detourAngle) * 1.65;
			steerY += Math.sin(this.detourAngle) * 1.65;
		} else if (targetPowerup && shouldSeekPowerup) {
			const ang = Math.atan2(targetPowerup.y - self.y, targetPowerup.x - self.x);
			steerX += Math.cos(ang);
			steerY += Math.sin(ang);
		} else if (bestTarget) {
			const distToTarget = Math.hypot(bestTarget.x - self.x, bestTarget.y - self.y);
			const angToTarget = Math.atan2(bestTarget.y - self.y, bestTarget.x - self.x);
			const desiredRange = self.definition.id === "artillery" ? 455 : self.definition.id === "tesla" ? 275 : self.definition.id === "phantom" ? 285 : self.personality === "aggressive" ? 180 : self.personality === "defensive" ? 360 : self.definition.id === "scout" ? 250 : 265;
			let nearbyCount = 0;
			let crowdCenterX = 0;
			let crowdCenterY = 0;
			if (self.definition.id === "tesla" || self.definition.id === "phantom") {
				const crowdRangeSq = 75625;
				for (const other of allTanks) {
					if (!other.alive || other.id === self.id) continue;
					const odx = other.x - self.x;
					const ody = other.y - self.y;
					if (odx * odx + ody * ody <= crowdRangeSq) {
						nearbyCount += 1;
						crowdCenterX += other.x;
						crowdCenterY += other.y;
					}
				}
			}
			const hpLow = self.hp < self.maxHp * (self.definition.id === "scout" || self.definition.id === "phantom" ? .44 : .35);
			if (self.definition.id === "phantom" && self.phaseCloaked) {
				const awayAng = nearbyCount > 0 ? Math.atan2(self.y - crowdCenterY / nearbyCount, self.x - crowdCenterX / nearbyCount) : angToTarget + Math.PI;
				steerX += Math.cos(awayAng) * 1.2;
				steerY += Math.sin(awayAng) * 1.2;
			} else if (nearbyCount >= 2) {
				const avgX = crowdCenterX / nearbyCount;
				const avgY = crowdCenterY / nearbyCount;
				const awayAng = Math.atan2(self.y - avgY, self.x - avgX);
				steerX += Math.cos(awayAng) * 1.25;
				steerY += Math.sin(awayAng) * 1.25;
			} else if (hpLow && self.personality !== "aggressive") {
				steerX -= Math.cos(angToTarget);
				steerY -= Math.sin(angToTarget);
			} else if (distToTarget > desiredRange + 45) {
				steerX += Math.cos(angToTarget);
				steerY += Math.sin(angToTarget);
			} else if (distToTarget < desiredRange - (self.definition.id === "artillery" ? 95 : 55)) {
				steerX -= Math.cos(angToTarget) * (self.definition.id === "artillery" ? 1.05 : .85);
				steerY -= Math.sin(angToTarget) * (self.definition.id === "artillery" ? 1.05 : .85);
			}
			const strafeWeight = self.definition.id === "scout" || self.personality === "mobile" ? 1.25 : self.definition.id === "phantom" ? 1.15 : self.definition.id === "artillery" ? .82 : self.definition.id === "tesla" ? .85 : .72;
			steerX += Math.cos(angToTarget + Math.PI / 2 * this.strafeSign) * strafeWeight;
			steerY += Math.sin(angToTarget + Math.PI / 2 * this.strafeSign) * strafeWeight;
		} else {
			this.wanderTimer -= stepDt;
			if (this.wanderTimer <= 0) {
				this.wanderTimer = 1.6 + Math.random() * 1.8;
				if (self.x < 260 || self.x > arenaWidth - 260 || self.y < 200 || self.y > arenaHeight - 200) {
					const centerAngle = Math.atan2(arenaHeight / 2 - self.y, arenaWidth / 2 - self.x);
					this.wanderAngle = centerAngle + (Math.random() - .5) * 1.4;
				} else this.wanderAngle += (Math.random() - .5) * 2.2;
			}
			steerX += Math.cos(this.wanderAngle);
			steerY += Math.sin(this.wanderAngle);
		}
		const margin = 84;
		if (self.x < margin) steerX += 1.75;
		if (self.x > arenaWidth - margin) steerX -= 1.75;
		if (self.y < margin) steerY += 1.75;
		if (self.y > arenaHeight - margin) steerY -= 1.75;
		const avoidMargin = self.radius + 36;
		const avoidMarginSq = avoidMargin * avoidMargin;
		const dangerRange = 155;
		const dangerRangeSq = 24025;
		for (const obs of obstacles) {
			if (!obs.alive) continue;
			if (obs.isPriming) {
				const bx = self.x - obs.x;
				const by = self.y - obs.y;
				const bDistSq = bx * bx + by * by;
				if (bDistSq < dangerRangeSq && bDistSq > 1e-4) {
					const bd = Math.sqrt(bDistSq);
					const flee = (dangerRange - bd) / dangerRange * 2.8;
					steerX += bx / bd * flee;
					steerY += by / bd * flee;
				}
				continue;
			}
			if (!obs.blocksMovement) continue;
			const closestX = __webpack_exports__default.Math.Clamp(self.x, obs.left, obs.right);
			const closestY = __webpack_exports__default.Math.Clamp(self.y, obs.top, obs.bottom);
			const dx = self.x - closestX;
			const dy = self.y - closestY;
			const distSq = dx * dx + dy * dy;
			if (distSq >= avoidMarginSq) continue;
			const d = Math.sqrt(distSq);
			{
				let nx;
				let ny;
				if (d > .01) {
					nx = dx / d;
					ny = dy / d;
				} else {
					const cdx = self.x - obs.x;
					const cdy = self.y - obs.y;
					const cd = Math.hypot(cdx, cdy) || 1;
					nx = cdx / cd;
					ny = cdy / cd;
				}
				const strength = (avoidMargin - d) / avoidMargin;
				const pushWeight = obs.type === "water" ? 2.35 : 2.05;
				steerX += nx * strength * pushWeight;
				steerY += ny * strength * pushWeight;
				if (steerX * nx + steerY * ny < 0) {
					const tx = -ny * this.strafeSign;
					const ty = nx * this.strafeSign;
					steerX += tx * strength * 1.45;
					steerY += ty * strength * 1.45;
				}
			}
		}
		const steerMag = Math.hypot(steerX, steerY);
		if (steerMag > .05) {
			this.cachedMoveX = steerX / steerMag;
			this.cachedMoveY = steerY / steerMag;
		} else {
			this.cachedMoveX = 0;
			this.cachedMoveY = 0;
		}
		this.cachedFire = false;
		this.cachedAbility = false;
		let abilityTargetX;
		let abilityTargetY;
		if (bestTarget) {
			const dist = Math.hypot(bestTarget.x - self.x, bestTarget.y - self.y);
			const timeToHit = dist / self.definition.stats.projectileSpeed;
			const leadX = bestTarget.x + bestTarget.vx * timeToHit * .2;
			const leadY = bestTarget.y + bestTarget.vy * timeToHit * .2;
			this.cachedAimAngle = Math.atan2(leadY - self.y, leadX - self.x) + this.aimJitter;
			const hasLos = bestHasLos;
			const turretAligned = Math.abs(__webpack_exports__default.Math.Angle.Wrap(this.cachedAimAngle - self.turretAngle)) < .32;
			const maxFireRange = self.getEffectiveProjectileRange() * 1.01;
			const hasRapidFire = self.abilityActiveTimer > 0 && Boolean(self.definition.activeAbility.fireRateMultiplier) || self.hasBuff("rapid_fire");
			if (this.engageGraceTimer <= 0 && !self.isReloading && self.ammo > 0 && self.fireCooldownTimer <= 0 && this.postShotCooldown <= 0 && hasLos && turretAligned && dist <= maxFireRange && (hasRapidFire || Math.random() < .72)) {
				this.cachedFire = true;
				this.postShotCooldown = hasRapidFire ? .14 + Math.random() * .12 : .24 + Math.random() * .26;
			}
			if (this.engageGraceTimer <= 0 && self.abilityCooldownTimer <= 0 && self.abilityActiveTimer <= 0) {
				if (self.definition.id === "fortress") {
					if (self.shieldHp <= 0 && (self.hp < self.maxHp * .85 || hasLos && dist < 380)) this.cachedAbility = true;
				} else if (self.definition.id === "scout") {
					const underThreat = Boolean(threat) || self.hp < self.maxHp * .55;
					const flankingMove = hasLos && dist > 235 && dist < 490 && self.ammo >= 3 && !self.isReloading;
					if (underThreat || flankingMove) this.cachedAbility = true;
				} else if (self.definition.id === "artillery") {
					const maxBarrageRange = self.getEffectiveProjectileRange() * .94;
					const targetSpeed = Math.hypot(bestTarget.vx, bestTarget.vy);
					let nearbyCluster = 0;
					const clusterRangeSq = 28900;
					for (const peer of allTanks) {
						if (!peer.alive || peer.id === self.id || peer.id === bestTarget.id) continue;
						const pdx = peer.x - bestTarget.x;
						const pdy = peer.y - bestTarget.y;
						if (pdx * pdx + pdy * pdy <= clusterRangeSq) nearbyCluster += 1;
					}
					if (dist >= 165 && dist <= maxBarrageRange && (targetSpeed < 175 || nearbyCluster > 0 || hasLos && dist >= 250)) {
						this.cachedAbility = true;
						abilityTargetX = bestTarget.x + bestTarget.vx * .35;
						abilityTargetY = bestTarget.y + bestTarget.vy * .35;
					}
				} else if (self.definition.id === "tesla") {
					const empRadius = self.definition.activeAbility.empRadius ?? 220;
					let enemiesInEmp = 0;
					let minEmpDist = Infinity;
					let enemyUsingMoveAbility = false;
					for (const other of allTanks) {
						if (!other.alive || other.id === self.id) continue;
						const d = Math.hypot(other.x - self.x, other.y - self.y);
						if (d <= empRadius + other.radius) {
							enemiesInEmp += 1;
							if (d < minEmpDist) minEmpDist = d;
							if (other.abilityActiveTimer > 0 && Boolean(other.definition.activeAbility.speedBoostMultiplier)) enemyUsingMoveAbility = true;
						}
					}
					if (enemiesInEmp >= 2 || enemiesInEmp >= 1 && (minEmpDist <= empRadius * .72 || enemyUsingMoveAbility || self.hp < self.maxHp * .58)) this.cachedAbility = true;
				} else if (self.definition.id === "phantom") {
					let closeEnemies = 0;
					const closeRangeSq = 115600;
					for (const other of allTanks) {
						if (!other.alive || other.id === self.id) continue;
						const odx = other.x - self.x;
						const ody = other.y - self.y;
						if (odx * odx + ody * ody <= closeRangeSq) closeEnemies += 1;
					}
					const incomingDanger = Boolean(threat) || closeEnemies >= 2;
					const pressuredWhileHurt = hasLos && dist <= 380 && (self.hp < self.maxHp * .68 || dist <= 225 && (self.isReloading || self.ammo <= 1));
					if (incomingDanger || pressuredWhileHurt) this.cachedAbility = true;
				} else if (self.definition.id === "assault") {
					if (hasLos && dist <= 470 && self.ammo >= 4 && !self.isReloading) this.cachedAbility = true;
				} else if (hasLos && dist < 380 && self.ammo > 0 && !self.isReloading && Math.random() < .15) this.cachedAbility = true;
			}
		} else {
			if (!self.isReloading && self.ammo > 0 && self.ammo <= Math.floor(self.maxAmmo * .35)) self.startReload();
			this.cachedAimAngle = steerMag > .1 ? Math.atan2(this.cachedMoveY, this.cachedMoveX) : self.hullAngle;
			if (this.engageGraceTimer <= 0 && !self.isReloading && self.ammo > 0 && self.fireCooldownTimer <= 0 && this.postShotCooldown <= 0) {
				const roamClearRangeSq = 14400;
				for (const obs of obstacles) {
					if (!obs.alive || !obs.destructible) continue;
					if (obs.type === "barrel") continue;
					const odx = obs.x - self.x;
					const ody = obs.y - self.y;
					if (odx * odx + ody * ody < roamClearRangeSq) {
						this.cachedAimAngle = Math.atan2(ody, odx);
						this.cachedFire = true;
						this.postShotCooldown = .3 + Math.random() * .25;
						break;
					}
				}
			}
		}
		const shouldDeployMine = this.engageGraceTimer <= 0 && self.mineCharges > 0 && self.mineDeployCooldown <= 0 && projectiles.getActiveMineCount(self.id) < MINE_SYSTEM_CONFIG.maxActivePerTank && (bestTarget !== null && bestTargetDist <= 285 || Boolean(threat) && projectiles.getActiveMineCount(self.id) === 0);
		return {
			moveX: this.cachedMoveX,
			moveY: this.cachedMoveY,
			aimAngle: this.cachedAimAngle,
			shouldFire: this.cachedFire,
			shouldUseAbility: this.cachedAbility,
			shouldDeployMine,
			abilityTargetX,
			abilityTargetY
		};
	}
	evaluatePowerupUtility(self, pwr, dist, obstacles) {
		const barrelDangerSq = 21025;
		for (const obs of obstacles) {
			if (!obs.alive || !obs.isPriming) continue;
			const dx = obs.x - pwr.x;
			const dy = obs.y - pwr.y;
			if (dx * dx + dy * dy < barrelDangerSq) return -Infinity;
		}
		const hpRatio = self.hp / Math.max(1, self.maxHp);
		let baseValue = 0;
		switch (pwr.id) {
			case "repair_kit":
				if (hpRatio >= .92) return -Infinity;
				baseValue = (1 - hpRatio) * 185;
				break;
			case "mine_kit":
				if (self.mineCharges >= MINE_SYSTEM_CONFIG.maxCarriedCharges) return -Infinity;
				baseValue = self.mineCharges === 0 ? 78 : 42;
				break;
			case "shield":
				if (self.shieldHp >= 45) baseValue = 18;
				else baseValue = hpRatio < .7 ? 118 : 88;
				break;
			case "cooldown_boost":
				baseValue = self.abilityCooldownTimer > 2 ? 86 : 36;
				break;
			case "rapid_fire":
				baseValue = self.hasBuff("rapid_fire") ? 24 : 92;
				break;
			case "heavy_shell":
				baseValue = self.hasBuff("heavy_shell") ? 24 : 90;
				break;
			case "multi_shot":
				baseValue = self.hasBuff("multi_shot") ? 22 : 84;
				break;
			case "piercing_shell":
				baseValue = self.hasBuff("piercing_shell") ? 20 : 76;
				break;
			case "speed_boost":
				baseValue = self.hasBuff("speed_boost") ? 18 : 74;
				break;
			case "radar": baseValue = self.hasBuff("radar") ? 16 : 68;
		}
		if (self.personality === "opportunistic") baseValue *= 1.15;
		return baseValue - dist * .16;
	}
	pickClearDetourAngle(self, blockedAngle, obstacles, arenaWidth, arenaHeight) {
		const sign = this.strafeSign;
		const offsets = [
			sign * 1.05,
			-sign * 1.05,
			sign * 1.75,
			-sign * 1.75,
			sign * 2.45,
			-sign * 2.45,
			Math.PI
		];
		const probeDist = self.radius + 54;
		let bestAngle = blockedAngle + sign * 1.57;
		let bestClearScore = -Infinity;
		for (const off of offsets) {
			const cand = blockedAngle + off;
			const px = self.x + Math.cos(cand) * probeDist;
			const py = self.y + Math.sin(cand) * probeDist;
			if (px < 52 || px > arenaWidth - 52 || py < 52 || py > arenaHeight - 52) continue;
			let minClear = Infinity;
			for (const obs of obstacles) {
				if (!obs.alive || !obs.blocksMovement) continue;
				const cx = __webpack_exports__default.Math.Clamp(px, obs.left, obs.right);
				const cy = __webpack_exports__default.Math.Clamp(py, obs.top, obs.bottom);
				const d = Math.hypot(px - cx, py - cy);
				if (d < minClear) minClear = d;
			}
			if (minClear >= self.radius + 14) return cand;
			if (minClear > bestClearScore) {
				bestClearScore = minClear;
				bestAngle = cand;
			}
		}
		return bestAngle;
	}
	hasLineOfSight(x1, y1, x2, y2, obstacles) {
		return hasLineOfSightObstacles(x1, y1, x2, y2, obstacles, 2);
	}
};
// src/game/arenas/arenaLayouts.ts
var ARENA_WIDTH = 2080;
var ARENA_HEIGHT = 1200;
var STANDARD_SPAWNS = [
	{
		x: 230,
		y: 160,
		angle: Math.atan2(440, 810)
	},
	{
		x: 1040,
		y: 135,
		angle: Math.PI / 2
	},
	{
		x: 1850,
		y: 160,
		angle: Math.atan2(440, -810)
	},
	{
		x: 1945,
		y: 600,
		angle: Math.PI
	},
	{
		x: 1850,
		y: 1040,
		angle: Math.atan2(-440, -810)
	},
	{
		x: 1040,
		y: 1065,
		angle: -Math.PI / 2
	},
	{
		x: 230,
		y: 1040,
		angle: Math.atan2(-440, 810)
	},
	{
		x: 135,
		y: 600,
		angle: 0
	}
];
var ARENA_DEFINITIONS = {
	training_grounds: {
		id: "training_grounds",
		name: "Training Grounds",
		subtitle: "Proving Yard",
		identity: "Beginner-friendly and balanced",
		description: "Open military proving yard with wide flanking lanes, scattered training cover, destructible wooden structures, and clear multi-angle routes.",
		features: [
			"Large open combat spaces",
			"Destructible wooden crates",
			"Balanced brick & steel cover",
			"Multiple flanking routes"
		],
		width: ARENA_WIDTH,
		height: ARENA_HEIGHT,
		groundColor: "#C8B894",
		groundGridColor: "#B5A37E",
		borderColor: "#4A4336",
		themeAccent: "#E08E26",
		spawns: STANDARD_SPAWNS,
		obstacles: [
			{
				type: "steel",
				x: 840,
				y: 440,
				w: 68,
				h: 68
			},
			{
				type: "steel",
				x: 1240,
				y: 440,
				w: 68,
				h: 68
			},
			{
				type: "steel",
				x: 840,
				y: 760,
				w: 68,
				h: 68
			},
			{
				type: "steel",
				x: 1240,
				y: 760,
				w: 68,
				h: 68
			},
			{
				type: "brick",
				x: 1040,
				y: 365,
				w: 136,
				h: 42
			},
			{
				type: "brick",
				x: 1040,
				y: 835,
				w: 136,
				h: 42
			},
			{
				type: "brick",
				x: 660,
				y: 600,
				w: 44,
				h: 132
			},
			{
				type: "brick",
				x: 1420,
				y: 600,
				w: 44,
				h: 132
			},
			{
				type: "brick",
				x: 465,
				y: 315,
				w: 116,
				h: 44
			},
			{
				type: "brick",
				x: 1615,
				y: 315,
				w: 116,
				h: 44
			},
			{
				type: "brick",
				x: 465,
				y: 885,
				w: 116,
				h: 44
			},
			{
				type: "brick",
				x: 1615,
				y: 885,
				w: 116,
				h: 44
			},
			{
				type: "brick",
				x: 660,
				y: 195,
				w: 88,
				h: 40
			},
			{
				type: "brick",
				x: 1420,
				y: 195,
				w: 88,
				h: 40
			},
			{
				type: "brick",
				x: 660,
				y: 1005,
				w: 88,
				h: 40
			},
			{
				type: "brick",
				x: 1420,
				y: 1005,
				w: 88,
				h: 40
			},
			{
				type: "crate",
				x: 500,
				y: 450,
				w: 50,
				h: 50
			},
			{
				type: "crate",
				x: 557,
				y: 450,
				w: 50,
				h: 50
			},
			{
				type: "crate",
				x: 1580,
				y: 450,
				w: 50,
				h: 50
			},
			{
				type: "crate",
				x: 1523,
				y: 450,
				w: 50,
				h: 50
			},
			{
				type: "crate",
				x: 500,
				y: 750,
				w: 50,
				h: 50
			},
			{
				type: "crate",
				x: 557,
				y: 750,
				w: 50,
				h: 50
			},
			{
				type: "crate",
				x: 1580,
				y: 750,
				w: 50,
				h: 50
			},
			{
				type: "crate",
				x: 1523,
				y: 750,
				w: 50,
				h: 50
			},
			{
				type: "crate",
				x: 935,
				y: 600,
				w: 48,
				h: 48
			},
			{
				type: "crate",
				x: 1145,
				y: 600,
				w: 48,
				h: 48
			},
			{
				type: "crate",
				x: 325,
				y: 455,
				w: 48,
				h: 48
			},
			{
				type: "crate",
				x: 1755,
				y: 745,
				w: 48,
				h: 48
			},
			{
				type: "water",
				x: 840,
				y: 245,
				w: 144,
				h: 70
			},
			{
				type: "water",
				x: 1240,
				y: 955,
				w: 144,
				h: 70
			},
			{
				type: "bush",
				x: 375,
				y: 600,
				w: 94,
				h: 94
			},
			{
				type: "bush",
				x: 1705,
				y: 600,
				w: 94,
				h: 94
			},
			{
				type: "bush",
				x: 1040,
				y: 600,
				w: 104,
				h: 82
			},
			{
				type: "bush",
				x: 840,
				y: 960,
				w: 102,
				h: 76
			},
			{
				type: "bush",
				x: 1240,
				y: 240,
				w: 102,
				h: 76
			},
			{
				type: "bush",
				x: 475,
				y: 175,
				w: 84,
				h: 68
			},
			{
				type: "bush",
				x: 1605,
				y: 1025,
				w: 84,
				h: 68
			},
			{
				type: "barrel",
				x: 685,
				y: 445,
				w: 40,
				h: 40
			},
			{
				type: "barrel",
				x: 1395,
				y: 445,
				w: 40,
				h: 40
			},
			{
				type: "barrel",
				x: 685,
				y: 755,
				w: 40,
				h: 40
			},
			{
				type: "barrel",
				x: 1395,
				y: 755,
				w: 40,
				h: 40
			},
			{
				type: "barrel",
				x: 685,
				y: 330,
				w: 40,
				h: 40
			},
			{
				type: "barrel",
				x: 1395,
				y: 870,
				w: 40,
				h: 40
			}
		]
	},
	industrial_zone: {
		id: "industrial_zone",
		name: "Industrial Zone",
		subtitle: "Foundry Depot",
		identity: "Tactical positioning and obstacle management",
		description: "Abandoned heavy foundry with steel warehouse bays, narrow tactical corridors mixed with open yards, cargo crates, and volatile fuel drums.",
		features: [
			"Steel warehouse structures",
			"Narrow choke & flank passages",
			"Destructible cargo crates",
			"Explosive barrel traps"
		],
		width: ARENA_WIDTH,
		height: ARENA_HEIGHT,
		groundColor: "#99A0A4",
		groundGridColor: "#828A8E",
		borderColor: "#363C40",
		themeAccent: "#38BDF8",
		spawns: STANDARD_SPAWNS,
		obstacles: [
			{
				type: "steel",
				x: 470,
				y: 310,
				w: 170,
				h: 44
			},
			{
				type: "steel",
				x: 470,
				y: 890,
				w: 170,
				h: 44
			},
			{
				type: "steel",
				x: 350,
				y: 455,
				w: 44,
				h: 120
			},
			{
				type: "steel",
				x: 350,
				y: 745,
				w: 44,
				h: 120
			},
			{
				type: "brick",
				x: 615,
				y: 445,
				w: 44,
				h: 100
			},
			{
				type: "brick",
				x: 615,
				y: 755,
				w: 44,
				h: 100
			},
			{
				type: "steel",
				x: 1610,
				y: 310,
				w: 170,
				h: 44
			},
			{
				type: "steel",
				x: 1610,
				y: 890,
				w: 170,
				h: 44
			},
			{
				type: "steel",
				x: 1730,
				y: 455,
				w: 44,
				h: 120
			},
			{
				type: "steel",
				x: 1730,
				y: 745,
				w: 44,
				h: 120
			},
			{
				type: "brick",
				x: 1465,
				y: 445,
				w: 44,
				h: 100
			},
			{
				type: "brick",
				x: 1465,
				y: 755,
				w: 44,
				h: 100
			},
			{
				type: "steel",
				x: 1040,
				y: 600,
				w: 96,
				h: 96
			},
			{
				type: "brick",
				x: 825,
				y: 310,
				w: 46,
				h: 112
			},
			{
				type: "brick",
				x: 1255,
				y: 310,
				w: 46,
				h: 112
			},
			{
				type: "brick",
				x: 825,
				y: 890,
				w: 46,
				h: 112
			},
			{
				type: "brick",
				x: 1255,
				y: 890,
				w: 46,
				h: 112
			},
			{
				type: "crate",
				x: 485,
				y: 565,
				w: 50,
				h: 50
			},
			{
				type: "crate",
				x: 485,
				y: 635,
				w: 50,
				h: 50
			},
			{
				type: "crate",
				x: 1595,
				y: 565,
				w: 50,
				h: 50
			},
			{
				type: "crate",
				x: 1595,
				y: 635,
				w: 50,
				h: 50
			},
			{
				type: "crate",
				x: 825,
				y: 550,
				w: 48,
				h: 48
			},
			{
				type: "crate",
				x: 825,
				y: 650,
				w: 48,
				h: 48
			},
			{
				type: "crate",
				x: 1255,
				y: 550,
				w: 48,
				h: 48
			},
			{
				type: "crate",
				x: 1255,
				y: 650,
				w: 48,
				h: 48
			},
			{
				type: "crate",
				x: 635,
				y: 185,
				w: 50,
				h: 50
			},
			{
				type: "crate",
				x: 1445,
				y: 1015,
				w: 50,
				h: 50
			},
			{
				type: "water",
				x: 1040,
				y: 310,
				w: 152,
				h: 72
			},
			{
				type: "water",
				x: 1040,
				y: 890,
				w: 152,
				h: 72
			},
			{
				type: "bush",
				x: 645,
				y: 600,
				w: 92,
				h: 92
			},
			{
				type: "bush",
				x: 1435,
				y: 600,
				w: 92,
				h: 92
			},
			{
				type: "bush",
				x: 690,
				y: 270,
				w: 86,
				h: 72
			},
			{
				type: "bush",
				x: 1390,
				y: 930,
				w: 86,
				h: 72
			},
			{
				type: "bush",
				x: 1390,
				y: 270,
				w: 86,
				h: 72
			},
			{
				type: "bush",
				x: 690,
				y: 930,
				w: 86,
				h: 72
			},
			{
				type: "barrel",
				x: 925,
				y: 465,
				w: 40,
				h: 40
			},
			{
				type: "barrel",
				x: 1155,
				y: 735,
				w: 40,
				h: 40
			},
			{
				type: "barrel",
				x: 725,
				y: 460,
				w: 40,
				h: 40
			},
			{
				type: "barrel",
				x: 1355,
				y: 740,
				w: 40,
				h: 40
			},
			{
				type: "barrel",
				x: 925,
				y: 735,
				w: 40,
				h: 40
			},
			{
				type: "barrel",
				x: 1155,
				y: 465,
				w: 40,
				h: 40
			}
		]
	},
	wasteland: {
		id: "wasteland",
		name: "Wasteland",
		subtitle: "Scorched Flats",
		identity: "Open combat with limited cover",
		description: "Dry sun-baked battlefield with open sightlines, sparse ruined outpost walls, oasis hazards, ambush scrub, and weathered terrain.",
		features: [
			"Wide open combat flats",
			"Sparse abandoned ruins",
			"Oasis water hazards",
			"Desert terrain decoration"
		],
		width: ARENA_WIDTH,
		height: ARENA_HEIGHT,
		groundColor: "#C59B6D",
		groundGridColor: "#AE8456",
		borderColor: "#4E3724",
		themeAccent: "#F97316",
		spawns: STANDARD_SPAWNS,
		obstacles: [
			{
				type: "brick",
				x: 625,
				y: 345,
				w: 120,
				h: 42
			},
			{
				type: "brick",
				x: 1455,
				y: 345,
				w: 120,
				h: 42
			},
			{
				type: "brick",
				x: 625,
				y: 855,
				w: 120,
				h: 42
			},
			{
				type: "brick",
				x: 1455,
				y: 855,
				w: 120,
				h: 42
			},
			{
				type: "brick",
				x: 1040,
				y: 440,
				w: 96,
				h: 40
			},
			{
				type: "brick",
				x: 1040,
				y: 760,
				w: 96,
				h: 40
			},
			{
				type: "steel",
				x: 375,
				y: 600,
				w: 66,
				h: 66
			},
			{
				type: "steel",
				x: 1705,
				y: 600,
				w: 66,
				h: 66
			},
			{
				type: "steel",
				x: 825,
				y: 600,
				w: 60,
				h: 60
			},
			{
				type: "steel",
				x: 1255,
				y: 600,
				w: 60,
				h: 60
			},
			{
				type: "water",
				x: 560,
				y: 600,
				w: 108,
				h: 132
			},
			{
				type: "water",
				x: 1520,
				y: 600,
				w: 108,
				h: 132
			},
			{
				type: "bush",
				x: 1040,
				y: 600,
				w: 118,
				h: 88
			},
			{
				type: "bush",
				x: 790,
				y: 265,
				w: 102,
				h: 80
			},
			{
				type: "bush",
				x: 1290,
				y: 265,
				w: 102,
				h: 80
			},
			{
				type: "bush",
				x: 790,
				y: 935,
				w: 102,
				h: 80
			},
			{
				type: "bush",
				x: 1290,
				y: 935,
				w: 102,
				h: 80
			},
			{
				type: "bush",
				x: 370,
				y: 365,
				w: 86,
				h: 74
			},
			{
				type: "bush",
				x: 1710,
				y: 835,
				w: 86,
				h: 74
			},
			{
				type: "crate",
				x: 435,
				y: 285,
				w: 48,
				h: 48
			},
			{
				type: "crate",
				x: 1645,
				y: 285,
				w: 48,
				h: 48
			},
			{
				type: "crate",
				x: 435,
				y: 915,
				w: 48,
				h: 48
			},
			{
				type: "crate",
				x: 1645,
				y: 915,
				w: 48,
				h: 48
			},
			{
				type: "crate",
				x: 1040,
				y: 270,
				w: 48,
				h: 48
			},
			{
				type: "crate",
				x: 1040,
				y: 930,
				w: 48,
				h: 48
			},
			{
				type: "barrel",
				x: 720,
				y: 480,
				w: 40,
				h: 40
			},
			{
				type: "barrel",
				x: 1360,
				y: 480,
				w: 40,
				h: 40
			},
			{
				type: "barrel",
				x: 720,
				y: 720,
				w: 40,
				h: 40
			},
			{
				type: "barrel",
				x: 1360,
				y: 720,
				w: 40,
				h: 40
			},
			{
				type: "barrel",
				x: 940,
				y: 600,
				w: 40,
				h: 40
			},
			{
				type: "barrel",
				x: 1140,
				y: 600,
				w: 40,
				h: 40
			}
		]
	}
};
var ARENA_LIST = [
	ARENA_DEFINITIONS.training_grounds,
	ARENA_DEFINITIONS.industrial_zone,
	ARENA_DEFINITIONS.wasteland
];
var BARREL_FUSE_SEC = .58;
var ObstacleEntity = class {
	constructor(scene, id, placement) {
		this.alive = true;
		this.isPriming = false;
		this.fuseRemainingSec = 0;
		this.fuseTotalSec = BARREL_FUSE_SEC;
		this.primedByAttackerId = "";
		this.crackOverlay = null;
		this.warningOuter = null;
		this.warningInner = null;
		this.waterShimmer = null;
		this.damageStage = 0;
		this.fuseSparkTimer = 0;
		this.hitFlashTimer = 0;
		this.lastFuseFlash = null;
		this.id = id;
		this.type = placement.type;
		this.x = placement.x;
		this.y = placement.y;
		this.width = placement.w;
		this.height = placement.h;
		this.blocksMovement = placement.type !== "bush";
		this.blocksProjectiles = placement.type === "brick" || placement.type === "steel" || placement.type === "crate" || placement.type === "barrel";
		this.destructible = placement.type === "brick" || placement.type === "crate" || placement.type === "barrel";
		this.providesConcealment = placement.type === "bush";
		if (placement.type === "brick") this.maxHp = 65;
		else if (placement.type === "crate") this.maxHp = 35;
		else if (placement.type === "barrel") this.maxHp = 22;
		else this.maxHp = 9999;
		this.hp = this.maxHp;
		const texKey = `obs_${placement.type}`;
		this.sprite = scene.add.image(placement.x, placement.y, texKey);
		this.sprite.setDisplaySize(placement.w, placement.h);
		if (placement.type === "bush") {
			this.sprite.setDepth(22);
			this.sprite.setAlpha(.92);
		} else if (placement.type === "water") {
			this.sprite.setDepth(2);
			this.waterShimmer = scene.add.rectangle(placement.x, placement.y, Math.max(18, placement.w * .56), Math.max(8, placement.h * .12), 14412542, .24).setDepth(2);
		} else this.sprite.setDepth(10);
	}
	get left() {
		return this.x - this.width / 2;
	}
	get right() {
		return this.x + this.width / 2;
	}
	get top() {
		return this.y - this.height / 2;
	}
	get bottom() {
		return this.y + this.height / 2;
	}
	containsPoint(px, py, padding = 0) {
		if (!this.alive) return false;
		return px >= this.left - padding && px <= this.right + padding && py >= this.top - padding && py <= this.bottom + padding;
	}
	damage(amount, scene, attackerId = "") {
		if (!this.alive || !this.destructible) return false;
		if (this.isPriming) return false;
		this.hp = Math.max(0, this.hp - amount);
		this.sprite.setTint(16768477);
		this.hitFlashTimer = .065;
		if (this.hp <= 0) {
			if (this.type === "barrel") {
				this.startFuse(scene, attackerId);
				return false;
			}
			this.destroy();
			return true;
		}
		const hpRatio = this.hp / this.maxHp;
		if (this.damageStage < 1 && hpRatio < .68) {
			this.damageStage = 1;
			this.crackOverlay = scene.add.graphics().setDepth(11);
			this.crackOverlay.lineStyle(2.5, 1447957, .85);
			this.crackOverlay.beginPath();
			this.crackOverlay.moveTo(this.x - this.width * .28, this.y - this.height * .25);
			this.crackOverlay.lineTo(this.x + 2, this.y);
			this.crackOverlay.lineTo(this.x + this.width * .24, this.y + this.height * .22);
			this.crackOverlay.moveTo(this.x + 2, this.y);
			this.crackOverlay.lineTo(this.x - this.width * .14, this.y + this.height * .28);
			this.crackOverlay.strokePath();
		}
		if (this.damageStage < 2 && hpRatio < .36 && this.crackOverlay) {
			this.damageStage = 2;
			this.crackOverlay.lineStyle(2.8, 1447957, .95);
			this.crackOverlay.beginPath();
			this.crackOverlay.moveTo(this.x + this.width * .26, this.y - this.height * .28);
			this.crackOverlay.lineTo(this.x - 4, this.y + 3);
			this.crackOverlay.lineTo(this.x - this.width * .3, this.y + this.height * .08);
			this.crackOverlay.strokePath();
			this.sprite.setAlpha(.88);
		}
		return false;
	}
	startFuse(scene, attackerId) {
		if (this.isPriming || !this.alive) return;
		this.isPriming = true;
		this.fuseTotalSec = BARREL_FUSE_SEC;
		this.fuseRemainingSec = BARREL_FUSE_SEC;
		this.primedByAttackerId = attackerId;
		this.warningOuter = scene.add.circle(this.x, this.y, 125, 15680580, .13).setStrokeStyle(2.5, 15680580, .9).setDepth(5);
		this.warningInner = scene.add.circle(this.x, this.y, 18, 16347926, .24).setStrokeStyle(2, 16436245, .95).setDepth(5);
		this.sprite.setTint(16436245);
		soundFX.playBarrelPrime();
	}
	updateHitFlash(dt) {
		if (this.hitFlashTimer <= 0) return;
		this.hitFlashTimer = Math.max(0, this.hitFlashTimer - dt);
		if (this.hitFlashTimer === 0 && this.alive && !this.isPriming && this.sprite.scene) this.sprite.clearTint();
	}
	updateAmbient(elapsedSec) {
		if (!this.alive) return;
		if (this.type === "water" && this.waterShimmer) {
			const wave = Math.sin(elapsedSec * 2.1 + this.id * 1.3);
			this.waterShimmer.setPosition(this.x + wave * 6, this.y + Math.cos(elapsedSec * 1.5 + this.id) * 3);
			this.waterShimmer.setAlpha(.16 + .14 * Math.abs(wave));
		} else if (this.type === "bush" && this.sprite.scene) this.sprite.setRotation(Math.sin(elapsedSec * 1.45 + this.id * .9) * .026);
	}
	updateFuse(dt, effects) {
		if (!this.alive || !this.isPriming) return null;
		this.fuseRemainingSec = Math.max(0, this.fuseRemainingSec - dt);
		const progress = 1 - this.fuseRemainingSec / Math.max(.01, this.fuseTotalSec);
		if (effects) {
			this.fuseSparkTimer -= dt;
			if (this.fuseSparkTimer <= 0) {
				this.fuseSparkTimer = .12;
				effects.spawnTrailPuff(this.x + (Math.random() - .5) * 14, this.y - 10 + (Math.random() - .5) * 8, 16707722, .24);
			}
		}
		if (this.warningInner) this.warningInner.setRadius(18 + 107 * progress);
		if (this.warningOuter) {
			const pulse = .65 + .35 * Math.abs(Math.sin(this.fuseRemainingSec * 22));
			this.warningOuter.setAlpha(pulse);
		}
		if (this.sprite.scene) {
			const flash = Math.sin(this.fuseRemainingSec * 28) > 0;
			if (flash !== this.lastFuseFlash) {
				this.lastFuseFlash = flash;
				this.sprite.setTint(flash ? 16707722 : 15680580);
			}
			const s = 1 + .1 * progress;
			this.sprite.setDisplaySize(this.width * s, this.height * s);
		}
		if (this.fuseRemainingSec <= 0) {
			const result = {
				x: this.x,
				y: this.y,
				attackerId: this.primedByAttackerId
			};
			this.destroy();
			return result;
		}
		return null;
	}
	destroy() {
		this.alive = false;
		this.isPriming = false;
		this.hp = 0;
		this.sprite.setVisible(false);
		this.sprite.destroy();
		if (this.waterShimmer) {
			this.waterShimmer.destroy();
			this.waterShimmer = null;
		}
		if (this.crackOverlay) {
			this.crackOverlay.destroy();
			this.crackOverlay = null;
		}
		if (this.warningOuter) {
			this.warningOuter.destroy();
			this.warningOuter = null;
		}
		if (this.warningInner) {
			this.warningInner.destroy();
			this.warningInner = null;
		}
	}
};
// src/game/powerups/TemporaryEffectManager.ts
/**
* Centralized Temporary Effect Manager
* Tracks durations, prevents unlimited stacking, applies duplicate policies consistently
* across Player and AI tanks, and leaves base TankDefinition immutable.
*/
var TemporaryEffectManager = class {
	constructor() {
		this.activeBuffs = /* @__PURE__ */ new Map();
		this.mineCharges = 0;
		this.mineDeployCooldown = 0;
		this.shieldHp = 0;
		this.maxShieldHp = 0;
		this.shieldFromPowerup = false;
		this.shieldFromAbility = false;
	}
	hasBuff(id) {
		const buff = this.activeBuffs.get(id);
		return Boolean(buff && buff.remainingSec > 0);
	}
	getRemainingSec(id) {
		return this.activeBuffs.get(id)?.remainingSec ?? 0;
	}
	activateShield(amount, source) {
		const safeAmount = Math.max(0, amount);
		if (safeAmount <= 0) return;
		if (source === "powerup") this.shieldFromPowerup = true;
		else this.shieldFromAbility = true;
		this.shieldHp = Math.max(this.shieldHp, safeAmount);
		this.maxShieldHp = Math.max(this.maxShieldHp, this.shieldHp, safeAmount);
	}
	onAbilityShieldExpired() {
		this.shieldFromAbility = false;
		if (this.shieldFromPowerup && this.hasBuff("shield")) {
			const powerupCap = POWERUP_DEFINITIONS.shield.shieldAmount ?? 50;
			this.shieldHp = Math.min(this.shieldHp, powerupCap);
			this.maxShieldHp = Math.min(this.maxShieldHp, powerupCap);
		} else {
			this.shieldHp = 0;
			this.maxShieldHp = 0;
		}
	}
	/**
	* Absorbs damage with active Shield before hull mitigation (Phase Shift) runs,
	* preventing multiplicative EHP inflation from Shield + Phase Shift.
	*/
	absorbIncomingDamage(rawAmount, source) {
		if (this.shieldHp <= 0 || rawAmount <= 0) return {
			remainingDamage: rawAmount,
			absorbed: 0,
			broken: false
		};
		if (!(source === "projectile" || this.shieldFromAbility)) return {
			remainingDamage: rawAmount,
			absorbed: 0,
			broken: false
		};
		const absorbed = Math.min(this.shieldHp, rawAmount);
		this.shieldHp -= absorbed;
		const remainingDamage = rawAmount - absorbed;
		let broken = false;
		if (this.shieldHp <= 0) {
			this.shieldHp = 0;
			this.maxShieldHp = 0;
			this.shieldFromPowerup = false;
			this.shieldFromAbility = false;
			this.activeBuffs.delete("shield");
			broken = true;
		}
		return {
			remainingDamage,
			absorbed,
			broken
		};
	}
	applyPowerup(id, alive, currentHp, maxHp, setHp) {
		if (!alive) return {
			applied: false,
			healedAmount: 0,
			minesAdded: 0
		};
		const def = POWERUP_DEFINITIONS[id];
		if (!def) return {
			applied: false,
			healedAmount: 0,
			minesAdded: 0
		};
		if (id === "repair_kit") {
			const missing = Math.max(0, maxHp - currentHp);
			if (missing <= 0) return {
				applied: true,
				healedAmount: 0,
				minesAdded: 0
			};
			const ratio = def.healMissingRatio ?? .45;
			const minHeal = def.healMinAmount ?? 25;
			const healAmount = Math.min(missing, Math.max(minHeal, Math.round(missing * ratio)));
			setHp(Math.min(maxHp, currentHp + healAmount));
			return {
				applied: true,
				healedAmount: healAmount,
				minesAdded: 0
			};
		}
		if (id === "mine_kit") {
			const grant = def.minesGranted ?? 2;
			const cap = def.maxMineCharges ?? MINE_SYSTEM_CONFIG.maxCarriedCharges;
			const before = this.mineCharges;
			this.mineCharges = Math.min(cap, this.mineCharges + grant);
			return {
				applied: true,
				healedAmount: 0,
				minesAdded: Math.max(0, this.mineCharges - before)
			};
		}
		if (id === "shield") this.activateShield(def.shieldAmount ?? 50, "powerup");
		if (def.durationSec > 0) this.activeBuffs.set(id, {
			id,
			remainingSec: def.durationSec,
			totalSec: def.durationSec
		});
		return {
			applied: true,
			healedAmount: 0,
			minesAdded: 0
		};
	}
	consumeMineCharge() {
		if (this.mineCharges <= 0 || this.mineDeployCooldown > 0) return false;
		this.mineCharges -= 1;
		this.mineDeployCooldown = MINE_SYSTEM_CONFIG.deployCooldownSec;
		return true;
	}
	update(dt, fortressAbilityActive) {
		if (this.mineDeployCooldown > 0) this.mineDeployCooldown = Math.max(0, this.mineDeployCooldown - dt);
		for (const [key, buff] of this.activeBuffs.entries()) {
			buff.remainingSec -= dt;
			if (buff.remainingSec <= 0) {
				this.activeBuffs.delete(key);
				if (key === "shield") {
					this.shieldFromPowerup = false;
					if (!fortressAbilityActive) {
						this.shieldFromAbility = false;
						this.shieldHp = 0;
						this.maxShieldHp = 0;
					}
				}
			}
		}
	}
	clearAll() {
		this.activeBuffs.clear();
		this.mineCharges = 0;
		this.mineDeployCooldown = 0;
		this.shieldHp = 0;
		this.maxShieldHp = 0;
		this.shieldFromPowerup = false;
		this.shieldFromAbility = false;
	}
	getMoveSpeedMultiplier(passiveBonus, activeAbilityBonus) {
		const powerupBonus = this.hasBuff("speed_boost") ? POWERUP_DEFINITIONS.speed_boost.speedBonusMultiplier ?? .35 : 0;
		return Math.min(MAX_TOTAL_SPEED_MULTIPLIER, 1 + passiveBonus + activeAbilityBonus + powerupBonus);
	}
	getFireRateMultiplier(activeAbilityFireRateMult) {
		const powerupMult = this.hasBuff("rapid_fire") ? POWERUP_DEFINITIONS.rapid_fire.fireRateMultiplier ?? 1.45 : 1;
		return Math.min(MAX_TOTAL_FIRERATE_MULTIPLIER, activeAbilityFireRateMult * powerupMult);
	}
	getDamageMultiplier() {
		return this.hasBuff("heavy_shell") ? POWERUP_DEFINITIONS.heavy_shell.damageMultiplier ?? 1.45 : 1;
	}
	getCooldownRecoveryMultiplier() {
		return this.hasBuff("cooldown_boost") ? POWERUP_DEFINITIONS.cooldown_boost.cooldownRecoveryMultiplier ?? 2 : 1;
	}
	getMultiShotConfig() {
		if (!this.hasBuff("multi_shot")) return {
			count: 1,
			spreadRad: 0
		};
		return {
			count: POWERUP_DEFINITIONS.multi_shot.multiShotCount ?? 3,
			spreadRad: POWERUP_DEFINITIONS.multi_shot.multiShotSpreadRad ?? .16
		};
	}
	getPierceCount() {
		return this.hasBuff("piercing_shell") ? POWERUP_DEFINITIONS.piercing_shell.pierceCount ?? 1 : 0;
	}
	getRadarRadius() {
		return this.hasBuff("radar") ? POWERUP_DEFINITIONS.radar.radarRadius ?? 880 : 0;
	}
	toHudSnapshots() {
		const out = [];
		this.activeBuffs.forEach((buff) => {
			const def = POWERUP_DEFINITIONS[buff.id];
			out.push({
				id: buff.id,
				name: def.name,
				shortLabel: def.shortLabel,
				remainingSec: buff.remainingSec,
				totalSec: buff.totalSec,
				color: def.color
			});
		});
		return out;
	}
};
// src/game/entities/TankEntity.ts
var TankEntity = class {
	get buffs() {
		return this.effectsManager.activeBuffs;
	}
	get shieldHp() {
		return this.effectsManager.shieldHp;
	}
	set shieldHp(val) {
		this.effectsManager.shieldHp = val;
	}
	get maxShieldHp() {
		return this.effectsManager.maxShieldHp;
	}
	set maxShieldHp(val) {
		this.effectsManager.maxShieldHp = val;
	}
	get mineCharges() {
		return this.effectsManager.mineCharges;
	}
	get mineDeployCooldown() {
		return this.effectsManager.mineDeployCooldown;
	}
	constructor(scene, id, displayName, isPlayer, definition, x, y, angle, personality = "tactical", cosmeticId = "default", customTextureKeys) {
		this.vx = 0;
		this.vy = 0;
		this.alive = true;
		this.eliminations = 0;
		this.damageDealt = 0;
		this.eliminatedAtRank = null;
		this.fireCooldownTimer = 0;
		this.isReloading = false;
		this.magazineReloadTimer = 0;
		this.magazineReloadTotal = 0;
		this.abilityCooldownTimer = 0;
		this.abilityActiveTimer = 0;
		this.spawnProtectionTimer = 0;
		this.staticSlowTimer = 0;
		this.staticSlowFactor = 1;
		this.empSlowTimer = 0;
		this.empSlowFactor = 1;
		this.recentAttackTimer = 0;
		this.concealed = false;
		this.phaseCloaked = false;
		this.effectsManager = new TemporaryEffectManager();
		this.playerRing = null;
		this.radarSweepRing = null;
		this.radarRevealRing = null;
		this.barrageReticle = null;
		this.dustTimer = 0;
		this.treadMarkTimer = 0;
		this.afterburnerExhaustTimer = 0;
		this.visualClock = 0;
		this.fireRecoilOffset = 0;
		this.hitFlashTimer = 0;
		this.hitFlashTint = 16751001;
		this.damageTrailRatio = 1;
		this.wasConcealed = false;
		this.lastHullTint = null;
		this.lastTurretTint = null;
		this.lastPlayerRingColor = null;
		this.lastAuraColor = null;
		this.lastSlowRingColor = null;
		this.lastSlowText = "";
		this.id = id;
		this.displayName = displayName;
		this.isPlayer = isPlayer;
		this.definition = definition;
		this.personality = personality;
		this.x = x;
		this.y = y;
		this.hullAngle = angle;
		this.turretAngle = angle;
		this.maxHp = getEffectiveTankMaxHp(definition);
		this.hp = this.maxHp;
		this.ammo = definition.stats.magazineCapacity;
		if (isPlayer) {
			this.playerRing = scene.add.circle(x, y, definition.stats.bodyRadius + 10, 2278750, .14);
			this.lastPlayerRingColor = 4906624;
			this.playerRing.setStrokeStyle(2.5, 4906624, .9);
			this.playerRing.setDepth(13);
			if (definition.id === "artillery") {
				const aoeR = definition.activeAbility.barrageAoERadius ?? 88;
				this.barrageReticle = scene.add.circle(x, y, aoeR, 15680580, .06);
				this.barrageReticle.setStrokeStyle(2, 16281969, .55);
				this.barrageReticle.setDepth(6);
				this.barrageReticle.setVisible(false);
			}
		}
		this.rapidFireRing = scene.add.circle(x, y, definition.stats.bodyRadius + 13, 16096779, .12);
		this.rapidFireRing.setStrokeStyle(2.5, 16498468, .92);
		this.rapidFireRing.setDepth(13);
		this.rapidFireRing.setVisible(false);
		this.afterburnerRing = scene.add.circle(x, y, definition.stats.bodyRadius + 12, 16436245, .14);
		this.afterburnerRing.setStrokeStyle(2.5, 16436245, .95);
		this.afterburnerRing.setDepth(13);
		this.afterburnerRing.setVisible(false);
		this.phaseRing = scene.add.circle(x, y, definition.stats.bodyRadius + 11, 10980346, .14);
		this.phaseRing.setStrokeStyle(2.5, 12891645, .9);
		this.phaseRing.setDepth(13);
		this.phaseRing.setVisible(false);
		this.slowRing = scene.add.circle(x, y, definition.stats.bodyRadius + 11, 2282478, .16);
		this.lastSlowRingColor = 2282478;
		this.slowRing.setStrokeStyle(2.8, 2282478, .95);
		this.slowRing.setDepth(16);
		this.slowRing.setVisible(false);
		const hullTexKey = customTextureKeys?.hullKey && scene.textures.exists(customTextureKeys.hullKey) ? customTextureKeys.hullKey : cosmeticId !== "default" && scene.textures.exists(`tank_hull_${definition.id}_${cosmeticId}`) ? `tank_hull_${definition.id}_${cosmeticId}` : `tank_hull_${definition.id}`;
		const turretTexKey = customTextureKeys?.turretKey && scene.textures.exists(customTextureKeys.turretKey) ? customTextureKeys.turretKey : cosmeticId !== "default" && scene.textures.exists(`tank_turret_${definition.id}_${cosmeticId}`) ? `tank_turret_${definition.id}_${cosmeticId}` : `tank_turret_${definition.id}`;
		this.hullSprite = scene.add.image(x, y, hullTexKey);
		this.hullSprite.setRotation(angle);
		this.hullSprite.setDepth(14);
		if (!isPlayer) {
			this.hullSprite.setTint(15919332);
			this.lastHullTint = 15919332;
		}
		this.turretSprite = scene.add.image(x, y, turretTexKey);
		this.turretSprite.setOrigin(36 / 96, .5);
		this.turretSprite.setRotation(angle);
		this.turretSprite.setDepth(15);
		this.shieldRing = scene.add.circle(x, y, definition.stats.bodyRadius + 8, 3718648, .18);
		this.shieldRing.setStrokeStyle(3, 3718648, .95);
		this.shieldRing.setDepth(16);
		this.shieldRing.setVisible(false);
		this.powerupAuraRing = scene.add.circle(x, y, definition.stats.bodyRadius + 15, 16096779, .08);
		this.lastAuraColor = 16096779;
		this.powerupAuraRing.setStrokeStyle(2.2, 16096779, .85);
		this.powerupAuraRing.setDepth(12);
		this.powerupAuraRing.setVisible(false);
		if (isPlayer) {
			this.radarSweepRing = scene.add.circle(x, y, 42, 1096065, .05);
			this.radarSweepRing.setStrokeStyle(2, 1096065, .55);
			this.radarSweepRing.setDepth(7);
			this.radarSweepRing.setVisible(false);
		} else {
			this.radarRevealRing = scene.add.circle(x, y, definition.stats.bodyRadius + 16, 1096065, .12);
			this.radarRevealRing.setStrokeStyle(2.6, 3462041, .92);
			this.radarRevealRing.setDepth(21);
			this.radarRevealRing.setVisible(false);
		}
		this.barBg = scene.add.rectangle(x, y - 34, 46, 6, 1316628, .9).setDepth(24);
		this.barTrailFill = scene.add.rectangle(x - 22, y - 34, 44, 4, 16707722, .9).setOrigin(0, .5).setDepth(24);
		this.barFill = scene.add.rectangle(x - 22, y - 34, 44, 4, isPlayer ? 2278750 : 15680580, 1).setOrigin(0, .5).setDepth(25);
		this.reloadBarBg = scene.add.rectangle(x, y - 28, 46, 4, 1316628, .9).setDepth(24).setVisible(false);
		this.reloadBarFill = scene.add.rectangle(x - 22, y - 28, 0, 2.5, 16436245, 1).setOrigin(0, .5).setDepth(25).setVisible(false);
		this.shieldFill = scene.add.rectangle(x - 22, y - 39, 44, 2.5, 3718648, 1).setOrigin(0, .5).setDepth(25).setVisible(false);
		this.nameLabel = scene.add.text(x, y - 46, isPlayer ? "YOU" : displayName, {
			fontFamily: "\"Barlow Condensed\", sans-serif",
			fontSize: "12px",
			fontStyle: "bold",
			color: isPlayer ? "#86EFAC" : "#F3EFE6",
			stroke: "#141714",
			strokeThickness: 3
		}).setOrigin(.5).setDepth(25);
		this.slowLabel = scene.add.text(x, y - 59, "⚡ SLOWED", {
			fontFamily: "\"Barlow Condensed\", sans-serif",
			fontSize: "11px",
			fontStyle: "bold",
			color: "#67E8F9",
			stroke: "#083344",
			strokeThickness: 3
		}).setOrigin(.5).setDepth(26).setVisible(false);
	}
	get radius() {
		return this.definition.stats.bodyRadius;
	}
	get maxAmmo() {
		return this.definition.stats.magazineCapacity;
	}
	getBarrelTip() {
		const barrelLen = this.definition.visual.silhouette === "long_barrel" ? 46 : 36;
		return {
			x: this.x + Math.cos(this.turretAngle) * barrelLen,
			y: this.y + Math.sin(this.turretAngle) * barrelLen
		};
	}
	getMuzzleSpawnPoint() {
		const spawnDist = this.radius + 2;
		return {
			x: this.x + Math.cos(this.turretAngle) * spawnDist,
			y: this.y + Math.sin(this.turretAngle) * spawnDist
		};
	}
	triggerFireRecoil() {
		const kick = this.definition.id === "artillery" ? 8.5 : this.definition.id === "fortress" ? 6.5 : 4.8;
		this.fireRecoilOffset = Math.max(this.fireRecoilOffset, kick);
	}
	get isSlowed() {
		return this.staticSlowTimer > 0 || this.empSlowTimer > 0;
	}
	get isEmpDisrupted() {
		return this.empSlowTimer > 0;
	}
	get slowRemainingSec() {
		return Math.max(this.staticSlowTimer, this.empSlowTimer);
	}
	getEffectiveDetectionMultiplier() {
		if (this.definition.id !== "phantom") return this.definition.stats.detectionMultiplier;
		return this.definition.passiveAbility.detectionMultiplier ?? this.definition.stats.detectionMultiplier;
	}
	getEffectiveMoveSpeed() {
		const passiveBonus = (this.definition.passiveAbility.moveSpeedMultiplier ?? 1) - 1;
		const activeBonus = this.abilityActiveTimer > 0 && this.definition.activeAbility.speedBoostMultiplier ? this.definition.activeAbility.speedBoostMultiplier - 1 : 0;
		const mult = this.effectsManager.getMoveSpeedMultiplier(passiveBonus, activeBonus);
		const slowMult = Math.min(this.staticSlowTimer > 0 ? this.staticSlowFactor : 1, this.empSlowTimer > 0 ? this.empSlowFactor : 1);
		return this.definition.stats.moveSpeed * mult * slowMult;
	}
	getEffectiveFireIntervalSec() {
		const activeMult = this.abilityActiveTimer > 0 && this.definition.activeAbility.fireRateMultiplier ? this.definition.activeAbility.fireRateMultiplier : 1;
		const divisor = this.effectsManager.getFireRateMultiplier(activeMult);
		return this.definition.stats.reloadSec / divisor;
	}
	getEffectiveReloadDurationSec() {
		return getEffectiveTankReloadSec(this.definition);
	}
	getEffectiveProjectileRange() {
		return getEffectiveTankProjectileRange(this.definition);
	}
	updateBarrageReticle(visible, targetX, targetY) {
		if (!this.barrageReticle) return;
		if (!visible || !this.alive) {
			this.barrageReticle.setVisible(false);
			return;
		}
		this.barrageReticle.setPosition(targetX, targetY).setVisible(true);
	}
	startReload() {
		if (!this.alive || this.isReloading || this.ammo >= this.maxAmmo) return false;
		const duration = this.getEffectiveReloadDurationSec();
		this.isReloading = true;
		this.magazineReloadTotal = duration;
		this.magazineReloadTimer = duration;
		return true;
	}
	getEffectiveDamage() {
		const mult = this.effectsManager.getDamageMultiplier();
		return Math.round(this.definition.stats.projectileDamage * mult);
	}
	hasBuff(id) {
		return this.effectsManager.hasBuff(id);
	}
	activateShield(amount, source = "ability") {
		this.effectsManager.activateShield(amount, source);
	}
	applyBuff(id) {
		return this.effectsManager.applyPowerup(id, this.alive, this.hp, this.maxHp, (nextHp) => {
			this.hp = nextHp;
		});
	}
	consumeMineCharge() {
		if (!this.alive) return false;
		return this.effectsManager.consumeMineCharge();
	}
	clearTemporaryEffects() {
		this.effectsManager.clearAll();
		this.staticSlowTimer = 0;
		this.staticSlowFactor = 1;
		this.empSlowTimer = 0;
		this.empSlowFactor = 1;
		this.phaseCloaked = false;
		this.powerupAuraRing.setVisible(false);
		this.shieldRing.setVisible(false);
		this.shieldFill.setVisible(false);
		if (this.radarSweepRing) this.radarSweepRing.setVisible(false);
		if (this.radarRevealRing) this.radarRevealRing.setVisible(false);
	}
	applySlow(factor, durationSec, source = "static") {
		const clampedFactor = Math.min(1, Math.max(.2, factor));
		const safeDuration = Math.max(0, durationSec);
		if (safeDuration <= 0) return;
		if (source === "emp") {
			this.empSlowFactor = clampedFactor;
			this.empSlowTimer = safeDuration;
		} else {
			this.staticSlowFactor = clampedFactor;
			this.staticSlowTimer = safeDuration;
		}
	}
	interruptMovementAbilities(effects) {
		if (!this.alive) return false;
		let interrupted = false;
		if (this.abilityActiveTimer > 0 && this.definition.activeAbility.speedBoostMultiplier) {
			this.abilityActiveTimer = 0;
			if (this.phaseCloaked) {
				this.phaseCloaked = false;
				effects?.spawnPhaseShift(this.x, this.y, false);
				if (this.isPlayer) soundFX.playPhaseEnd();
			}
			interrupted = true;
		}
		this.vx *= .35;
		this.vy *= .35;
		return interrupted;
	}
	updateMovement(dt, moveX, moveY, obstacles, arenaWidth, arenaHeight, effects) {
		if (!this.alive) return;
		const mag = Math.hypot(moveX, moveY);
		const nx = mag > .05 ? moveX / Math.max(1, mag) : 0;
		const ny = mag > .05 ? moveY / Math.max(1, mag) : 0;
		const maxSpd = this.getEffectiveMoveSpeed();
		const targetVx = nx * maxSpd;
		const targetVy = ny * maxSpd;
		const accel = this.definition.stats.acceleration;
		const decel = accel * 1.35;
		const rate = mag > .05 ? accel : decel;
		const dxv = targetVx - this.vx;
		const dyv = targetVy - this.vy;
		const dv = Math.hypot(dxv, dyv);
		if (dv > rate * dt) {
			this.vx += dxv / dv * rate * dt;
			this.vy += dyv / dv * rate * dt;
		} else {
			this.vx = targetVx;
			this.vy = targetVy;
		}
		if (Math.hypot(this.vx, this.vy) > 15) {
			const targetAngle = Math.atan2(this.vy, this.vx);
			const diff = __webpack_exports__default.Math.Angle.Wrap(targetAngle - this.hullAngle);
			const maxTurn = this.definition.stats.turnSpeed * dt;
			this.hullAngle += __webpack_exports__default.Math.Clamp(diff, -maxTurn, maxTurn);
			this.dustTimer -= dt;
			if (this.dustTimer <= 0) {
				this.dustTimer = this.definition.id === "scout" ? .07 : .095;
				effects.spawnTreadDust(this.x - Math.cos(this.hullAngle) * 18, this.y - Math.sin(this.hullAngle) * 18);
			}
			this.treadMarkTimer -= dt;
			if (this.treadMarkTimer <= 0) {
				this.treadMarkTimer = this.definition.id === "scout" ? .11 : .145;
				effects.spawnTreadMark(this.x - Math.cos(this.hullAngle) * 10, this.y - Math.sin(this.hullAngle) * 10, this.hullAngle, this.definition.id === "fortress");
			}
			if (this.definition.id === "scout" && this.abilityActiveTimer > 0) {
				this.afterburnerExhaustTimer -= dt;
				if (this.afterburnerExhaustTimer <= 0) {
					this.afterburnerExhaustTimer = .055;
					effects.spawnAfterburnerExhaust(this.x - Math.cos(this.hullAngle) * 18, this.y - Math.sin(this.hullAngle) * 18, this.hullAngle);
				}
			}
		}
		this.x += this.vx * dt;
		this.y += this.vy * dt;
		this.resolveBoundsAndObstacles(obstacles, arenaWidth, arenaHeight);
		if (this.concealed && !this.wasConcealed) effects.spawnLeafRustle(this.x, this.y);
		this.wasConcealed = this.concealed;
	}
	resolveBoundsAndObstacles(obstacles, arenaWidth, arenaHeight) {
		const pad = this.radius + 14;
		this.x = __webpack_exports__default.Math.Clamp(this.x, pad, arenaWidth - pad);
		this.y = __webpack_exports__default.Math.Clamp(this.y, pad, arenaHeight - pad);
		let inBush = false;
		for (const obs of obstacles) {
			if (!obs.alive) continue;
			if (obs.providesConcealment) {
				if (obs.containsPoint(this.x, this.y, 4)) inBush = true;
				continue;
			}
			if (!obs.blocksMovement) continue;
			const closestX = __webpack_exports__default.Math.Clamp(this.x, obs.left, obs.right);
			const closestY = __webpack_exports__default.Math.Clamp(this.y, obs.top, obs.bottom);
			const distX = this.x - closestX;
			const distY = this.y - closestY;
			const distSq = distX * distX + distY * distY;
			if (distSq < this.radius * this.radius) {
				const dist = Math.sqrt(distSq);
				if (dist > 1e-4) {
					const overlap = this.radius - dist;
					this.x += distX / dist * overlap;
					this.y += distY / dist * overlap;
				} else {
					const dl = Math.abs(this.x - obs.left);
					const dr = Math.abs(obs.right - this.x);
					const dtSide = Math.abs(this.y - obs.top);
					const dbSide = Math.abs(obs.bottom - this.y);
					const minSide = Math.min(dl, dr, dtSide, dbSide);
					if (minSide === dl) this.x = obs.left - this.radius;
					else if (minSide === dr) this.x = obs.right + this.radius;
					else if (minSide === dtSide) this.y = obs.top - this.radius;
					else this.y = obs.bottom + this.radius;
				}
			}
		}
		this.concealed = inBush;
	}
	aimTurretToward(targetAngle, dt, sensitivity = 1) {
		if (!this.alive) return;
		const diff = __webpack_exports__default.Math.Angle.Wrap(targetAngle - this.turretAngle);
		const maxRot = 14 * Math.min(1.6, Math.max(.5, sensitivity)) * dt;
		this.turretAngle += __webpack_exports__default.Math.Clamp(diff, -maxRot, maxRot);
	}
	updateTimersAndVisuals(dt, playerHasRadar, prepPhase = false, effects, playerX = 0, playerY = 0, playerRadarRadius = 0) {
		if (!this.alive) return;
		if (!this.isPlayer && prepPhase) {
			this.hideAllVisuals();
			return;
		}
		this.visualClock += dt;
		if (this.fireCooldownTimer > 0) this.fireCooldownTimer = Math.max(0, this.fireCooldownTimer - dt);
		if (this.recentAttackTimer > 0) this.recentAttackTimer = Math.max(0, this.recentAttackTimer - dt);
		if (this.isReloading && dt > 0) {
			this.magazineReloadTimer = Math.max(0, this.magazineReloadTimer - dt);
			if (this.magazineReloadTimer <= 0) {
				this.isReloading = false;
				this.magazineReloadTimer = 0;
				this.magazineReloadTotal = 0;
				this.ammo = this.maxAmmo;
				if (this.isPlayer) soundFX.playReloadComplete();
			}
		}
		if (this.spawnProtectionTimer > 0) this.spawnProtectionTimer = Math.max(0, this.spawnProtectionTimer - dt);
		const cdrMult = this.effectsManager.getCooldownRecoveryMultiplier();
		if (this.abilityCooldownTimer > 0) this.abilityCooldownTimer = Math.max(0, this.abilityCooldownTimer - dt * cdrMult);
		if (this.abilityActiveTimer > 0) {
			this.abilityActiveTimer = Math.max(0, this.abilityActiveTimer - dt);
			if (this.abilityActiveTimer === 0) {
				const wasPhased = this.phaseCloaked;
				this.phaseCloaked = false;
				if (wasPhased) {
					effects?.spawnPhaseShift(this.x, this.y, false);
					if (this.isPlayer) soundFX.playPhaseEnd();
				} else if (this.definition.id === "fortress") {
					this.effectsManager.onAbilityShieldExpired();
					effects?.spawnRing(this.x, this.y, this.radius + 22, 3718648, .24);
					if (this.isPlayer) soundFX.playAbilityExpire("fortress");
				} else if (this.definition.id === "assault") {
					effects?.spawnRing(this.x, this.y, this.radius + 20, 16096779, .2);
					if (this.isPlayer) soundFX.playAbilityExpire("assault");
				} else if (this.definition.id === "scout") {
					effects?.spawnRing(this.x, this.y, this.radius + 18, 16436245, .2);
					if (this.isPlayer) soundFX.playAbilityExpire("scout");
				}
			}
		} else if (this.phaseCloaked) this.phaseCloaked = false;
		if (this.staticSlowTimer > 0) {
			this.staticSlowTimer = Math.max(0, this.staticSlowTimer - dt);
			if (this.staticSlowTimer === 0) this.staticSlowFactor = 1;
		}
		if (this.empSlowTimer > 0) {
			this.empSlowTimer = Math.max(0, this.empSlowTimer - dt);
			if (this.empSlowTimer === 0) this.empSlowFactor = 1;
		}
		const fortressShieldActive = this.definition.id === "fortress" && this.abilityActiveTimer > 0;
		this.effectsManager.update(dt, fortressShieldActive);
		if (this.fireRecoilOffset > 0) this.fireRecoilOffset = Math.max(0, this.fireRecoilOffset - 46 * dt);
		if (this.hitFlashTimer > 0) this.hitFlashTimer = Math.max(0, this.hitFlashTimer - dt);
		const engineVib = Math.hypot(this.vx, this.vy) > 45 && !prepPhase ? 1 + Math.sin(this.visualClock * 26) * .012 : 1;
		const hitScale = this.hitFlashTimer > 0 ? 1.045 : 1;
		const recoilX = Math.cos(this.turretAngle) * this.fireRecoilOffset;
		const recoilY = Math.sin(this.turretAngle) * this.fireRecoilOffset;
		this.hullSprite.setVisible(true).setPosition(this.x, this.y).setRotation(this.hullAngle).setScale(engineVib * hitScale);
		this.turretSprite.setVisible(true).setPosition(this.x - recoilX, this.y - recoilY).setRotation(this.turretAngle).setScale(hitScale);
		const desiredHullTint = this.hitFlashTimer > 0 ? this.hitFlashTint : this.isPlayer ? null : 15919332;
		if (desiredHullTint !== this.lastHullTint) {
			this.lastHullTint = desiredHullTint;
			if (desiredHullTint === null) this.hullSprite.clearTint();
			else this.hullSprite.setTint(desiredHullTint);
		}
		const desiredTurretTint = this.hitFlashTimer > 0 ? this.hitFlashTint : this.definition.id === "assault" && this.abilityActiveTimer > 0 ? 16639626 : null;
		if (desiredTurretTint !== this.lastTurretTint) {
			this.lastTurretTint = desiredTurretTint;
			if (desiredTurretTint === null) this.turretSprite.clearTint();
			else this.turretSprite.setTint(desiredTurretTint);
		}
		if (this.playerRing) {
			this.playerRing.setVisible(true).setPosition(this.x, this.y);
			const ringColor = this.spawnProtectionTimer > 0 ? 16436245 : 4906624;
			if (ringColor !== this.lastPlayerRingColor) {
				this.lastPlayerRingColor = ringColor;
				this.playerRing.setStrokeStyle(2.5, ringColor, .9);
			}
		}
		const rdx = this.x - playerX;
		const rdy = this.y - playerY;
		const radarRevealed = !this.isPlayer && !prepPhase && playerHasRadar && playerRadarRadius > 0 && rdx * rdx + rdy * rdy <= playerRadarRadius * playerRadarRadius;
		const hiddenFromPlayer = !this.isPlayer && !radarRevealed && (this.concealed || this.phaseCloaked);
		const spawnPulse = this.spawnProtectionTimer > 0 ? .72 + .28 * Math.abs(Math.sin(this.spawnProtectionTimer * 10)) : 1;
		const targetAlpha = (this.isPlayer ? this.phaseCloaked ? .38 : this.concealed ? .55 : 1 : hiddenFromPlayer ? .16 : this.phaseCloaked ? .34 : 1) * spawnPulse;
		this.hullSprite.setAlpha(targetAlpha);
		this.turretSprite.setAlpha(targetAlpha);
		if (this.definition.id === "assault" && this.abilityActiveTimer > 0 && !hiddenFromPlayer) {
			const pulseAlpha = .55 + .35 * Math.abs(Math.sin(this.abilityActiveTimer * 12));
			this.rapidFireRing.setPosition(this.x, this.y).setAlpha(pulseAlpha).setVisible(true);
		} else this.rapidFireRing.setVisible(false);
		if (this.definition.id === "scout" && this.abilityActiveTimer > 0 && !hiddenFromPlayer) {
			const pulseAlpha = .58 + .38 * Math.abs(Math.sin(this.abilityActiveTimer * 14));
			this.afterburnerRing.setPosition(this.x, this.y).setAlpha(pulseAlpha).setVisible(true);
		} else this.afterburnerRing.setVisible(false);
		if (this.phaseCloaked && (!hiddenFromPlayer || this.isPlayer)) {
			const pulseAlpha = .45 + .35 * Math.abs(Math.sin(this.abilityActiveTimer * 10));
			this.phaseRing.setPosition(this.x, this.y).setAlpha(pulseAlpha).setVisible(true);
		} else this.phaseRing.setVisible(false);
		if (this.shieldHp > 0) {
			const shieldPulse = this.definition.id === "fortress" && this.abilityActiveTimer > 0 ? .72 + .28 * Math.abs(Math.sin(this.abilityActiveTimer * 8)) : .9;
			this.shieldRing.setPosition(this.x, this.y).setAlpha(shieldPulse).setVisible(!hiddenFromPlayer);
		} else this.shieldRing.setVisible(false);
		const showHudBar = !hiddenFromPlayer;
		this.barBg.setPosition(this.x, this.y - 34).setVisible(showHudBar);
		const hpRatio = __webpack_exports__default.Math.Clamp(this.hp / this.maxHp, 0, 1);
		if (this.damageTrailRatio < hpRatio) this.damageTrailRatio = hpRatio;
		else if (this.damageTrailRatio > hpRatio) this.damageTrailRatio = Math.max(hpRatio, this.damageTrailRatio - dt * .95);
		this.barTrailFill.setPosition(this.x - 22, this.y - 34).setDisplaySize(Math.max(0, 44 * this.damageTrailRatio), 4).setVisible(showHudBar && this.damageTrailRatio > hpRatio + .01);
		this.barFill.setPosition(this.x - 22, this.y - 34).setDisplaySize(Math.max(0, 44 * hpRatio), 4).setVisible(showHudBar);
		if (this.isReloading && this.magazineReloadTotal > 0 && showHudBar) {
			const reloadProgress = __webpack_exports__default.Math.Clamp(1 - this.magazineReloadTimer / this.magazineReloadTotal, 0, 1);
			this.reloadBarBg.setPosition(this.x, this.y - 28).setVisible(true);
			this.reloadBarFill.setPosition(this.x - 22, this.y - 28).setDisplaySize(Math.max(2, 44 * reloadProgress), 2.5).setVisible(true);
		} else {
			this.reloadBarBg.setVisible(false);
			this.reloadBarFill.setVisible(false);
		}
		if (this.shieldHp > 0 && showHudBar) {
			const denom = Math.max(1, this.maxShieldHp || this.definition.activeAbility.shieldAmount || 75);
			const shRatio = __webpack_exports__default.Math.Clamp(this.shieldHp / denom, 0, 1);
			this.shieldFill.setPosition(this.x - 22, this.y - 39).setDisplaySize(44 * shRatio, 2.5).setVisible(true);
		} else this.shieldFill.setVisible(false);
		const auraColor = this.hasBuff("heavy_shell") ? 15680580 : this.hasBuff("rapid_fire") ? 16096779 : this.hasBuff("multi_shot") ? 15485081 : this.hasBuff("piercing_shell") ? 11032055 : this.hasBuff("speed_boost") ? 440020 : this.hasBuff("cooldown_boost") ? 15381256 : null;
		if (auraColor !== null && !hiddenFromPlayer) {
			const auraPulse = .55 + .35 * Math.abs(Math.sin(this.visualClock * 8));
			if (auraColor !== this.lastAuraColor) {
				this.lastAuraColor = auraColor;
				this.powerupAuraRing.setStrokeStyle(2.2, auraColor, .9).setFillStyle(auraColor, .08);
			}
			this.powerupAuraRing.setPosition(this.x, this.y).setAlpha(auraPulse).setVisible(true);
		} else this.powerupAuraRing.setVisible(false);
		if (this.radarSweepRing) {
			if (!prepPhase && this.hasBuff("radar")) {
				const sweepPhase = this.visualClock * .95 % 1;
				this.radarSweepRing.setPosition(this.x, this.y).setRadius(40 + sweepPhase * 120).setAlpha(.75 * (1 - sweepPhase)).setVisible(true);
			} else this.radarSweepRing.setVisible(false);
		}
		if (this.radarRevealRing) {
			if (radarRevealed) {
				const pulse = .58 + .38 * Math.abs(Math.sin(this.visualClock * 10));
				this.radarRevealRing.setPosition(this.x, this.y).setAlpha(pulse).setVisible(true);
			} else this.radarRevealRing.setVisible(false);
		}
		if (this.isSlowed && !hiddenFromPlayer) {
			const slowPulse = .55 + .4 * Math.abs(Math.sin(this.slowRemainingSec * 16));
			const ringColor = this.isEmpDisrupted ? 3718648 : 2282478;
			if (ringColor !== this.lastSlowRingColor) {
				this.lastSlowRingColor = ringColor;
				this.slowRing.setStrokeStyle(2.8, ringColor, .95);
			}
			this.slowRing.setPosition(this.x, this.y).setAlpha(slowPulse).setVisible(true);
		} else this.slowRing.setVisible(false);
		this.nameLabel.setPosition(this.x, this.y - 46).setVisible(showHudBar);
		if (this.isSlowed && showHudBar) {
			const nextSlowText = this.isEmpDisrupted ? "⚡ EMP SLOW" : "⚡ STATIC";
			if (nextSlowText !== this.lastSlowText) {
				this.lastSlowText = nextSlowText;
				this.slowLabel.setText(nextSlowText);
			}
			this.slowLabel.setPosition(this.x, this.y - 59).setVisible(true);
		} else this.slowLabel.setVisible(false);
	}
	takeDamage(amount, source = "projectile") {
		if (!this.alive || this.spawnProtectionTimer > 0) return {
			killed: false,
			actualDamage: 0,
			shieldAbsorbed: 0,
			shieldBroken: false
		};
		const shieldRes = this.effectsManager.absorbIncomingDamage(amount, source);
		const absorbed = shieldRes.absorbed;
		const shieldBroken = shieldRes.broken;
		if (shieldBroken && this.definition.id === "fortress" && this.abilityActiveTimer > 0) this.abilityActiveTimer = 0;
		const phaseDamageMult = this.definition.activeAbility.phaseDamageMultiplier ?? .4;
		const dmg = this.phaseCloaked ? Math.round(shieldRes.remainingDamage * phaseDamageMult) : shieldRes.remainingDamage;
		let hullLost = 0;
		if (dmg > 0) {
			const prevHp = this.hp;
			this.hp = Math.max(0, this.hp - dmg);
			hullLost = prevHp - this.hp;
			this.hitFlashTimer = .085;
			this.hitFlashTint = 16751001;
		} else if (absorbed > 0) {
			this.hitFlashTimer = .075;
			this.hitFlashTint = 9684477;
		}
		const totalApplied = Math.round(absorbed + hullLost);
		if (this.hp <= 0) {
			this.alive = false;
			this.clearTemporaryEffects();
			this.recentAttackTimer = 0;
			this.hideAllVisuals();
			return {
				killed: true,
				actualDamage: totalApplied,
				shieldAbsorbed: Math.round(absorbed),
				shieldBroken
			};
		}
		return {
			killed: false,
			actualDamage: totalApplied,
			shieldAbsorbed: Math.round(absorbed),
			shieldBroken
		};
	}
	hideAllVisuals() {
		this.hullSprite.setVisible(false);
		this.turretSprite.setVisible(false);
		this.rapidFireRing.setVisible(false);
		this.afterburnerRing.setVisible(false);
		this.phaseRing.setVisible(false);
		this.slowRing.setVisible(false);
		this.shieldRing.setVisible(false);
		this.powerupAuraRing.setVisible(false);
		this.barBg.setVisible(false);
		this.barTrailFill.setVisible(false);
		this.barFill.setVisible(false);
		this.reloadBarBg.setVisible(false);
		this.reloadBarFill.setVisible(false);
		this.shieldFill.setVisible(false);
		this.nameLabel.setVisible(false);
		this.slowLabel.setVisible(false);
		if (this.playerRing) this.playerRing.setVisible(false);
		if (this.barrageReticle) this.barrageReticle.setVisible(false);
		if (this.radarSweepRing) this.radarSweepRing.setVisible(false);
		if (this.radarRevealRing) this.radarRevealRing.setVisible(false);
	}
	destroy() {
		this.clearTemporaryEffects();
		this.hullSprite.destroy();
		this.turretSprite.destroy();
		this.rapidFireRing.destroy();
		this.afterburnerRing.destroy();
		this.phaseRing.destroy();
		this.slowRing.destroy();
		this.shieldRing.destroy();
		this.powerupAuraRing.destroy();
		this.barBg.destroy();
		this.barTrailFill.destroy();
		this.barFill.destroy();
		this.reloadBarBg.destroy();
		this.reloadBarFill.destroy();
		this.shieldFill.destroy();
		this.nameLabel.destroy();
		this.slowLabel.destroy();
		if (this.playerRing) this.playerRing.destroy();
		if (this.barrageReticle) this.barrageReticle.destroy();
		if (this.radarSweepRing) this.radarSweepRing.destroy();
		if (this.radarRevealRing) this.radarRevealRing.destroy();
	}
};
// src/game/powerups/pickupPlacement.ts
function isValidPickupSpawnPosition(x, y, arenaWidth, arenaHeight, tanks, obstacles, spawns, existingItems, minPickupSeparation = POWERUP_SPAWN_CONFIG.minPickupSeparation) {
	const margin = 105;
	if (x < margin || x > arenaWidth - margin || y < margin || y > arenaHeight - margin) return false;
	for (const obs of obstacles) {
		if (!obs.alive) continue;
		if (obs.containsPoint(x, y, POWERUP_SPAWN_CONFIG.obstacleClearance)) return false;
	}
	const spawnClearSq = POWERUP_SPAWN_CONFIG.spawnPointClearance * POWERUP_SPAWN_CONFIG.spawnPointClearance;
	for (const sp of spawns) {
		const dx = sp.x - x;
		const dy = sp.y - y;
		if (dx * dx + dy * dy < spawnClearSq) return false;
	}
	for (const tank of tanks) {
		if (!tank.alive) continue;
		const dx = tank.x - x;
		const dy = tank.y - y;
		const minDist = tank.radius + POWERUP_SPAWN_CONFIG.tankClearance;
		if (dx * dx + dy * dy < minDist * minDist) return false;
	}
	const minSepSq = minPickupSeparation * minPickupSeparation;
	for (const existing of existingItems) {
		const dx = existing.x - x;
		const dy = existing.y - y;
		if (dx * dx + dy * dy < minSepSq) return false;
	}
	return true;
}
// src/game/powerups/PowerupManager.ts
var PowerupManager = class {
	constructor(scene) {
		this.items = [];
		this.spawnTimer = POWERUP_SPAWN_CONFIG.initialSpawnDelaySec;
		this.maxActive = POWERUP_SPAWN_CONFIG.maxActive;
		this.spawnIntervalSec = POWERUP_SPAWN_CONFIG.spawnIntervalSec;
		this.despawnDurationSec = POWERUP_SPAWN_CONFIG.despawnDurationSec;
		this.scene = scene;
	}
	getActivePowerups() {
		return this.items;
	}
	update(dt, arenaWidth, arenaHeight, tanks, obstacles, spawns, effects, onPickupCollected) {
		if (this.items.length < this.maxActive) {
			this.spawnTimer -= dt;
			if (this.spawnTimer <= 0) {
				this.spawnTimer = this.spawnIntervalSec;
				this.trySpawnPowerup(arenaWidth, arenaHeight, tanks, obstacles, spawns, effects);
			}
		}
		for (let i = this.items.length - 1; i >= 0; i--) {
			const item = this.items[i];
			item.lifeSec -= dt;
			item.pulseTime += dt;
			if (item.lifeSec <= 0) {
				item.sprite.destroy();
				item.halo.destroy();
				this.items.splice(i, 1);
				continue;
			}
			const bob = 1 + Math.sin(item.pulseTime * 4) * .06;
			item.sprite.setScale(bob);
			item.halo.setScale(.94 + Math.sin(item.pulseTime * 4) * .1);
			if (item.lifeSec < 4) {
				const blink = Math.sin(item.pulseTime * 16) > 0 ? 1 : .25;
				item.sprite.setAlpha(blink);
				item.halo.setAlpha(blink * .75);
			} else {
				item.sprite.setAlpha(1);
				item.halo.setAlpha(.55 + Math.sin(item.pulseTime * 4) * .2);
			}
			let collected = false;
			for (const tank of tanks) {
				if (!tank.alive) continue;
				if (Math.hypot(tank.x - item.x, tank.y - item.y) <= tank.radius + POWERUP_SPAWN_CONFIG.collectionPadding) {
					this.collectPowerup(tank, item, effects, onPickupCollected);
					item.sprite.destroy();
					item.halo.destroy();
					this.items.splice(i, 1);
					collected = true;
					break;
				}
			}
			if (collected) continue;
		}
	}
	collectPowerup(tank, item, effects, onPickupCollected) {
		const def = POWERUP_DEFINITIONS[item.id];
		const result = tank.applyBuff(item.id);
		if (!result.applied) return;
		const colorNum = __webpack_exports__default.Display.Color.HexStringToColor(def.color).color;
		effects.spawnRing(item.x, item.y, 44, colorNum, .28);
		if (tank.isPlayer) {
			let labelText = def.name.toUpperCase();
			if (item.id === "repair_kit") labelText = result.healedAmount > 0 ? `+${result.healedAmount} HP` : "HULL FULL";
			else if (item.id === "mine_kit") labelText = result.minesAdded > 0 ? `+${result.minesAdded} MINES` : "MINES FULL";
			effects.spawnFloatingLabel(tank.x, tank.y, labelText, def.color);
			soundFX.playPowerup();
		}
		onPickupCollected?.(tank, item.id, result);
	}
	trySpawnPowerup(arenaWidth, arenaHeight, tanks, obstacles, spawns, effects) {
		const margin = 110;
		const halfW = arenaWidth / 2;
		const halfH = arenaHeight / 2;
		const quadCounts = [
			0,
			0,
			0,
			0
		];
		for (const item of this.items) {
			const q = (item.x >= halfW ? 1 : 0) + (item.y >= halfH ? 2 : 0);
			quadCounts[q] += 1;
		}
		const minQuadCount = Math.min(...quadCounts);
		const preferredQuads = [];
		for (let q = 0; q < 4; q++) if (quadCounts[q] === minQuadCount) preferredQuads.push(q);
		let fallbackCandidate = null;
		let chosenCandidate = null;
		for (let attempt = 0; attempt < 48; attempt++) {
			const targetQuad = preferredQuads[attempt % preferredQuads.length];
			const usePreferredQuad = attempt < 36;
			const minX = usePreferredQuad && targetQuad & 1 ? halfW + 40 : margin;
			const maxX = usePreferredQuad && !(targetQuad & 1) ? halfW - 40 : arenaWidth - margin;
			const minY = usePreferredQuad && targetQuad & 2 ? halfH + 40 : margin;
			const maxY = usePreferredQuad && !(targetQuad & 2) ? halfH - 40 : arenaHeight - margin;
			const x = minX + Math.random() * Math.max(40, maxX - minX);
			const y = minY + Math.random() * Math.max(40, maxY - minY);
			if (isValidPickupSpawnPosition(x, y, arenaWidth, arenaHeight, tanks, obstacles, spawns, this.items, POWERUP_SPAWN_CONFIG.minPickupSeparation)) {
				chosenCandidate = {
					x,
					y
				};
				break;
			}
			if (!fallbackCandidate && isValidPickupSpawnPosition(x, y, arenaWidth, arenaHeight, tanks, obstacles, spawns, this.items, 200)) fallbackCandidate = {
				x,
				y
			};
		}
		const chosen = chosenCandidate ?? fallbackCandidate;
		if (!chosen) return;
		const id = POWERUP_IDS[Math.floor(Math.random() * POWERUP_IDS.length)];
		const def = POWERUP_DEFINITIONS[id];
		const colorNum = __webpack_exports__default.Display.Color.HexStringToColor(def.color).color;
		const halo = this.scene.add.circle(chosen.x, chosen.y, 26, colorNum, .14).setStrokeStyle(2, colorNum, .78).setDepth(8);
		const sprite = this.scene.add.image(chosen.x, chosen.y, `pwr_${id}`).setDepth(9);
		this.items.push({
			id,
			x: chosen.x,
			y: chosen.y,
			lifeSec: this.despawnDurationSec,
			sprite,
			halo,
			pulseTime: Math.random() * 4
		});
		effects.spawnRing(chosen.x, chosen.y, 34, colorNum, .24);
	}
	clear() {
		for (const item of this.items) {
			item.sprite.destroy();
			item.halo.destroy();
		}
		this.items = [];
		this.spawnTimer = POWERUP_SPAWN_CONFIG.initialSpawnDelaySec;
	}
};
// src/game/projectiles/ProjectilePool.ts
var ProjectilePool = class {
	constructor(scene, poolSize = 110) {
		this.pool = [];
		this.mines = [];
		this.barrageShells = [];
		this.tankLookup = /* @__PURE__ */ new Map();
		this.scene = scene;
		for (let i = 0; i < poolSize; i++) {
			const sprite = scene.add.image(-200, -200, "proj_standard");
			sprite.setDepth(18);
			sprite.setVisible(false);
			this.pool.push({
				sprite,
				active: false,
				ownerId: "",
				x: 0,
				y: 0,
				vx: 0,
				vy: 0,
				damage: 0,
				distanceLeft: 0,
				radius: 6,
				pierceLeft: 0,
				appliesSlow: false,
				slowFactor: 1,
				slowDurationSec: 0,
				hitEntityIds: /* @__PURE__ */ new Set(),
				hitObstacleIds: /* @__PURE__ */ new Set(),
				trailTimer: 0,
				trailColor: 16639626
			});
		}
		for (let i = 0; i < 16; i++) {
			const indicatorRing = scene.add.circle(-200, -200, 22, 16347926, .12).setStrokeStyle(2, 16347926, .8).setDepth(7).setVisible(false);
			const sprite = scene.add.image(-200, -200, "entity_mine");
			sprite.setDepth(8);
			sprite.setVisible(false);
			this.mines.push({
				sprite,
				indicatorRing,
				ownerId: "",
				x: 0,
				y: 0,
				armTimer: MINE_SYSTEM_CONFIG.armDelaySec,
				life: MINE_SYSTEM_CONFIG.durationSec,
				damage: MINE_SYSTEM_CONFIG.damage,
				pulseClock: 0,
				active: false
			});
		}
		for (let i = 0; i < 16; i++) {
			const warningOuter = scene.add.circle(-200, -200, 80, 15680580, .14).setStrokeStyle(2.5, 15680580, .85).setDepth(5).setVisible(false);
			const warningInner = scene.add.circle(-200, -200, 10, 16347926, .22).setStrokeStyle(2, 16436245, .9).setDepth(5).setVisible(false);
			const shadow = scene.add.circle(-200, -200, 8, 0, .3).setDepth(19).setVisible(false);
			const shellSprite = scene.add.image(-200, -200, "proj_artillery").setDepth(29).setVisible(false);
			this.barrageShells.push({
				warningOuter,
				warningInner,
				shadow,
				shellSprite,
				active: false,
				launched: false,
				impacted: false,
				ownerId: "",
				startX: 0,
				startY: 0,
				impactX: 0,
				impactY: 0,
				delayTimer: 0,
				flightTimer: 0,
				flightTotal: .65,
				aoeRadius: 88,
				damage: 28,
				hitEntityIds: /* @__PURE__ */ new Set(),
				hitObstacleIds: /* @__PURE__ */ new Set(),
				trailTimer: 0
			});
		}
	}
	spawn(opts) {
		for (const p of this.pool) if (!p.active) {
			p.active = true;
			p.ownerId = opts.owner.id;
			p.x = opts.x;
			p.y = opts.y;
			p.vx = Math.cos(opts.angle) * opts.speed;
			p.vy = Math.sin(opts.angle) * opts.speed;
			p.damage = opts.damage;
			p.distanceLeft = opts.range;
			p.radius = opts.radius;
			p.pierceLeft = opts.pierceCount;
			p.appliesSlow = opts.appliesSlow;
			p.slowFactor = opts.slowFactor;
			p.slowDurationSec = opts.slowDurationSec;
			p.hitEntityIds.clear();
			p.hitObstacleIds.clear();
			p.trailTimer = .025;
			p.trailColor = opts.textureKey === "proj_electric" ? 2282478 : opts.textureKey === "proj_artillery" || opts.textureKey === "proj_heavy" ? 16347926 : opts.textureKey === "proj_pierce" ? 12616956 : 16639626;
			p.sprite.setTexture(opts.textureKey);
			p.sprite.setPosition(opts.x, opts.y);
			p.sprite.setRotation(opts.angle);
			p.sprite.setVisible(true);
			return;
		}
	}
	spawnMine(ownerId, x, y, durationSec = MINE_SYSTEM_CONFIG.durationSec, armDelaySec = MINE_SYSTEM_CONFIG.armDelaySec, damage = MINE_SYSTEM_CONFIG.damage) {
		if (this.getActiveMineCount(ownerId) >= MINE_SYSTEM_CONFIG.maxActivePerTank || this.getActiveMineCount() >= MINE_SYSTEM_CONFIG.maxActiveGlobal) return false;
		for (const m of this.mines) if (!m.active) {
			m.active = true;
			m.ownerId = ownerId;
			m.x = x;
			m.y = y;
			m.armTimer = armDelaySec;
			m.life = durationSec;
			m.damage = damage;
			m.pulseClock = 0;
			m.sprite.setPosition(x, y).setAlpha(.65).setVisible(true);
			m.indicatorRing.setPosition(x, y).setStrokeStyle(2, 16436245, .65).setFillStyle(16436245, .1).setVisible(true);
			return true;
		}
		return false;
	}
	canSpawnMine(ownerId) {
		if (this.getActiveMineCount(ownerId) >= MINE_SYSTEM_CONFIG.maxActivePerTank || this.getActiveMineCount() >= MINE_SYSTEM_CONFIG.maxActiveGlobal) return false;
		for (const m of this.mines) if (!m.active) return true;
		return false;
	}
	getActiveMineCount(ownerId) {
		let count = 0;
		for (const m of this.mines) if (m.active && (!ownerId || m.ownerId === ownerId)) count += 1;
		return count;
	}
	clearAll() {
		for (const p of this.pool) {
			p.active = false;
			p.sprite.setVisible(false);
		}
		for (const m of this.mines) {
			m.active = false;
			m.sprite.setVisible(false);
			m.indicatorRing.setVisible(false);
		}
		for (const b of this.barrageShells) {
			b.active = false;
			b.launched = false;
			b.impacted = false;
			b.warningOuter.setVisible(false);
			b.warningInner.setVisible(false);
			b.shadow.setVisible(false);
			b.shellSprite.setVisible(false);
		}
	}
	spawnBarrage(opts) {
		let scheduled = 0;
		const count = Math.max(1, opts.shellCount);
		const baseAngle = Math.random() * Math.PI * 2;
		const minCoord = 28;
		const maxW = Math.max(29, opts.arenaWidth - minCoord);
		const maxH = Math.max(29, opts.arenaHeight - minCoord);
		for (let i = 0; i < count; i++) {
			const slot = this.barrageShells.find((b) => !b.active);
			if (!slot) break;
			const offsetDist = i === 0 ? Math.random() * 14 : opts.scatterRadius * (.45 + Math.random() * .55);
			const offsetAng = baseAngle + i * Math.PI * 2 / Math.max(1, count - 1) + (Math.random() - .5) * .4;
			const impactX = __webpack_exports__default.Math.Clamp(opts.targetX + Math.cos(offsetAng) * offsetDist, minCoord, maxW);
			const impactY = __webpack_exports__default.Math.Clamp(opts.targetY + Math.sin(offsetAng) * offsetDist, minCoord, maxH);
			slot.active = true;
			slot.launched = false;
			slot.impacted = false;
			slot.ownerId = opts.owner.id;
			slot.startX = opts.startX;
			slot.startY = opts.startY;
			slot.impactX = impactX;
			slot.impactY = impactY;
			slot.delayTimer = i * opts.impactIntervalSec;
			slot.flightTotal = Math.max(.25, opts.flightSec);
			slot.flightTimer = slot.flightTotal;
			slot.aoeRadius = opts.aoeRadius;
			slot.damage = opts.damage;
			slot.hitEntityIds.clear();
			slot.hitObstacleIds.clear();
			slot.trailTimer = .04;
			slot.warningOuter.setVisible(false);
			slot.warningInner.setVisible(false);
			slot.shadow.setVisible(false);
			slot.shellSprite.setVisible(false);
			scheduled += 1;
		}
		return scheduled;
	}
	update(dt, tanks, obstacles, arenaWidth, arenaHeight, effects, onBarrelExplode, onTankEliminated, onObstacleDestroyed) {
		this.tankLookup.clear();
		const tankMap = this.tankLookup;
		for (const t of tanks) tankMap.set(t.id, t);
		for (const m of this.mines) {
			if (!m.active) continue;
			m.life -= dt;
			m.pulseClock += dt;
			if (m.life <= 0) {
				m.active = false;
				m.sprite.setVisible(false);
				m.indicatorRing.setVisible(false);
				continue;
			}
			if (m.armTimer > 0) {
				m.armTimer -= dt;
				if (m.armTimer <= 0) {
					m.sprite.setAlpha(1);
					m.indicatorRing.setStrokeStyle(2, 16347926, .85).setFillStyle(16347926, .14);
				}
				continue;
			}
			const blinkWarn = m.life < 4 ? Math.sin(m.pulseClock * 18) > 0 ? 1 : .3 : 1;
			const pulseAlpha = (.45 + .4 * Math.abs(Math.sin(m.pulseClock * 6))) * blinkWarn;
			m.sprite.setAlpha(blinkWarn);
			m.indicatorRing.setAlpha(pulseAlpha);
			for (const t of tanks) {
				if (!t.alive || t.id === m.ownerId) continue;
				const mdx = t.x - m.x;
				const mdy = t.y - m.y;
				const trigR = t.radius + MINE_SYSTEM_CONFIG.triggerPadding;
				if (mdx * mdx + mdy * mdy <= trigR * trigR) {
					m.active = false;
					m.sprite.setVisible(false);
					m.indicatorRing.setVisible(false);
					effects.spawnDestruction(m.x, m.y, 16347926, 85);
					soundFX.playExplosion();
					const res = t.takeDamage(m.damage, "explosion");
					const attacker = tankMap.get(m.ownerId);
					if (attacker) attacker.damageDealt += res.actualDamage;
					if ((t.isPlayer || attacker?.isPlayer) && res.actualDamage > 0) effects.spawnDamageNumber(t.x, t.y, res.actualDamage, "explosion");
					if (res.killed) onTankEliminated(t, m.ownerId);
					break;
				}
			}
		}
		for (const p of this.pool) {
			if (!p.active) continue;
			const totalDx = p.vx * dt;
			const totalDy = p.vy * dt;
			const totalDist = Math.hypot(totalDx, totalDy);
			const subSteps = Math.max(1, Math.ceil(totalDist / 8));
			const subDx = totalDx / subSteps;
			const subDy = totalDy / subSteps;
			const subDist = totalDist / subSteps;
			for (let step = 0; step < subSteps; step++) {
				if (!p.active) break;
				p.x += subDx;
				p.y += subDy;
				p.distanceLeft -= subDist;
				const outOfBounds = p.x < 10 || p.x > arenaWidth - 10 || p.y < 10 || p.y > arenaHeight - 10;
				if (p.distanceLeft <= 0 || outOfBounds) {
					p.active = false;
					p.sprite.setVisible(false);
					if (outOfBounds) {
						effects.spawnImpact(p.x, p.y, 9741240);
						effects.spawnRing(p.x, p.y, 16, 9741240, .14);
					} else effects.spawnTrailPuff(p.x, p.y, 15067115, .25);
					break;
				}
				let consumed = false;
				for (const obs of obstacles) {
					if (!obs.alive || !obs.blocksProjectiles) continue;
					if (p.hitObstacleIds.has(obs.id)) continue;
					if (obs.containsPoint(p.x, p.y, p.radius)) {
						p.hitObstacleIds.add(obs.id);
						const obsKind = obs.type === "crate" ? "crate" : obs.type === "brick" ? "brick" : "steel";
						if (obs.destructible) {
							if (obs.damage(p.damage, this.scene, p.ownerId)) {
								if (obs.type === "barrel") onBarrelExplode(obs.x, obs.y, p.ownerId);
								else {
									effects.spawnDestruction(obs.x, obs.y, obs.type === "brick" ? 11817737 : 14251782, 48);
									effects.spawnObstacleDebris(obs.x, obs.y, obsKind);
									soundFX.playImpact("destructible");
									onObstacleDestroyed?.(obs, p.ownerId);
								}
							} else {
								effects.spawnObstacleDebris(p.x, p.y, obsKind);
								if (obs.isPriming) effects.spawnImpact(p.x, p.y, 16436245);
								soundFX.playImpact("destructible");
							}
							if (p.pierceLeft > 0) p.pierceLeft -= 1;
							else consumed = true;
						} else {
							effects.spawnObstacleDebris(p.x, p.y, "steel");
							soundFX.playImpact("steel");
							consumed = true;
						}
						break;
					}
				}
				if (consumed) {
					p.active = false;
					p.sprite.setVisible(false);
					break;
				}
				for (const tank of tanks) {
					if (!tank.alive || tank.id === p.ownerId) continue;
					if (p.hitEntityIds.has(tank.id)) continue;
					const tdx = tank.x - p.x;
					const tdy = tank.y - p.y;
					const hitR = tank.radius + p.radius;
					if (tdx * tdx + tdy * tdy <= hitR * hitR) {
						p.hitEntityIds.add(tank.id);
						const res = tank.takeDamage(p.damage);
						const attacker = tankMap.get(p.ownerId);
						if (attacker) attacker.damageDealt += res.actualDamage;
						if (p.appliesSlow) tank.applySlow(p.slowFactor, p.slowDurationSec, "static");
						if (res.shieldAbsorbed > 0) {
							effects.spawnImpact(p.x, p.y, 3718648);
							soundFX.playImpact("shield");
							if (res.shieldBroken) {
								effects.spawnRing(tank.x, tank.y, tank.radius + 22, 3718648, .28);
								soundFX.playShieldBreak();
							}
						} else if (p.appliesSlow) {
							effects.spawnElectricImpact(p.x, p.y);
							soundFX.playImpact("tank");
						} else {
							effects.spawnImpact(p.x, p.y, 15680580);
							soundFX.playImpact("tank");
						}
						if ((tank.isPlayer || attacker?.isPlayer) && res.actualDamage > 0) {
							const kind = res.shieldAbsorbed > 0 && res.actualDamage === res.shieldAbsorbed ? "shield" : p.appliesSlow ? "electric" : "normal";
							effects.spawnDamageNumber(tank.x, tank.y, res.actualDamage, kind);
						}
						if (res.killed) onTankEliminated(tank, p.ownerId);
						if (p.pierceLeft > 0) p.pierceLeft -= 1;
						else {
							p.active = false;
							p.sprite.setVisible(false);
						}
						break;
					}
				}
			}
			if (p.active) {
				p.sprite.setPosition(p.x, p.y);
				p.trailTimer -= dt;
				if (p.trailTimer <= 0) {
					p.trailTimer = p.trailColor === 2282478 ? .04 : .052;
					effects.spawnTrailPuff(p.x, p.y, p.trailColor, p.radius >= 8 ? .28 : .2);
				}
			}
		}
		for (const b of this.barrageShells) {
			if (!b.active || b.impacted) continue;
			if (b.delayTimer > 0) {
				b.delayTimer -= dt;
				if (b.delayTimer > 0) continue;
				b.delayTimer = 0;
			}
			if (!b.launched) {
				b.launched = true;
				b.warningOuter.setPosition(b.impactX, b.impactY).setRadius(b.aoeRadius).setVisible(true);
				b.warningInner.setPosition(b.impactX, b.impactY).setRadius(8).setVisible(true);
				b.shadow.setPosition(b.startX, b.startY).setVisible(true);
				b.shellSprite.setPosition(b.startX, b.startY).setRotation(Math.atan2(b.impactY - b.startY, b.impactX - b.startX)).setScale(.95).setVisible(true);
				effects.spawnMuzzleFlash(b.startX, b.startY, Math.atan2(b.impactY - b.startY, b.impactX - b.startX));
			}
			b.flightTimer -= dt;
			if (b.flightTimer > 0) {
				const progress = __webpack_exports__default.Math.Clamp(1 - b.flightTimer / b.flightTotal, 0, 1);
				b.warningInner.setRadius(Math.max(8, b.aoeRadius * progress));
				const sx = __webpack_exports__default.Math.Linear(b.startX, b.impactX, progress);
				const sy = __webpack_exports__default.Math.Linear(b.startY, b.impactY, progress);
				const arcLift = Math.sin(progress * Math.PI) * 64;
				b.shadow.setPosition(sx, sy);
				b.shellSprite.setPosition(sx, sy - arcLift).setScale(.95 + Math.sin(progress * Math.PI) * .45);
				b.trailTimer -= dt;
				if (b.trailTimer <= 0) {
					b.trailTimer = .06;
					effects.spawnTrailPuff(sx, sy - arcLift, 16347926, .26);
				}
				continue;
			}
			b.impacted = true;
			b.active = false;
			b.warningOuter.setVisible(false);
			b.warningInner.setVisible(false);
			b.shadow.setVisible(false);
			b.shellSprite.setVisible(false);
			effects.spawnDestruction(b.impactX, b.impactY, 15680580, b.aoeRadius);
			soundFX.playExplosion();
			const attacker = tankMap.get(b.ownerId);
			for (const tank of tanks) {
				if (!tank.alive || tank.id === b.ownerId) continue;
				if (b.hitEntityIds.has(tank.id)) continue;
				const dist = Math.hypot(tank.x - b.impactX, tank.y - b.impactY);
				const hitThreshold = b.aoeRadius + tank.radius * .5;
				if (dist <= hitThreshold) {
					b.hitEntityIds.add(tank.id);
					const falloff = 1 - .35 * Math.min(1, dist / Math.max(1, hitThreshold));
					const dmg = Math.round(b.damage * falloff);
					const res = tank.takeDamage(dmg, "explosion");
					if (attacker) attacker.damageDealt += res.actualDamage;
					if ((tank.isPlayer || attacker?.isPlayer) && res.actualDamage > 0) effects.spawnDamageNumber(tank.x, tank.y, res.actualDamage, "explosion");
					if (res.killed) onTankEliminated(tank, b.ownerId);
				}
			}
			const obsHitRangeSq = b.aoeRadius * .85 * (b.aoeRadius * .85);
			for (const obs of obstacles) {
				if (!obs.alive || !obs.destructible) continue;
				if (b.hitObstacleIds.has(obs.id)) continue;
				const odx = obs.x - b.impactX;
				const ody = obs.y - b.impactY;
				if (odx * odx + ody * ody <= obsHitRangeSq) {
					b.hitObstacleIds.add(obs.id);
					if (obs.damage(Math.round(b.damage * .85), this.scene, b.ownerId)) {
						if (obs.type === "barrel") onBarrelExplode(obs.x, obs.y, b.ownerId);
						else {
							effects.spawnDestruction(obs.x, obs.y, obs.type === "brick" ? 11817737 : 14251782, 48);
							effects.spawnObstacleDebris(obs.x, obs.y, obs.type === "brick" ? "brick" : "crate");
							onObstacleDestroyed?.(obs, b.ownerId);
						}
					}
				}
			}
		}
	}
	getActiveBarrageCount(ownerId) {
		let count = 0;
		for (const b of this.barrageShells) if (b.active && (!ownerId || b.ownerId === ownerId)) count += 1;
		return count;
	}
	getActiveThreatNear(x, y, radius, ignoreOwnerId) {
		const radiusSq = radius * radius;
		for (const p of this.pool) {
			if (!p.active || p.ownerId === ignoreOwnerId) continue;
			const dx = p.x - x;
			const dy = p.y - y;
			if (dx * dx + dy * dy < radiusSq) return {
				vx: p.vx,
				vy: p.vy
			};
		}
		for (const b of this.barrageShells) {
			if (!b.active || !b.launched || b.impacted) continue;
			const dx = b.impactX - x;
			const dy = b.impactY - y;
			const r = b.aoeRadius + 30;
			if (dx * dx + dy * dy <= r * r) return {
				vx: dx || 1,
				vy: dy || 0
			};
		}
		return null;
	}
};
// src/game/systems/EffectsPool.ts
var EffectsPool = class {
	constructor(scene, qualityOrLowDetail = "high") {
		this.puffs = [];
		this.rings = [];
		this.decals = [];
		this.labels = [];
		this.lowDetail = false;
		this.quality = "high";
		const quality = typeof qualityOrLowDetail === "boolean" ? qualityOrLowDetail ? "low" : "high" : qualityOrLowDetail;
		this.quality = quality;
		this.lowDetail = quality === "low";
		const maxPuffs = quality === "low" ? 45 : quality === "medium" ? 80 : 120;
		for (let i = 0; i < maxPuffs; i++) {
			const sprite = scene.add.image(-200, -200, "fx_puff");
			sprite.setDepth(28);
			sprite.setVisible(false);
			this.puffs.push({
				sprite,
				vx: 0,
				vy: 0,
				life: 0,
				maxLife: .3,
				startScale: .4,
				endScale: 1,
				active: false
			});
		}
		const maxRings = 24;
		for (let i = 0; i < maxRings; i++) {
			const graphics = scene.add.circle(-200, -200, 10, 16096779, 0);
			graphics.setStrokeStyle(4, 16096779, 1);
			graphics.setDepth(27);
			graphics.setVisible(false);
			this.rings.push({
				graphics,
				life: 0,
				maxLife: .35,
				maxRadius: 80,
				active: false
			});
		}
		const maxDecals = quality === "low" ? 16 : quality === "medium" ? 28 : 48;
		for (let i = 0; i < maxDecals; i++) {
			const sprite = scene.add.image(-200, -200, "fx_tread");
			sprite.setDepth(3);
			sprite.setVisible(false);
			this.decals.push({
				sprite,
				life: 0,
				maxLife: 1.4,
				startAlpha: .4,
				active: false
			});
		}
		const maxLabels = 24;
		for (let i = 0; i < maxLabels; i++) {
			const label = scene.add.text(-200, -200, "", {
				fontFamily: "\"Barlow Condensed\", sans-serif",
				fontSize: "18px",
				fontStyle: "bold",
				color: "#F3EFE6",
				stroke: "#141714",
				strokeThickness: 4
			}).setOrigin(.5).setDepth(35).setVisible(false);
			this.labels.push({
				label,
				startY: 0,
				risePx: 32,
				life: 0,
				maxLife: .65,
				active: false
			});
		}
	}
	setGraphicsQuality(quality) {
		this.quality = quality;
		this.lowDetail = quality === "low";
	}
	setLowDetail(lowDetail) {
		this.quality = lowDetail ? "low" : "high";
		this.lowDetail = lowDetail;
	}
	scaleCount(highCount, mediumCount, lowCount) {
		if (this.quality === "low") return lowCount;
		if (this.quality === "medium") return mediumCount;
		return highCount;
	}
	spawnPuff(x, y, vx, vy, tint, life, startScale, endScale) {
		for (const p of this.puffs) if (!p.active) {
			p.active = true;
			p.vx = vx;
			p.vy = vy;
			p.life = life;
			p.maxLife = life;
			p.startScale = startScale;
			p.endScale = endScale;
			p.sprite.setPosition(x, y);
			p.sprite.setTint(tint);
			p.sprite.setAlpha(.9);
			p.sprite.setScale(startScale);
			p.sprite.setVisible(true);
			return;
		}
	}
	spawnRing(x, y, maxRadius, color = 16096779, duration = .32) {
		for (const r of this.rings) if (!r.active) {
			r.active = true;
			r.life = duration;
			r.maxLife = duration;
			r.maxRadius = maxRadius;
			r.graphics.setPosition(x, y);
			r.graphics.setRadius(10);
			r.graphics.setStrokeStyle(4, color, 1);
			r.graphics.setFillStyle(color, .16);
			r.graphics.setAlpha(1);
			r.graphics.setVisible(true);
			return;
		}
	}
	spawnTreadMark(x, y, hullAngle, isHeavy = false) {
		if (this.lowDetail) return;
		for (const d of this.decals) if (!d.active) {
			d.active = true;
			d.life = 1.4;
			d.maxLife = 1.4;
			d.startAlpha = .42;
			d.sprite.setTexture("fx_tread").setPosition(x, y).setRotation(hullAngle).setScale(isHeavy ? 1.18 : .95).setAlpha(.42).setVisible(true);
			return;
		}
	}
	spawnScorchMark(x, y, radius = 48) {
		if (this.lowDetail) return;
		for (const d of this.decals) if (!d.active) {
			d.active = true;
			d.life = 4.2;
			d.maxLife = 4.2;
			d.startAlpha = .65;
			d.sprite.setTexture("fx_scorch").setPosition(x, y).setRotation(Math.random() * Math.PI * 2).setScale(Math.max(.65, radius / 34)).setAlpha(.65).setVisible(true);
			return;
		}
	}
	spawnTrailPuff(x, y, tint, startScale = .24) {
		if (this.lowDetail) return;
		this.spawnPuff(x, y, (Math.random() - .5) * 14, (Math.random() - .5) * 14, tint, .16, startScale, .04);
	}
	spawnMuzzleFlash(x, y, angle) {
		const count = this.lowDetail ? 1 : 2;
		for (let i = 0; i < count; i++) {
			const spread = (Math.random() - .5) * .4;
			const spd = 70 + Math.random() * 50;
			this.spawnPuff(x, y, Math.cos(angle + spread) * spd, Math.sin(angle + spread) * spd, 16707722, .13, .35, .7);
		}
	}
	spawnElectricMuzzleFlash(x, y, angle) {
		const count = this.lowDetail ? 2 : 3;
		for (let i = 0; i < count; i++) {
			const spread = (Math.random() - .5) * .6;
			const spd = 80 + Math.random() * 65;
			this.spawnPuff(x, y, Math.cos(angle + spread) * spd, Math.sin(angle + spread) * spd, i === 0 ? 14742270 : 2282478, .15, .32, .62);
		}
	}
	spawnElectricImpact(x, y) {
		this.spawnRing(x, y, 30, 2282478, .2);
		const count = this.scaleCount(6, 4, 3);
		for (let i = 0; i < count; i++) {
			const a = Math.random() * Math.PI * 2;
			const spd = 70 + Math.random() * 120;
			this.spawnPuff(x, y, Math.cos(a) * spd, Math.sin(a) * spd, i % 2 === 0 ? 2282478 : 14742270, .24, .3, .05);
		}
	}
	spawnEmpPulse(x, y, maxRadius) {
		this.spawnRing(x, y, maxRadius, 2282478, .4);
		this.spawnRing(x, y, Math.round(maxRadius * .62), 10875900, .28);
		const count = this.scaleCount(12, 8, 6);
		for (let i = 0; i < count; i++) {
			const a = Math.PI * 2 * i / count + (Math.random() - .5) * .2;
			const spd = 140 + Math.random() * 110;
			this.spawnPuff(x + Math.cos(a) * 16, y + Math.sin(a) * 16, Math.cos(a) * spd, Math.sin(a) * spd, i % 2 === 0 ? 2282478 : 14742270, .32, .34, .08);
		}
	}
	spawnPhaseShift(x, y, entering) {
		this.spawnRing(x, y, entering ? 56 : 42, entering ? 10980346 : 12891645, entering ? .32 : .24);
		const count = this.lowDetail ? 3 : 6;
		for (let i = 0; i < count; i++) {
			const a = Math.PI * 2 * i / count + (Math.random() - .5) * .3;
			const spd = (entering ? 85 : 55) + Math.random() * 65;
			this.spawnPuff(x + Math.cos(a) * 8, y + Math.sin(a) * 8, Math.cos(a) * spd, Math.sin(a) * spd, i % 2 === 0 ? 10980346 : 14538494, entering ? .28 : .2, .3, .06);
		}
	}
	spawnLeafRustle(x, y) {
		if (this.lowDetail) return;
		for (let i = 0; i < 3; i++) {
			const a = Math.random() * Math.PI * 2;
			const spd = 30 + Math.random() * 45;
			this.spawnPuff(x + (Math.random() - .5) * 12, y + (Math.random() - .5) * 12, Math.cos(a) * spd, Math.sin(a) * spd, i === 0 ? 6200918 : 4883780, .26, .25, .06);
		}
	}
	spawnObstacleDebris(x, y, kind) {
		const count = kind === "steel" ? this.scaleCount(4, 3, 2) : this.scaleCount(7, 5, 3);
		const colA = kind === "crate" ? 14251782 : kind === "brick" ? 11817737 : 14870768;
		const colB = kind === "crate" ? 9584654 : kind === "brick" ? 14078929 : 9741240;
		if (kind === "steel") this.spawnRing(x, y, 20, 13358561, .14);
		for (let i = 0; i < count; i++) {
			const a = Math.random() * Math.PI * 2;
			const spd = 55 + Math.random() * 115;
			this.spawnPuff(x, y, Math.cos(a) * spd, Math.sin(a) * spd, i % 2 === 0 ? colA : colB, .28, kind === "steel" ? .24 : .34, .06);
		}
	}
	spawnImpact(x, y, tint = 16096779) {
		const count = this.scaleCount(6, 4, 3);
		for (let i = 0; i < count; i++) {
			const a = Math.random() * Math.PI * 2;
			const spd = 60 + Math.random() * 110;
			this.spawnPuff(x, y, Math.cos(a) * spd, Math.sin(a) * spd, tint, .22, .28, .05);
		}
	}
	spawnDestruction(x, y, tint = 10265519, radius = 64) {
		this.spawnRing(x, y, radius, tint, .34);
		this.spawnScorchMark(x, y, Math.min(72, radius * .8));
		const count = this.scaleCount(12, 8, 6);
		for (let i = 0; i < count; i++) {
			const a = Math.PI * 2 * i / count + (Math.random() - .5) * .3;
			const spd = 70 + Math.random() * 140;
			this.spawnPuff(x, y, Math.cos(a) * spd, Math.sin(a) * spd, i % 2 === 0 ? tint : 2696484, .38, .48, .15);
		}
	}
	spawnTreadDust(x, y) {
		if (this.lowDetail) return;
		this.spawnPuff(x + (Math.random() - .5) * 10, y + (Math.random() - .5) * 10, (Math.random() - .5) * 18, (Math.random() - .5) * 18, 11050893, .28, .22, .55);
	}
	spawnAfterburnerExhaust(x, y, hullAngle, burst = false) {
		if (this.lowDetail && !burst) return;
		const count = burst ? this.lowDetail ? 2 : 4 : 1;
		const backAngle = hullAngle + Math.PI;
		for (let i = 0; i < count; i++) {
			const spread = (Math.random() - .5) * .55;
			const spd = (burst ? 110 : 85) + Math.random() * 55;
			this.spawnPuff(x + (Math.random() - .5) * 6, y + (Math.random() - .5) * 6, Math.cos(backAngle + spread) * spd, Math.sin(backAngle + spread) * spd, i % 2 === 0 ? 16436245 : 16347926, burst ? .24 : .16, burst ? .34 : .26, .06);
		}
	}
	spawnFloatingLabel(x, y, text, color = "#F3EFE6", fontSize = "17px") {
		for (const item of this.labels) if (!item.active) {
			item.active = true;
			item.startY = y - 18;
			item.risePx = 30;
			item.life = .65;
			item.maxLife = .65;
			item.label.setText(text).setColor(color).setFontSize(fontSize).setPosition(x + (Math.random() - .5) * 10, item.startY).setAlpha(1).setVisible(true);
			return;
		}
	}
	spawnDamageNumber(x, y, amount, kind = "normal") {
		if (amount <= 0) return;
		const prefix = kind === "shield" ? "SHD -" : kind === "electric" ? "⚡ -" : "-";
		const color = kind === "shield" ? "#7DD3FC" : kind === "electric" ? "#67E8F9" : kind === "explosion" ? "#FB923C" : "#FEF08A";
		this.spawnFloatingLabel(x, y - 6, `${prefix}${Math.round(amount)}`, color, "16px");
	}
	update(dt) {
		for (const p of this.puffs) {
			if (!p.active) continue;
			p.life -= dt;
			if (p.life <= 0) {
				p.active = false;
				p.sprite.setVisible(false);
				continue;
			}
			const progress = 1 - p.life / p.maxLife;
			p.sprite.x += p.vx * dt;
			p.sprite.y += p.vy * dt;
			p.vx *= .92;
			p.vy *= .92;
			p.sprite.setScale(__webpack_exports__default.Math.Linear(p.startScale, p.endScale, progress));
			p.sprite.setAlpha(1 - progress);
		}
		for (const r of this.rings) {
			if (!r.active) continue;
			r.life -= dt;
			if (r.life <= 0) {
				r.active = false;
				r.graphics.setVisible(false);
				continue;
			}
			const progress = 1 - r.life / r.maxLife;
			r.graphics.setRadius(__webpack_exports__default.Math.Linear(12, r.maxRadius, progress));
			r.graphics.setAlpha(1 - progress);
		}
		for (const d of this.decals) {
			if (!d.active) continue;
			d.life -= dt;
			if (d.life <= 0) {
				d.active = false;
				d.sprite.setVisible(false);
				continue;
			}
			const progress = 1 - d.life / d.maxLife;
			d.sprite.setAlpha(d.startAlpha * (1 - progress));
		}
		for (const item of this.labels) {
			if (!item.active) continue;
			item.life -= dt;
			if (item.life <= 0) {
				item.active = false;
				item.label.setVisible(false);
				continue;
			}
			const progress = 1 - item.life / item.maxLife;
			const eased = 1 - Math.pow(1 - progress, 2);
			item.label.setY(item.startY - item.risePx * eased);
			item.label.setAlpha(progress > .55 ? (1 - progress) / .45 : 1);
		}
	}
};
// src/utils/haptics.ts
function isVibrationSupported() {
	return typeof navigator !== "undefined" && typeof navigator.vibrate === "function";
}
function triggerHaptic(enabled, pattern) {
	if (!enabled || !isVibrationSupported()) return;
	try {
		navigator.vibrate(pattern);
	} catch {}
}
// src/game/scenes/ArenaScene.ts
var BOT_CALLSIGNS = [
	"Viper",
	"Anvil",
	"Kestrel",
	"Brimstone",
	"Cobalt",
	"Riptide",
	"Nomad",
	"Bastion",
	"Switchblade",
	"Goliath"
];
var BOT_PERSONALITIES = [
	"aggressive",
	"tactical",
	"mobile",
	"defensive",
	"opportunistic",
	"aggressive",
	"tactical"
];
var ArenaScene = class extends __webpack_exports__default.Scene {
	constructor() {
		super({ key: "ArenaScene" });
		this.tanks = [];
		this.aiMap = /* @__PURE__ */ new Map();
		this.obstacles = [];
		this.matchTimeLeft = 150;
		this.elapsedMatchSec = 0;
		this.matchEnded = false;
		this.matchId = "";
		this.paused = false;
		this.hudPushTimer = 0;
		this.killFeedText = null;
		this.killFeedTimer = 0;
		this.recentPickupName = null;
		this.recentPickupColor = null;
		this.recentPickupTimer = 0;
		this.pendingDefeatTimer = null;
		this.manualAimHoldTimer = 0;
		this.playerEliminatedAtSec = null;
		this.prepRemainingSec = 3;
		this.lastPrepStep = 3;
		this.goBannerTimer = 0;
		this.emptyFeedbackTimer = 0;
		this.mouseScreenX = 0;
		this.mouseScreenY = 0;
		this.lastAimDistance = 420;
		this.sceneActive = true;
		this.eventSeq = 0;
		this.matchStartEmitted = false;
		this.pausedByUser = false;
		this.pausedByPlatform = false;
		this.handleWindowBlur = () => {
			gameBridge.resetInput();
			soundFX.updateMovementAudio(0, false);
		};
		this.handleVisibilityChange = () => {
			if (typeof document !== "undefined" && document.visibilityState === "hidden") {
				gameBridge.resetInput();
				soundFX.updateMovementAudio(0, false);
			}
		};
		this.handleBarrelExplosion = (bx, by, attackerId) => {
			if (!this.sceneActive || this.matchEnded) return;
			const blastRadius = 125;
			this.effects.spawnDestruction(bx, by, 16347926, blastRadius);
			soundFX.playExplosion();
			if ((this.launchConfig.settings.screenShakeEnabled ?? true) && this.launchConfig.settings.graphicsQuality !== "low" && !this.launchConfig.settings.lowDetailMode) this.cameras.main.shake(120, .006);
			const attacker = this.tanks.find((t) => t.id === attackerId);
			for (const tank of this.tanks) {
				if (!tank.alive) continue;
				const dist = Math.hypot(tank.x - bx, tank.y - by);
				if (dist <= blastRadius + tank.radius) {
					const falloff = 1 - Math.min(.6, dist / (blastRadius + tank.radius));
					const dmg = Math.round(52 * falloff);
					const res = tank.takeDamage(dmg, "explosion");
					if (attacker && tank.id !== attacker.id) attacker.damageDealt += res.actualDamage;
					if ((tank.isPlayer || attacker?.isPlayer) && res.actualDamage > 0) {
						this.effects.spawnDamageNumber(tank.x, tank.y, res.actualDamage, "explosion");
						if (tank.isPlayer) triggerHaptic(this.launchConfig.settings.vibrationEnabled, 30);
					}
					if (res.killed) this.handleTankEliminated(tank, attackerId);
				}
			}
			for (const obs of this.obstacles) {
				if (!obs.alive || !obs.destructible) continue;
				if (Math.hypot(obs.x - bx, obs.y - by) <= blastRadius) {
					if (obs.damage(45, this, attackerId)) {
						this.handleObstacleDestroyed(obs, attackerId);
						if (obs.type === "barrel") this.time.delayedCall(90, () => this.handleBarrelExplosion(obs.x, obs.y, attackerId));
					}
				}
			}
		};
		this.handleObstacleDestroyed = (obs, attackerId) => {
			if (attackerId !== "player") return;
			gameBridge.emitGameplayEvent({
				eventId: `${this.matchId}:obs:${obs.id}`,
				type: "obstacle_destroyed",
				matchId: this.matchId,
				obstacleId: obs.id,
				obstacleType: obs.type
			});
		};
		this.handleTankEliminated = (victim, attackerId) => {
			victim.eliminatedAtRank = this.tanks.filter((t) => t.alive).length + 1;
			const attacker = this.tanks.find((t) => t.id === attackerId);
			if (attacker && attacker.id !== victim.id) {
				attacker.eliminations += 1;
				this.killFeedText = `${attacker.displayName} eliminated ${victim.displayName}`;
				if (attacker.isPlayer && !victim.isPlayer) gameBridge.emitGameplayEvent({
					eventId: `${this.matchId}:elim:${victim.id}`,
					type: "tank_elimination",
					matchId: this.matchId,
					victimId: victim.id
				});
			} else this.killFeedText = `${victim.displayName} destroyed`;
			this.killFeedTimer = 3;
			const playerInvolved = victim.isPlayer || Boolean(attacker?.isPlayer);
			this.effects.spawnDestruction(victim.x, victim.y, 15680580, 72);
			soundFX.playElimination(playerInvolved);
			const allowShake = (this.launchConfig.settings.screenShakeEnabled ?? true) && this.launchConfig.settings.graphicsQuality !== "low" && !this.launchConfig.settings.lowDetailMode;
			if (playerInvolved && allowShake) this.cameras.main.shake(105, .0045);
			if (playerInvolved) triggerHaptic(this.launchConfig.settings.vibrationEnabled, victim.isPlayer ? [
				45,
				35,
				60
			] : 28);
			if (victim.isPlayer && this.pendingDefeatTimer === null && !this.matchEnded) {
				soundFX.updateMovementAudio(0, false);
				this.playerEliminatedAtSec = this.elapsedMatchSec;
				this.pendingDefeatTimer = .85;
			}
			this.emitHudSnapshot();
		};
	}
	init(data) {
		const safeData = data ?? gameBridge.getLaunchConfig() ?? {
			tankId: "assault",
			arenaId: "training_grounds",
			settings: {
				soundEnabled: true,
				soundVolume: .65,
				musicEnabled: true,
				musicVolume: .4,
				graphicsQuality: "high",
				screenShakeEnabled: true,
				vibrationEnabled: true,
				controlSensitivity: 1,
				showTouchControls: "always",
				autoFireOnAim: false,
				lowDetailMode: false,
				matchDurationSec: 150,
				landscapePromptEnabled: true
			}
		};
		this.launchConfig = safeData;
		this.sceneActive = true;
		this.arena = ARENA_DEFINITIONS[safeData.arenaId] || ARENA_DEFINITIONS.training_grounds;
		this.matchTimeLeft = safeData.settings?.matchDurationSec || 150;
		this.elapsedMatchSec = 0;
		this.matchEnded = false;
		this.matchId = `match_${Date.now()}_${Math.random().toString(36).slice(2, 9)}`;
		this.paused = false;
		this.pausedByUser = false;
		this.pausedByPlatform = false;
		this.hudPushTimer = 0;
		this.killFeedText = null;
		this.killFeedTimer = 0;
		this.recentPickupName = null;
		this.recentPickupColor = null;
		this.recentPickupTimer = 0;
		this.pendingDefeatTimer = null;
		this.manualAimHoldTimer = 0;
		this.playerEliminatedAtSec = null;
		this.prepRemainingSec = 3;
		this.lastPrepStep = 3;
		this.goBannerTimer = 0;
		this.emptyFeedbackTimer = 0;
		this.mouseScreenX = 0;
		this.mouseScreenY = 0;
		this.lastAimDistance = 420;
		this.eventSeq = 0;
		this.matchStartEmitted = false;
		this.tanks = [];
		this.obstacles = [];
		this.aiMap.clear();
	}
	create() {
		const playerCosmetic = this.launchConfig.cosmeticId ?? "default";
		ensureProceduralTextures(this, playerCosmetic);
		const playerTex = ensurePlayerTankTextures(this, this.launchConfig.tankId, playerCosmetic, this.launchConfig.customization ?? null);
		soundFX.configure(this.launchConfig.settings.soundEnabled, this.launchConfig.settings.soundVolume, this.launchConfig.settings.musicEnabled ?? true, this.launchConfig.settings.musicVolume ?? .4);
		soundFX.setMusicMode("battle");
		this.drawArenaGround();
		const quality = this.launchConfig.settings.graphicsQuality ?? (this.launchConfig.settings.lowDetailMode ? "low" : "high");
		this.effects = new EffectsPool(this, quality);
		this.projectiles = new ProjectilePool(this, 120);
		this.powerups = new PowerupManager(this);
		this.arena.obstacles.forEach((obs, idx) => {
			this.obstacles.push(new ObstacleEntity(this, idx + 1, obs));
		});
		const allSpawns = [...this.arena.spawns];
		const cornerIndices = [
			0,
			2,
			4,
			6
		].filter((idx) => idx < allSpawns.length);
		const chosenCornerIdx = cornerIndices.length > 0 ? cornerIndices[Math.floor(Math.random() * cornerIndices.length)] : 0;
		const pSpawn = allSpawns.splice(chosenCornerIdx, 1)[0];
		const shuffledBotSpawns = __webpack_exports__default.Utils.Array.Shuffle(allSpawns);
		const shuffledNames = __webpack_exports__default.Utils.Array.Shuffle([...BOT_CALLSIGNS]);
		const playerDef = TANK_DEFINITIONS[this.launchConfig.tankId] || TANK_DEFINITIONS.assault;
		this.playerTank = new TankEntity(this, "player", "YOU", true, playerDef, pSpawn.x, pSpawn.y, pSpawn.angle, "tactical", playerCosmetic, playerTex);
		this.tanks.push(this.playerTank);
		const botClasses = [
			"assault",
			"scout",
			"fortress",
			"artillery",
			"tesla",
			"phantom",
			"assault"
		];
		const shuffledPersonalities = __webpack_exports__default.Utils.Array.Shuffle([...BOT_PERSONALITIES]);
		for (let i = 1; i < 8; i++) {
			const sp = shuffledBotSpawns[i - 1];
			const botDef = TANK_DEFINITIONS[botClasses[i - 1] ?? TANK_LIST[i % TANK_LIST.length].id];
			const botId = `bot_${i}`;
			const botTank = new TankEntity(this, botId, shuffledNames[i - 1], false, botDef, sp.x, sp.y, sp.angle, shuffledPersonalities[i - 1] ?? "tactical");
			botTank.abilityCooldownTimer = 5.5 + Math.random() * 4;
			botTank.hideAllVisuals();
			this.tanks.push(botTank);
			this.aiMap.set(botId, new AIController());
		}
		this.cameras.main.setBounds(0, 0, this.arena.width, this.arena.height);
		this.cameras.main.startFollow(this.playerTank.hullSprite, true, .14, .14);
		this.cameras.main.centerOn(this.playerTank.x, this.playerTank.y);
		this.setupInputs();
		this.unsubCommand = gameBridge.onCommand((cmd) => {
			if (!this.sceneActive) return;
			if (cmd === "PAUSE") this.setPaused(true, "user");
			else if (cmd === "RESUME") this.setPaused(false, "user");
			else if (cmd === "RESTART") {
				gameBridge.resetInput();
				const nextConfig = gameBridge.getLaunchConfig() ?? this.launchConfig;
				this.scene.restart(nextConfig);
			}
		});
		this.unsubPlatform = platformBridge.subscribeState((state) => {
			if (!this.sceneActive || this.matchEnded) return;
			const shouldLock = state.isPlatformPaused || state.isAdPlaying || !state.isPageVisible;
			this.setPaused(shouldLock, "platform");
		});
		this.unsubSettings = gameBridge.onSettingsChange((nextSettings) => {
			if (!this.sceneActive) return;
			this.launchConfig = {
				...this.launchConfig,
				settings: nextSettings
			};
			soundFX.configure(nextSettings.soundEnabled, nextSettings.soundVolume, nextSettings.musicEnabled, nextSettings.musicVolume);
			const nextQuality = nextSettings.graphicsQuality ?? (nextSettings.lowDetailMode ? "low" : "high");
			this.effects.setGraphicsQuality(nextQuality);
		});
		window.addEventListener("blur", this.handleWindowBlur);
		if (typeof document !== "undefined") document.addEventListener("visibilitychange", this.handleVisibilityChange);
		const cleanupBridgeListeners = () => {
			this.sceneActive = false;
			soundFX.stopAllLoops();
			platformBridge.notifyGameplayStop();
			if (this.unsubCommand) {
				this.unsubCommand();
				this.unsubCommand = void 0;
			}
			if (this.unsubPlatform) {
				this.unsubPlatform();
				this.unsubPlatform = void 0;
			}
			if (this.unsubSettings) {
				this.unsubSettings();
				this.unsubSettings = void 0;
			}
			window.removeEventListener("blur", this.handleWindowBlur);
			if (typeof document !== "undefined") document.removeEventListener("visibilitychange", this.handleVisibilityChange);
			this.powerups?.clear();
			this.projectiles?.clearAll();
			this.input?.removeAllListeners();
			this.input?.keyboard?.removeAllKeys(true);
			this.time.paused = false;
			this.tweens.resumeAll();
			gameBridge.resetInput();
		};
		this.events.once(__webpack_exports__default.Scenes.Events.SHUTDOWN, cleanupBridgeListeners);
		this.events.once(__webpack_exports__default.Scenes.Events.DESTROY, cleanupBridgeListeners);
		if (!this.paused) platformBridge.notifyGameplayStart();
		platformBridge.trackEvent("match_started", {
			tank_id: this.launchConfig.tankId,
			arena_id: this.arena.id
		});
		soundFX.playCountdown(false);
		this.emitHudSnapshot();
	}
	drawArenaGround() {
		const w = this.arena.width;
		const h = this.arena.height;
		const g = this.add.graphics().setDepth(0);
		g.fillStyle(__webpack_exports__default.Display.Color.HexStringToColor(this.arena.groundColor).color, 1);
		g.fillRect(0, 0, w, h);
		g.lineStyle(1.5, __webpack_exports__default.Display.Color.HexStringToColor(this.arena.groundGridColor).color, .5);
		const step = 80;
		for (let x = step; x < w; x += step) g.lineBetween(x, 0, x, h);
		for (let y = step; y < h; y += step) g.lineBetween(0, y, w, y);
		if (this.arena.id === "training_grounds") {
			g.fillStyle(12101506, .45);
			g.fillRect(740, 340, 600, 520);
			g.lineStyle(3, 9404255, .65);
			g.strokeRect(740, 340, 600, 520);
			g.lineStyle(2.5, 9404255, .7);
			g.strokeCircle(w / 2, h / 2, 135);
			g.lineStyle(1.5, 14716454, .42);
			g.strokeCircle(w / 2, h / 2, 95);
		} else if (this.arena.id === "industrial_zone") {
			g.fillStyle(8160135, .42);
			g.fillRect(290, 250, 390, 700);
			g.fillRect(1400, 250, 390, 700);
			g.lineStyle(3, 15381256, .35);
			g.strokeRect(290, 250, 390, 700);
			g.strokeRect(1400, 250, 390, 700);
			g.fillStyle(7699584, .5);
			g.fillCircle(w / 2, h / 2, 150);
			g.lineStyle(3, 4937059, .75);
			g.strokeCircle(w / 2, h / 2, 150);
			g.lineStyle(2, 3718648, .32);
			g.strokeCircle(w / 2, h / 2, 118);
		} else if (this.arena.id === "wasteland") {
			for (const [px, py, pr, col, alpha] of [
				[
					360,
					240,
					140,
					12094301,
					.48
				],
				[
					1710,
					960,
					155,
					12094301,
					.48
				],
				[
					1040,
					600,
					195,
					11699029,
					.42
				],
				[
					560,
					600,
					115,
					10187337,
					.45
				],
				[
					1520,
					600,
					115,
					10187337,
					.45
				],
				[
					1420,
					240,
					120,
					13740412,
					.38
				],
				[
					660,
					950,
					130,
					13740412,
					.38
				]
			]) {
				g.fillStyle(col, alpha);
				g.fillCircle(px, py, pr);
			}
			g.lineStyle(2, 8149046, .42);
			for (const [x1, y1, x2, y2, x3, y3] of [
				[
					240,
					340,
					310,
					385,
					395,
					368
				],
				[
					1680,
					260,
					1755,
					315,
					1840,
					290
				],
				[
					890,
					410,
					945,
					455,
					1005,
					438
				],
				[
					1120,
					740,
					1185,
					795,
					1245,
					775
				],
				[
					290,
					860,
					365,
					915,
					430,
					895
				],
				[
					1640,
					850,
					1715,
					815,
					1790,
					845
				]
			]) {
				g.beginPath();
				g.moveTo(x1, y1);
				g.lineTo(x2, y2);
				g.lineTo(x3, y3);
				g.strokePath();
			}
			g.fillStyle(7228976, .38);
			for (let i = 0; i < 36; i++) {
				const px = 90 + i * 293 % (w - 180);
				const py = 90 + i * 197 % (h - 180);
				g.fillCircle(px, py, 3 + i % 3);
			}
		}
		g.lineStyle(18, __webpack_exports__default.Display.Color.HexStringToColor(this.arena.borderColor).color, 1);
		g.strokeRect(4, 4, w - 8, h - 8);
		g.lineStyle(3, 1447957, 1);
		g.strokeRect(12, 12, w - 24, h - 24);
	}
	setupInputs() {
		if (this.input.keyboard) {
			const keys = this.input.keyboard.addKeys({
				W: __webpack_exports__default.Input.Keyboard.KeyCodes.W,
				A: __webpack_exports__default.Input.Keyboard.KeyCodes.A,
				S: __webpack_exports__default.Input.Keyboard.KeyCodes.S,
				D: __webpack_exports__default.Input.Keyboard.KeyCodes.D,
				UP: __webpack_exports__default.Input.Keyboard.KeyCodes.UP,
				DOWN: __webpack_exports__default.Input.Keyboard.KeyCodes.DOWN,
				LEFT: __webpack_exports__default.Input.Keyboard.KeyCodes.LEFT,
				RIGHT: __webpack_exports__default.Input.Keyboard.KeyCodes.RIGHT,
				SPACE: __webpack_exports__default.Input.Keyboard.KeyCodes.SPACE,
				E: __webpack_exports__default.Input.Keyboard.KeyCodes.E,
				F: __webpack_exports__default.Input.Keyboard.KeyCodes.F,
				Q: __webpack_exports__default.Input.Keyboard.KeyCodes.Q,
				R: __webpack_exports__default.Input.Keyboard.KeyCodes.R,
				SHIFT: __webpack_exports__default.Input.Keyboard.KeyCodes.SHIFT,
				P: __webpack_exports__default.Input.Keyboard.KeyCodes.P,
				ESC: __webpack_exports__default.Input.Keyboard.KeyCodes.ESC
			});
			this.keys = keys;
			keys.P.on("down", () => this.setPaused(!this.pausedByUser, "user"));
			keys.ESC.on("down", () => this.setPaused(!this.pausedByUser, "user"));
			keys.E.on("down", () => {
				if (!this.paused && !this.matchEnded && this.prepRemainingSec <= 0) gameBridge.input.abilityPressed = true;
			});
			keys.SHIFT.on("down", () => {
				if (!this.paused && !this.matchEnded && this.prepRemainingSec <= 0) gameBridge.input.abilityPressed = true;
			});
			keys.R.on("down", () => {
				if (!this.paused && !this.matchEnded && this.prepRemainingSec <= 0) gameBridge.input.reloadPressed = true;
			});
			keys.F.on("down", () => {
				if (!this.paused && !this.matchEnded && this.prepRemainingSec <= 0) gameBridge.input.deployMinePressed = true;
			});
			keys.Q.on("down", () => {
				if (!this.paused && !this.matchEnded && this.prepRemainingSec <= 0) gameBridge.input.deployMinePressed = true;
			});
		}
		this.input.on("pointermove", (pointer) => {
			if (pointer.wasTouch) return;
			this.mouseScreenX = pointer.x;
			this.mouseScreenY = pointer.y;
			if (this.prepRemainingSec > 0) return;
			gameBridge.input.mouseWorldX = pointer.worldX;
			gameBridge.input.mouseWorldY = pointer.worldY;
			gameBridge.input.mouseAimActive = true;
		});
		this.input.on("pointerdown", (pointer) => {
			if (pointer.wasTouch) return;
			this.mouseScreenX = pointer.x;
			this.mouseScreenY = pointer.y;
			if (this.prepRemainingSec > 0) return;
			gameBridge.input.mouseWorldX = pointer.worldX;
			gameBridge.input.mouseWorldY = pointer.worldY;
			gameBridge.input.mouseAimActive = true;
			gameBridge.input.firePressed = true;
			gameBridge.input.firing = true;
		});
		this.input.on("pointerup", (pointer) => {
			if (pointer.wasTouch) return;
			gameBridge.input.firing = false;
		});
		this.input.on("pointerupoutside", (pointer) => {
			if (pointer.wasTouch) return;
			gameBridge.input.firing = false;
		});
	}
	setPaused(value, source = "user") {
		if (this.matchEnded) return;
		if (source === "user") this.pausedByUser = value;
		else this.pausedByPlatform = value;
		const nextPaused = this.pausedByUser || this.pausedByPlatform;
		if (this.paused === nextPaused) return;
		this.paused = nextPaused;
		this.time.paused = nextPaused;
		if (nextPaused) {
			this.tweens.pauseAll();
			gameBridge.resetInput();
			soundFX.updateMovementAudio(0, false);
			platformBridge.notifyGameplayStop();
		} else {
			this.tweens.resumeAll();
			platformBridge.notifyGameplayStart();
		}
		this.emitHudSnapshot();
	}
	update(_time, deltaMs) {
		if (!this.sceneActive || this.paused || this.matchEnded) return;
		const dt = Math.min(deltaMs / 1e3, .05);
		if (this.prepRemainingSec > 0) {
			this.prepRemainingSec = Math.max(0, this.prepRemainingSec - dt);
			if (this.prepRemainingSec <= .001) this.prepRemainingSec = 0;
			gameBridge.input.firing = false;
			gameBridge.input.firePressed = false;
			gameBridge.input.abilityPressed = false;
			gameBridge.input.reloadPressed = false;
			gameBridge.input.deployMinePressed = false;
			for (const tank of this.tanks) tank.updateTimersAndVisuals(0, false, true);
			if (this.prepRemainingSec > 0) {
				const currentStep = Math.ceil(this.prepRemainingSec);
				if (currentStep !== this.lastPrepStep) {
					this.lastPrepStep = currentStep;
					soundFX.playCountdown(false);
					this.emitHudSnapshot();
				}
				return;
			}
			this.lastPrepStep = 0;
			this.goBannerTimer = .75;
			for (const tank of this.tanks) if (tank.alive) tank.updateTimersAndVisuals(0, false, false);
			soundFX.playCountdown(true);
			this.effects.spawnRing(this.playerTank.x, this.playerTank.y, 58, 14716454, .35);
			if (!this.matchStartEmitted) {
				this.matchStartEmitted = true;
				gameBridge.emitGameplayEvent({
					eventId: `${this.matchId}:started`,
					type: "match_started",
					matchId: this.matchId,
					tankId: this.playerTank.definition.id,
					arenaId: this.arena.id
				});
			}
			this.emitHudSnapshot();
		}
		if (this.goBannerTimer > 0) {
			this.goBannerTimer = Math.max(0, this.goBannerTimer - dt);
			if (this.goBannerTimer === 0) this.emitHudSnapshot();
		}
		if (this.pendingDefeatTimer === null) {
			this.elapsedMatchSec += dt;
			this.matchTimeLeft = Math.max(0, this.matchTimeLeft - dt);
		}
		if (this.killFeedTimer > 0) {
			this.killFeedTimer -= dt;
			if (this.killFeedTimer <= 0) this.killFeedText = null;
		}
		if (this.recentPickupTimer > 0) {
			this.recentPickupTimer -= dt;
			if (this.recentPickupTimer <= 0) {
				this.recentPickupName = null;
				this.recentPickupColor = null;
			}
		}
		if (this.pendingDefeatTimer !== null) {
			this.pendingDefeatTimer -= dt;
			if (this.pendingDefeatTimer <= 0) {
				this.finishMatch("eliminated");
				return;
			}
		}
		this.updatePlayerTank(dt);
		const playerSpd = Math.hypot(this.playerTank.vx, this.playerTank.vy);
		const playerMaxSpd = Math.max(1, this.playerTank.getEffectiveMoveSpeed());
		soundFX.updateMovementAudio(playerSpd / playerMaxSpd, this.playerTank.alive);
		for (const tank of this.tanks) {
			if (tank.isPlayer || !tank.alive) continue;
			const ai = this.aiMap.get(tank.id);
			if (!ai) continue;
			const decision = ai.update(dt, tank, this.tanks, this.obstacles, this.powerups.getActivePowerups(), this.projectiles, this.arena.width, this.arena.height);
			tank.updateMovement(dt, decision.moveX, decision.moveY, this.obstacles, this.arena.width, this.arena.height, this.effects);
			tank.aimTurretToward(decision.aimAngle, dt);
			if (decision.shouldFire) fireTankWeapon(tank, this.projectiles, this.effects);
			if (decision.shouldUseAbility) activateTankAbility(tank, this.tanks, this.projectiles, this.effects, this.handleTankEliminated, {
				targetX: decision.abilityTargetX,
				targetY: decision.abilityTargetY,
				arenaWidth: this.arena.width,
				arenaHeight: this.arena.height
			});
			if (decision.shouldDeployMine) deployTankMine(tank, this.tanks, this.obstacles, this.projectiles, this.effects, this.arena.width, this.arena.height);
		}
		this.resolveTankPairCollisions();
		this.projectiles.update(dt, this.tanks, this.obstacles, this.arena.width, this.arena.height, this.effects, this.handleBarrelExplosion, this.handleTankEliminated, this.handleObstacleDestroyed);
		const isLowQuality = this.launchConfig.settings.graphicsQuality === "low" || this.launchConfig.settings.lowDetailMode;
		for (const obs of this.obstacles) {
			if (!obs.alive) continue;
			obs.updateHitFlash(dt);
			if (!isLowQuality && (obs.type === "water" || obs.type === "bush")) obs.updateAmbient(this.elapsedMatchSec);
			if (!obs.isPriming) continue;
			const blast = obs.updateFuse(dt, this.effects);
			if (blast) {
				this.handleObstacleDestroyed(obs, blast.attackerId);
				this.handleBarrelExplosion(blast.x, blast.y, blast.attackerId);
			}
		}
		this.powerups.update(dt, this.arena.width, this.arena.height, this.tanks, this.obstacles, this.arena.spawns, this.effects, (collector, id, result) => {
			if (collector.isPlayer && result.applied) {
				const def = POWERUP_DEFINITIONS[id];
				this.recentPickupName = id === "repair_kit" && result.healedAmount > 0 ? `${def.name} (+${result.healedAmount} HP)` : id === "mine_kit" ? `${def.name} (+${result.minesAdded})` : def.name;
				this.recentPickupColor = def.color;
				this.recentPickupTimer = 2.2;
				gameBridge.emitGameplayEvent({
					eventId: `${this.matchId}:pwr:${++this.eventSeq}`,
					type: "powerup_collected",
					matchId: this.matchId,
					powerupId: id
				});
				this.emitHudSnapshot();
			}
		});
		const playerRadar = this.prepRemainingSec <= 0 && this.playerTank.alive && this.playerTank.hasBuff("radar");
		const playerRadarRadius = playerRadar ? this.playerTank.effectsManager.getRadarRadius() : 0;
		for (const tank of this.tanks) tank.updateTimersAndVisuals(dt, playerRadar, false, this.effects, this.playerTank.x, this.playerTank.y, playerRadarRadius);
		this.effects.update(dt);
		let aliveCount = 0;
		for (const t of this.tanks) if (t.alive) aliveCount += 1;
		if (this.playerTank.alive && aliveCount === 1) {
			this.finishMatch("last_standing");
			return;
		}
		if (this.matchTimeLeft <= 0) {
			this.finishMatch(this.playerTank.alive ? "time_highest_hp" : "eliminated");
			return;
		}
		this.hudPushTimer -= dt;
		if (this.hudPushTimer <= 0) {
			this.hudPushTimer = .1;
			this.emitHudSnapshot();
		}
	}
	updatePlayerTank(dt) {
		if (!this.playerTank.alive) return;
		const inp = gameBridge.input;
		let mx = inp.moveX;
		let my = inp.moveY;
		if (this.keys) {
			let kx = 0;
			let ky = 0;
			if (this.keys.A.isDown || this.keys.LEFT.isDown) kx -= 1;
			if (this.keys.D.isDown || this.keys.RIGHT.isDown) kx += 1;
			if (this.keys.W.isDown || this.keys.UP.isDown) ky -= 1;
			if (this.keys.S.isDown || this.keys.DOWN.isDown) ky += 1;
			if (kx !== 0 || ky !== 0) {
				const km = Math.hypot(kx, ky);
				mx = kx / km;
				my = ky / km;
			}
		}
		this.playerTank.updateMovement(dt, mx, my, this.obstacles, this.arena.width, this.arena.height, this.effects);
		this.manualAimHoldTimer = Math.max(0, this.manualAimHoldTimer - dt);
		const spaceDown = Boolean(this.keys?.SPACE.isDown);
		const spaceJustDown = Boolean(this.keys && __webpack_exports__default.Input.Keyboard.JustDown(this.keys.SPACE));
		const hasFireInput = inp.firing || inp.firePressed || spaceDown || spaceJustDown;
		const sensitivity = this.launchConfig.settings.controlSensitivity ?? 1;
		let shouldAutoFire = false;
		const maxRange = this.playerTank.getEffectiveProjectileRange();
		if (inp.aimActive && Math.hypot(inp.aimX, inp.aimY) > .15) {
			inp.mouseAimActive = false;
			const aimMag = Math.min(1, Math.hypot(inp.aimX, inp.aimY));
			const aimAngle = Math.atan2(inp.aimY, inp.aimX);
			this.playerTank.aimTurretToward(aimAngle, dt, sensitivity);
			this.lastAimDistance = __webpack_exports__default.Math.Linear(140, maxRange * .92, (aimMag - .15) / .85);
			this.manualAimHoldTimer = 2.5;
			if (this.launchConfig.settings.autoFireOnAim && aimMag > .72) shouldAutoFire = true;
		} else if (inp.mouseAimActive) {
			const worldPt = this.cameras.main.getWorldPoint(this.mouseScreenX, this.mouseScreenY);
			const dx = worldPt.x - this.playerTank.x;
			const dy = worldPt.y - this.playerTank.y;
			const aimAngle = Math.atan2(dy, dx);
			this.playerTank.aimTurretToward(aimAngle, dt, sensitivity);
			this.lastAimDistance = __webpack_exports__default.Math.Clamp(Math.hypot(dx, dy), 95, maxRange);
			this.manualAimHoldTimer = 2.5;
		} else if (hasFireInput) this.manualAimHoldTimer = Math.max(this.manualAimHoldTimer, 1.5);
		else if (this.manualAimHoldTimer <= 0 && Math.hypot(mx, my) > .2) this.playerTank.aimTurretToward(Math.atan2(my, mx), dt * .55, sensitivity);
		const useMouseForBarrage = !inp.aimActive && inp.mouseAimActive;
		const barrageTarget = this.computeArtilleryTargetPoint(useMouseForBarrage);
		const showReticle = this.playerTank.definition.id === "artillery" && this.prepRemainingSec <= 0 && this.playerTank.abilityCooldownTimer <= 0 && this.playerTank.abilityActiveTimer <= 0;
		this.playerTank.updateBarrageReticle(showReticle, barrageTarget.x, barrageTarget.y);
		this.emptyFeedbackTimer = Math.max(0, this.emptyFeedbackTimer - dt);
		if (inp.reloadPressed) {
			inp.reloadPressed = false;
			if (this.playerTank.startReload()) {
				soundFX.playReloadStart();
				this.effects.spawnFloatingLabel(this.playerTank.x, this.playerTank.y, "RELOADING", "#FACC15");
				this.emitHudSnapshot();
			}
		}
		if (hasFireInput || shouldAutoFire) {
			const fireStatus = fireTankWeapon(this.playerTank, this.projectiles, this.effects);
			if (fireStatus === "fired") triggerHaptic(this.launchConfig.settings.vibrationEnabled, 12);
			else if ((fireStatus === "empty" || fireStatus === "reloading") && (inp.firePressed || spaceJustDown || this.emptyFeedbackTimer <= 0)) {
				this.emptyFeedbackTimer = .55;
				soundFX.playEmptyClick();
				if (fireStatus === "reloading") this.effects.spawnFloatingLabel(this.playerTank.x, this.playerTank.y, "RELOADING...", "#FACC15");
				else this.effects.spawnFloatingLabel(this.playerTank.x, this.playerTank.y, "EMPTY!", "#EF4444");
			}
		}
		inp.firePressed = false;
		if (inp.abilityPressed) {
			inp.abilityPressed = false;
			if (activateTankAbility(this.playerTank, this.tanks, this.projectiles, this.effects, this.handleTankEliminated, {
				targetX: barrageTarget.x,
				targetY: barrageTarget.y,
				arenaWidth: this.arena.width,
				arenaHeight: this.arena.height
			})) {
				triggerHaptic(this.launchConfig.settings.vibrationEnabled, 22);
				gameBridge.emitGameplayEvent({
					eventId: `${this.matchId}:ability:${++this.eventSeq}`,
					type: "ability_activated",
					matchId: this.matchId,
					tankId: this.playerTank.definition.id
				});
				this.emitHudSnapshot();
			}
		}
		if (inp.deployMinePressed) {
			inp.deployMinePressed = false;
			if (deployTankMine(this.playerTank, this.tanks, this.obstacles, this.projectiles, this.effects, this.arena.width, this.arena.height)) this.emitHudSnapshot();
		}
	}
	computeArtilleryTargetPoint(useMouseWorld) {
		const maxRange = this.playerTank.getEffectiveProjectileRange();
		let rawX;
		let rawY;
		if (useMouseWorld) {
			const worldPt = this.cameras.main.getWorldPoint(this.mouseScreenX, this.mouseScreenY);
			const dx = worldPt.x - this.playerTank.x;
			const dy = worldPt.y - this.playerTank.y;
			const dist = Math.hypot(dx, dy);
			const clampedDist = __webpack_exports__default.Math.Clamp(dist, 95, maxRange);
			const ang = dist > .01 ? Math.atan2(dy, dx) : this.playerTank.turretAngle;
			rawX = this.playerTank.x + Math.cos(ang) * clampedDist;
			rawY = this.playerTank.y + Math.sin(ang) * clampedDist;
		} else {
			const clampedDist = __webpack_exports__default.Math.Clamp(this.lastAimDistance, 110, maxRange);
			rawX = this.playerTank.x + Math.cos(this.playerTank.turretAngle) * clampedDist;
			rawY = this.playerTank.y + Math.sin(this.playerTank.turretAngle) * clampedDist;
		}
		return {
			x: __webpack_exports__default.Math.Clamp(rawX, 32, this.arena.width - 32),
			y: __webpack_exports__default.Math.Clamp(rawY, 32, this.arena.height - 32)
		};
	}
	resolveTankPairCollisions() {
		for (let i = 0; i < this.tanks.length; i++) {
			const a = this.tanks[i];
			if (!a.alive) continue;
			for (let j = i + 1; j < this.tanks.length; j++) {
				const b = this.tanks[j];
				if (!b.alive) continue;
				const dx = b.x - a.x;
				const dy = b.y - a.y;
				const minDist = a.radius + b.radius;
				const dist = Math.hypot(dx, dy);
				if (dist < minDist && dist > .001) {
					const push = (minDist - dist) * .5;
					const nx = dx / dist;
					const ny = dy / dist;
					a.x -= nx * push;
					a.y -= ny * push;
					b.x += nx * push;
					b.y += ny * push;
				}
			}
			a.resolveBoundsAndObstacles(this.obstacles, this.arena.width, this.arena.height);
		}
	}
	finishMatch(trigger) {
		if (this.matchEnded) return;
		this.matchEnded = true;
		gameBridge.resetInput();
		soundFX.stopAllLoops();
		platformBridge.notifyGameplayStop();
		this.powerups.clear();
		this.projectiles.clearAll();
		for (const t of this.tanks) t.clearTemporaryEffects();
		this.recentPickupName = null;
		this.recentPickupColor = null;
		this.recentPickupTimer = 0;
		const ranked = [...this.tanks].sort((a, b) => {
			if (a.alive !== b.alive) return a.alive ? -1 : 1;
			if (a.alive && b.alive) {
				if (b.hp !== a.hp) return b.hp - a.hp;
				return b.eliminations - a.eliminations;
			}
			return (a.eliminatedAtRank ?? 8) - (b.eliminatedAtRank ?? 8);
		});
		const placement = ranked.findIndex((t) => t.isPlayer) + 1;
		const victory = placement === 1;
		const winnerName = ranked[0]?.displayName ?? "Unknown";
		let reason = trigger;
		if (trigger === "time_highest_hp" && !victory) reason = "time_outscored";
		const scrapBreakdown = calculateMatchScrapBreakdown({
			victory,
			placement,
			eliminations: this.playerTank.eliminations,
			damageDealt: this.playerTank.damageDealt
		});
		const scrapEarned = scrapBreakdown.totalScrap;
		soundFX.playMatchEnd(victory);
		if (victory) platformBridge.notifyHappyTime();
		const totalDuration = this.launchConfig.settings?.matchDurationSec || 150;
		const rawSurvival = this.playerEliminatedAtSec ?? this.elapsedMatchSec;
		const survivalSec = Math.min(totalDuration, Math.max(0, Math.floor(rawSurvival)));
		const result = {
			matchId: this.matchId || `match_${Date.now()}`,
			victory,
			reason,
			placement,
			totalTanks: this.tanks.length,
			eliminations: this.playerTank.eliminations,
			damageDealt: this.playerTank.damageDealt,
			survivalSec,
			scrapEarned,
			scrapBreakdown,
			arenaId: this.arena.id,
			tankId: this.playerTank.definition.id,
			winnerName
		};
		gameBridge.emitGameplayEvent({
			eventId: `${this.matchId}:completed`,
			type: "match_completed",
			matchId: result.matchId,
			tankId: result.tankId,
			arenaId: result.arenaId,
			placement: result.placement,
			survivalSec: result.survivalSec
		});
		if (result.victory) gameBridge.emitGameplayEvent({
			eventId: `${this.matchId}:victory`,
			type: "match_victory",
			matchId: result.matchId,
			tankId: result.tankId,
			arenaId: result.arenaId
		});
		gameBridge.emitMatchEnd(result);
	}
	emitHudSnapshot() {
		if (!this.sceneActive || !this.playerTank) return;
		const aliveCount = this.tanks.filter((t) => t.alive).length;
		const activeBuffs = this.playerTank.effectsManager.toHudSnapshots();
		const isPreparing = this.prepRemainingSec > 0;
		const prepLabel = isPreparing ? String(Math.max(1, Math.ceil(this.prepRemainingSec))) : this.goBannerTimer > 0 ? "GO!" : null;
		const radarActive = !isPreparing && this.playerTank.alive && this.playerTank.hasBuff("radar");
		const radarRemainingSec = radarActive ? this.playerTank.effectsManager.getRemainingSec("radar") : 0;
		const radarRadius = radarActive ? this.playerTank.effectsManager.getRadarRadius() : 0;
		let radarDetectedCount = 0;
		if (radarActive && radarRadius > 0) for (const t of this.tanks) {
			if (!t.alive || t.isPlayer) continue;
			if (Math.hypot(t.x - this.playerTank.x, t.y - this.playerTank.y) <= radarRadius) radarDetectedCount += 1;
		}
		const snapshot = {
			tankId: this.playerTank.definition.id,
			tankName: this.playerTank.definition.name,
			hp: Math.ceil(this.playerTank.hp),
			maxHp: this.playerTank.maxHp,
			shieldHp: Math.ceil(this.playerTank.shieldHp),
			ammo: this.playerTank.ammo,
			maxAmmo: this.playerTank.maxAmmo,
			isReloading: this.playerTank.isReloading,
			reloadRemainingSec: this.playerTank.magazineReloadTimer,
			reloadTotalSec: this.playerTank.magazineReloadTotal || this.playerTank.getEffectiveReloadDurationSec(),
			aliveCount,
			totalTanks: this.tanks.length,
			eliminations: this.playerTank.eliminations,
			timeRemainingSec: Math.ceil(this.matchTimeLeft),
			abilityCooldownSec: this.playerTank.abilityCooldownTimer,
			abilityTotalCooldownSec: this.playerTank.definition.activeAbility.cooldownSec,
			abilityActiveSec: this.playerTank.abilityActiveTimer,
			abilityName: this.playerTank.definition.activeAbility.name,
			activeBuffs,
			mineCharges: this.playerTank.mineCharges,
			maxMineCharges: MINE_SYSTEM_CONFIG.maxCarriedCharges,
			activeMineCount: this.projectiles.getActiveMineCount(this.playerTank.id),
			isConcealed: this.playerTank.concealed,
			isPhased: this.playerTank.phaseCloaked,
			isSlowed: this.playerTank.isSlowed,
			slowRemainingSec: this.playerTank.slowRemainingSec,
			radarActive,
			radarRemainingSec,
			radarDetectedCount,
			recentPickupName: this.recentPickupName,
			recentPickupColor: this.recentPickupColor,
			isPaused: this.paused,
			isPreparing,
			prepLabel,
			killFeedText: this.killFeedText
		};
		gameBridge.emitHudUpdate(snapshot);
	}
};
// src/game/PhaserGameHost.tsx
var import_jsx_runtime = require_jsx_runtime();
var VIEWPORT_WIDTH = 1440;
var VIEWPORT_HEIGHT = 840;
function PhaserGameHost({ launchConfig, matchInstanceKey }) {
	const containerRef = (0, import_react.useRef)(null);
	const gameRef = (0, import_react.useRef)(null);
	const launchConfigRef = (0, import_react.useRef)(launchConfig);
	launchConfigRef.current = launchConfig;
	(0, import_react.useEffect)(() => {
		const container = containerRef.current;
		if (!container) return;
		const initialConfig = launchConfigRef.current;
		gameBridge.setLaunchConfig(initialConfig);
		const config = {
			type: __webpack_exports__default.AUTO,
			parent: container,
			width: VIEWPORT_WIDTH,
			height: VIEWPORT_HEIGHT,
			backgroundColor: "#141714",
			antialias: true,
			roundPixels: false,
			scale: {
				mode: __webpack_exports__default.Scale.FIT,
				autoCenter: __webpack_exports__default.Scale.CENTER_BOTH,
				width: VIEWPORT_WIDTH,
				height: VIEWPORT_HEIGHT
			},
			scene: [],
			callbacks: { postBoot: (bootedGame) => {
				bootedGame.scene.add("ArenaScene", ArenaScene, true, initialConfig);
			} }
		};
		const game = new __webpack_exports__default.Game(config);
		gameRef.current = game;
		const handleResize = () => {
			game.scale.refresh();
		};
		const resizeObserver = new ResizeObserver(() => {
			game.scale.refresh();
		});
		resizeObserver.observe(container);
		window.addEventListener("resize", handleResize);
		window.addEventListener("orientationchange", handleResize);
		document.addEventListener("fullscreenchange", handleResize);
		screen.orientation?.addEventListener?.("change", handleResize);
		return () => {
			resizeObserver.disconnect();
			window.removeEventListener("resize", handleResize);
			window.removeEventListener("orientationchange", handleResize);
			document.removeEventListener("fullscreenchange", handleResize);
			screen.orientation?.removeEventListener?.("change", handleResize);
			gameBridge.resetInput();
			gameBridge.clearLastHudSnapshot();
			game.destroy(true);
			gameRef.current = null;
		};
	}, [
		matchInstanceKey,
		launchConfig.tankId,
		launchConfig.arenaId
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		ref: containerRef,
		className: "w-full h-full flex items-center justify-center bg-[#141714] overflow-hidden"
	});
}
// src/components/ArenaPreviewSvg.tsx
var OBSTACLE_COLOR = {
	steel: "#5A626B",
	brick: "#9A4E38",
	crate: "#A8743B",
	water: "#3282B8",
	bush: "#436B33",
	barrel: "#D13B2E"
};
var OBSTACLE_STROKE = {
	steel: "#8B95A1",
	brick: "#C96D52",
	crate: "#D29B59",
	water: "#63B3ED",
	bush: "#689A50",
	barrel: "#FCA5A5"
};
function ArenaPreviewSvg({ arena, className = "" }) {
	const { width, height, groundColor, groundGridColor, borderColor, obstacles, spawns, id } = arena;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: `0 0 ${width} ${height}`,
		role: "img",
		"aria-label": `${arena.name} tactical arena preview`,
		className: `w-full aspect-[2080/1200] rounded-lg border border-[#F3EFE6]/15 overflow-hidden bg-[#141714] ${className}`,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: 0,
				y: 0,
				width,
				height,
				fill: groundColor
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", {
				stroke: groundGridColor,
				strokeWidth: 4,
				opacity: .35,
				children: [[
					400,
					800,
					1200,
					1600
				].map((x) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
					x1: x,
					y1: 0,
					x2: x,
					y2: height
				}, `gx-${x}`)), [
					300,
					600,
					900
				].map((y) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
					x1: 0,
					y1: y,
					x2: width,
					y2: y
				}, `gy-${y}`))]
			}),
			id === "training_grounds" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: 720,
				y: 340,
				width: 640,
				height: 520,
				rx: 16,
				fill: "#AE9D78",
				opacity: .45
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: width / 2,
				cy: height / 2,
				r: 235,
				fill: "none",
				stroke: "#DFD1B0",
				strokeWidth: 6,
				opacity: .45
			})] }),
			id === "industrial_zone" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
					x: 315,
					y: 260,
					width: 350,
					height: 680,
					fill: "#7B8287",
					opacity: .42
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
					x: 1415,
					y: 260,
					width: 350,
					height: 680,
					fill: "#7B8287",
					opacity: .42
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
					x: 315,
					y: 260,
					width: 350,
					height: 680,
					fill: "none",
					stroke: "#E08E26",
					strokeWidth: 8,
					opacity: .45
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
					x: 1415,
					y: 260,
					width: 350,
					height: 680,
					fill: "none",
					stroke: "#E08E26",
					strokeWidth: 8,
					opacity: .45
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: width / 2,
					cy: height / 2,
					r: 180,
					fill: "none",
					stroke: "#D68624",
					strokeWidth: 6,
					opacity: .4
				})
			] }),
			id === "wasteland" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
					cx: 540,
					cy: 590,
					rx: 270,
					ry: 170,
					fill: "#9C7348",
					opacity: .38
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
					cx: 1540,
					cy: 590,
					rx: 270,
					ry: 170,
					fill: "#9C7348",
					opacity: .38
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
					cx: 1040,
					cy: 310,
					rx: 300,
					ry: 110,
					fill: "#D5AB7B",
					opacity: .35
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
					cx: 1040,
					cy: 890,
					rx: 300,
					ry: 110,
					fill: "#D5AB7B",
					opacity: .35
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: 12,
				y: 12,
				width: width - 24,
				height: height - 24,
				fill: "none",
				stroke: borderColor,
				strokeWidth: 24
			}),
			obstacles.map((obs, idx) => {
				if (obs.type === "barrel") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: obs.x,
					cy: obs.y,
					r: obs.w * .52,
					fill: OBSTACLE_COLOR.barrel,
					stroke: OBSTACLE_STROKE.barrel,
					strokeWidth: 5
				}, `obs-${idx}`);
				if (obs.type === "bush") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
					cx: obs.x,
					cy: obs.y,
					rx: obs.w * .5,
					ry: obs.h * .5,
					fill: OBSTACLE_COLOR.bush,
					stroke: OBSTACLE_STROKE.bush,
					strokeWidth: 4,
					opacity: .85
				}, `obs-${idx}`);
				return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
					x: obs.x - obs.w / 2,
					y: obs.y - obs.h / 2,
					width: obs.w,
					height: obs.h,
					rx: obs.type === "water" ? 14 : 5,
					fill: OBSTACLE_COLOR[obs.type],
					stroke: OBSTACLE_STROKE[obs.type],
					strokeWidth: obs.type === "steel" ? 6 : 4
				}, `obs-${idx}`);
			}),
			spawns.map((sp, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("g", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: sp.x,
				cy: sp.y,
				r: 24,
				fill: idx === 0 ? "#E08E26" : "#1E221D",
				stroke: "#F3EFE6",
				strokeWidth: 6
			}) }, `sp-${idx}`))
		]
	});
}
// src/ui/ArenaSelectionScreen.tsx
function ArenaSelectionScreen({ selectedArena, onSelectArena, onBack, onStartBattle }) {
	const activeArena = ARENA_DEFINITIONS[selectedArena] || ARENA_DEFINITIONS.training_grounds;
	const destructibleCount = activeArena.obstacles.filter((o) => o.type === "brick" || o.type === "crate").length;
	const steelCount = activeArena.obstacles.filter((o) => o.type === "steel").length;
	const barrelCount = activeArena.obstacles.filter((o) => o.type === "barrel").length;
	const bushCount = activeArena.obstacles.filter((o) => o.type === "bush").length;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "w-full h-full overflow-y-auto bg-[#141714] tactical-bg-grid text-[#F3EFE6] flex flex-col",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
			className: "w-full max-w-6xl mx-auto px-4 sm:px-7 py-3 flex items-center justify-between gap-3 border-b border-[#F3EFE6]/12 shrink-0 bg-[#141714]/80",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: onBack,
					className: "min-h-[44px] px-3.5 rounded-xl border border-[#F3EFE6]/20 bg-[#1E221D] flex items-center gap-1.5 text-sm font-semibold hover:bg-[#282D26] transition whitespace-nowrap",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "w-4 h-4" }), "Back"]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-2xl sm:text-3xl font-extrabold tracking-wide leading-none",
					children: "Arena Selection"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[11px] text-[#F3EFE6]/55 mt-0.5",
					children: "Choose your combat theatre · 8-Tank Free-For-All"
				})] })]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "hidden sm:inline-flex items-center gap-1.5 text-xs font-mono text-[#E08E26]",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Compass, { className: "w-4 h-4" }),
					"Selected: ",
					activeArena.name
				]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
			className: "screen-transition flex-1 w-full max-w-6xl mx-auto px-4 sm:px-7 py-3.5 sm:py-5 grid grid-cols-1 landscape:grid-cols-12 lg:grid-cols-12 gap-4 sm:gap-5 items-stretch",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "landscape:col-span-5 lg:col-span-5 flex flex-col gap-2.5 sm:gap-3",
				children: ARENA_LIST.map((arena) => {
					const selected = arena.id === activeArena.id;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => onSelectArena(arena.id),
						"aria-pressed": selected,
						className: `text-left rounded-2xl p-3.5 sm:p-4 border transition flex items-center gap-3.5 ${selected ? "bg-[#252B23] border-[#E08E26] shadow-lg" : "bg-[#1B1F1A]/95 border-[#F3EFE6]/12 hover:border-[#F3EFE6]/32"}`,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "w-24 sm:w-28 shrink-0",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArenaPreviewSvg, {
								arena,
								className: "rounded-lg"
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0 flex-1",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-[10px] font-mono uppercase tracking-wider font-semibold",
										style: { color: arena.themeAccent },
										children: arena.subtitle
									}), selected && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "inline-flex items-center gap-1 rounded bg-[#22C55E] text-[#141714] px-2 py-0.5 text-[10px] font-bold uppercase",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "w-3 h-3 stroke-[3]" }), "Selected"]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "font-display text-2xl font-extrabold text-[#F3EFE6] leading-tight mt-0.5 truncate",
									children: arena.name
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs text-[#F3EFE6]/70 mt-1 line-clamp-2 leading-snug",
									children: arena.identity
								})
							]
						})]
					}, arena.id);
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "landscape:col-span-7 lg:col-span-7 bg-[#1B1F1A]/95 border border-[#F3EFE6]/15 rounded-2xl p-4 sm:p-5 flex flex-col justify-between gap-3.5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-center justify-between gap-2 mb-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "text-xs font-mono uppercase tracking-wider font-semibold",
							style: { color: activeArena.themeAccent },
							children: [
								activeArena.subtitle,
								" · ",
								activeArena.identity
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display text-3xl font-extrabold text-[#F3EFE6] leading-none mt-0.5",
							children: activeArena.name
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "text-xs font-mono tabular-nums text-[#F3EFE6]/60",
							children: [
								activeArena.width,
								" × ",
								activeArena.height,
								" · 8 Spawns"
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArenaPreviewSvg, {
						arena: activeArena,
						className: "rounded-xl shadow-lg"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs sm:text-sm text-[#F3EFE6]/80 mt-3 leading-relaxed",
						children: activeArena.description
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid grid-cols-2 gap-2 mt-3 text-xs",
						children: activeArena.features.map((feature) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "bg-[#141714] border border-[#F3EFE6]/10 rounded-lg px-3 py-2 flex items-center gap-2 text-[#F3EFE6]/85",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shield, { className: "w-3.5 h-3.5 text-[#E08E26] shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "truncate",
								children: feature
							})]
						}, feature))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-4 gap-2 mt-3 pt-2.5 border-t border-[#F3EFE6]/10 text-center font-mono tabular-nums text-xs",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "font-bold text-[#F3EFE6]",
								children: steelCount
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-[10px] font-sans text-[#F3EFE6]/55",
								children: "Steel Cover"
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "font-bold text-[#F3EFE6]",
								children: destructibleCount
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-[10px] font-sans text-[#F3EFE6]/55",
								children: "Destructibles"
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "font-bold text-emerald-400",
								children: bushCount
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-[10px] font-sans text-[#F3EFE6]/55",
								children: "Brush Zones"
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "font-bold text-red-400",
								children: barrelCount
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-[10px] font-sans text-[#F3EFE6]/55",
								children: "Fuel Barrels"
							})] })
						]
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-3 pt-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: onBack,
						className: "min-h-[48px] px-5 rounded-xl bg-[#272D25] border border-[#F3EFE6]/20 text-sm font-semibold hover:bg-[#31382E] transition whitespace-nowrap",
						children: "Confirm & Back"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: onStartBattle,
						className: "min-h-[48px] flex-1 px-6 rounded-xl bg-[#E08E26] text-[#141714] font-display text-xl font-extrabold tracking-wide flex items-center justify-center gap-2 hover:bg-[#EE9B32] transition whitespace-nowrap",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "w-4 h-4 fill-current" }),
							"Play ",
							activeArena.name
						]
					})]
				})]
			})]
		})]
	});
}
// src/components/TouchJoystick.tsx
function TouchJoystick({ label, accentColor, size = 112, sensitivity = 1, onChange }) {
	const baseRef = (0, import_react.useRef)(null);
	const knobRef = (0, import_react.useRef)(null);
	const activePointerId = (0, import_react.useRef)(null);
	const dragBoundsRef = (0, import_react.useRef)(null);
	const onChangeRef = (0, import_react.useRef)(onChange);
	onChangeRef.current = onChange;
	const maxTravel = size * .34;
	(0, import_react.useEffect)(() => {
		return () => {
			activePointerId.current = null;
			dragBoundsRef.current = null;
			onChangeRef.current(0, 0, false);
		};
	}, []);
	const updateStick = (clientX, clientY) => {
		const base = baseRef.current;
		const knob = knobRef.current;
		if (!base || !knob) return;
		let bounds = dragBoundsRef.current;
		if (!bounds) {
			const rect = base.getBoundingClientRect();
			bounds = {
				cx: rect.left + rect.width / 2,
				cy: rect.top + rect.height / 2,
				maxTravel
			};
			dragBoundsRef.current = bounds;
		}
		let dx = clientX - bounds.cx;
		let dy = clientY - bounds.cy;
		const distSq = dx * dx + dy * dy;
		const travel = bounds.maxTravel;
		if (distSq > travel * travel && distSq > 1e-4) {
			const dist = Math.sqrt(distSq);
			dx = dx / dist * travel;
			dy = dy / dist * travel;
		}
		knob.style.transform = `translate3d(${dx}px, ${dy}px, 0)`;
		const rawNx = dx / travel;
		const rawNy = dy / travel;
		const rawMag = Math.hypot(rawNx, rawNy);
		if (rawMag > .001) {
			const scaledMag = Math.min(1, rawMag * sensitivity);
			onChangeRef.current(rawNx / rawMag * scaledMag, rawNy / rawMag * scaledMag, true);
		} else onChangeRef.current(0, 0, true);
	};
	const resetStick = () => {
		activePointerId.current = null;
		dragBoundsRef.current = null;
		if (knobRef.current) {
			knobRef.current.style.transition = "";
			knobRef.current.style.transform = "translate3d(0px, 0px, 0)";
		}
		onChangeRef.current(0, 0, false);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		ref: baseRef,
		role: "application",
		"aria-label": label,
		className: "touch-none-game relative rounded-full border-2 border-[#F3EFE6]/35 bg-[#141714]/65 backdrop-blur-xs flex items-center justify-center shadow-lg select-none",
		style: {
			width: size,
			height: size
		},
		onPointerDown: (e) => {
			e.preventDefault();
			e.stopPropagation();
			if (activePointerId.current !== null) return;
			activePointerId.current = e.pointerId;
			const rect = e.currentTarget.getBoundingClientRect();
			dragBoundsRef.current = {
				cx: rect.left + rect.width / 2,
				cy: rect.top + rect.height / 2,
				maxTravel
			};
			if (knobRef.current) knobRef.current.style.transition = "none";
			try {
				e.currentTarget.setPointerCapture(e.pointerId);
			} catch {}
			updateStick(e.clientX, e.clientY);
		},
		onPointerMove: (e) => {
			if (activePointerId.current !== e.pointerId) return;
			e.preventDefault();
			e.stopPropagation();
			updateStick(e.clientX, e.clientY);
		},
		onPointerUp: (e) => {
			if (activePointerId.current !== e.pointerId) return;
			e.preventDefault();
			e.stopPropagation();
			try {
				if (e.currentTarget.hasPointerCapture(e.pointerId)) e.currentTarget.releasePointerCapture(e.pointerId);
			} catch {}
			resetStick();
		},
		onPointerCancel: (e) => {
			if (activePointerId.current !== e.pointerId) return;
			e.stopPropagation();
			resetStick();
		},
		onLostPointerCapture: (e) => {
			if (activePointerId.current !== e.pointerId) return;
			resetStick();
		},
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "pointer-events-none absolute inset-3 rounded-full border border-[#F3EFE6]/15" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "pointer-events-none absolute bottom-1.5 text-[10px] font-semibold tracking-wider uppercase text-[#F3EFE6]/55",
				children: label
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				ref: knobRef,
				className: "pointer-events-none rounded-full border-2 border-[#141714] shadow-md transition-transform duration-75 will-change-transform",
				style: {
					width: size * .42,
					height: size * .42,
					backgroundColor: accentColor
				}
			})
		]
	});
}
// src/utils/orientation.ts
function readState() {
	if (typeof window === "undefined") return {
		width: 1280,
		height: 720,
		isLandscape: true,
		isPortrait: false,
		isCompactLandscape: false,
		isTouchDevice: false,
		isFullscreen: false,
		canFullscreen: false
	};
	const width = window.innerWidth;
	const height = window.innerHeight;
	const isLandscape = width >= height;
	return {
		width,
		height,
		isLandscape,
		isPortrait: height > width,
		isCompactLandscape: isLandscape && height <= 500,
		isTouchDevice: "ontouchstart" in window || navigator.maxTouchPoints > 0,
		isFullscreen: Boolean(document.fullscreenElement),
		canFullscreen: Boolean(document.fullscreenEnabled || document.documentElement.requestFullscreen)
	};
}
function useViewportOrientation() {
	const [state, setState] = (0, import_react.useState)(() => readState());
	(0, import_react.useEffect)(() => {
		const update = () => setState(readState());
		window.addEventListener("resize", update);
		window.addEventListener("orientationchange", update);
		document.addEventListener("fullscreenchange", update);
		screen.orientation?.addEventListener?.("change", update);
		return () => {
			window.removeEventListener("resize", update);
			window.removeEventListener("orientationchange", update);
			document.removeEventListener("fullscreenchange", update);
			screen.orientation?.removeEventListener?.("change", update);
		};
	}, []);
	return state;
}
async function enterLandscapeFullscreen() {
	try {
		const el = document.documentElement;
		if (!document.fullscreenElement && el.requestFullscreen) await el.requestFullscreen();
		const orientation = screen.orientation;
		if (orientation && typeof orientation.lock === "function") await orientation.lock("landscape").catch(() => {});
		return true;
	} catch {
		return false;
	}
}
async function exitLandscapeFullscreen() {
	try {
		const orientation = screen.orientation;
		if (orientation && typeof orientation.unlock === "function") orientation.unlock();
		if (document.fullscreenElement && document.exitFullscreen) await document.exitFullscreen();
	} catch {}
}
// src/ui/GameHUD.tsx
function createInitialHud(tankId = "assault") {
	const def = TANK_DEFINITIONS[tankId] || TANK_DEFINITIONS.assault;
	const maxHp = getEffectiveTankMaxHp(def);
	return {
		tankId: def.id,
		tankName: def.name,
		hp: maxHp,
		maxHp,
		shieldHp: 0,
		ammo: def.stats.magazineCapacity,
		maxAmmo: def.stats.magazineCapacity,
		isReloading: false,
		reloadRemainingSec: 0,
		reloadTotalSec: getEffectiveTankReloadSec(def),
		aliveCount: 8,
		totalTanks: 8,
		eliminations: 0,
		timeRemainingSec: 150,
		abilityCooldownSec: 0,
		abilityTotalCooldownSec: def.activeAbility.cooldownSec,
		abilityActiveSec: 0,
		abilityName: def.activeAbility.name,
		activeBuffs: [],
		mineCharges: 0,
		maxMineCharges: MINE_SYSTEM_CONFIG.maxCarriedCharges,
		activeMineCount: 0,
		isConcealed: false,
		isPhased: false,
		isSlowed: false,
		slowRemainingSec: 0,
		radarActive: false,
		radarRemainingSec: 0,
		radarDetectedCount: 0,
		recentPickupName: null,
		recentPickupColor: null,
		isPaused: false,
		isPreparing: true,
		prepLabel: "3",
		killFeedText: null
	};
}
function formatTime(totalSec) {
	return `${Math.floor(totalSec / 60)}:${(totalSec % 60).toString().padStart(2, "0")}`;
}
function GameHUD({ settings, selectedTankId = "assault", onToggleSound, onToggleMusic, onExitToMenu, onRestartMatch }) {
	const [hud, setHud] = (0, import_react.useState)(() => {
		const snap = gameBridge.getLastHudSnapshot();
		return snap && snap.tankId === selectedTankId ? snap : createInitialHud(selectedTankId);
	});
	const { width: viewportWidth, isTouchDevice, isCompactLandscape, isFullscreen, canFullscreen } = useViewportOrientation();
	(0, import_react.useEffect)(() => {
		const snap = gameBridge.getLastHudSnapshot();
		setHud(snap && snap.tankId === selectedTankId ? snap : createInitialHud(selectedTankId));
		return gameBridge.onHudUpdate((nextSnap) => setHud(nextSnap));
	}, [selectedTankId]);
	const showControls = settings.showTouchControls === "always" || isTouchDevice;
	const isNarrowScreen = viewportWidth < 560;
	const hpPct = Math.max(0, Math.min(100, hud.hp / Math.max(1, hud.maxHp) * 100));
	const abilityReady = hud.abilityCooldownSec <= .05;
	const abilityActive = hud.abilityActiveSec > 0;
	const canManualReload = !hud.isPreparing && !hud.isReloading && hud.ammo < hud.maxAmmo;
	const reloadProgressPct = hud.isReloading && hud.reloadTotalSec > 0 ? Math.max(0, Math.min(100, (hud.reloadTotalSec - hud.reloadRemainingSec) / hud.reloadTotalSec * 100)) : 0;
	const stickSize = isNarrowScreen ? 88 : isCompactLandscape ? 92 : 110;
	const fireSize = isNarrowScreen ? "w-[56px] h-[56px]" : isCompactLandscape ? "w-[60px] h-[60px]" : "w-[68px] h-[68px] sm:w-[76px] sm:h-[76px]";
	const abilitySize = isNarrowScreen ? "w-[46px] h-[46px]" : isCompactLandscape ? "w-[52px] h-[52px]" : "w-[58px] h-[58px] sm:w-[64px] sm:h-[64px]";
	const reloadBtnSize = isNarrowScreen ? "w-[44px] h-[44px]" : isCompactLandscape ? "w-[46px] h-[46px]" : "w-[50px] h-[50px] sm:w-[56px] sm:h-[56px]";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "pointer-events-none fixed inset-0 z-20 flex flex-col justify-between safe-area-hud sm:p-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start justify-between gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: `pointer-events-auto flex flex-col gap-1 bg-[#141714]/82 border border-[#F3EFE6]/20 rounded-lg backdrop-blur-xs ${isCompactLandscape || isNarrowScreen ? "min-w-[144px] max-w-[178px] px-2.5 py-1" : "min-w-[165px] sm:min-w-[230px] px-3 py-1.5"}`,
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between gap-2 text-[10px] uppercase tracking-wider font-semibold text-[#E08E26]",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "truncate",
									children: hud.tankName
								}), hud.shieldHp > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "inline-flex items-center gap-1 text-sky-400 font-mono tabular-nums normal-case",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shield, { className: "w-3 h-3" }), hud.shieldHp]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex items-center justify-between text-xs font-mono tabular-nums",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "font-semibold text-[#F3EFE6]",
									children: [
										"HP ",
										hud.hp,
										"/",
										hud.maxHp
									]
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "w-full h-2 rounded-sm bg-[#272B26] overflow-hidden border border-[#0F110F]",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "h-full transition-all duration-100",
									style: {
										width: `${hpPct}%`,
										backgroundColor: hpPct > 50 ? "#22C55E" : hpPct > 25 ? "#E08E26" : "#EF4444"
									}
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between gap-2 pt-0.5 text-[11px] font-mono tabular-nums",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: `font-bold ${hud.isReloading ? "text-[#FACC15]" : hud.ammo === 0 ? "text-red-400" : "text-[#F3EFE6]"}`,
									children: [
										"AMMO ",
										hud.ammo,
										"/",
										hud.maxAmmo
									]
								}), hud.isReloading ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-[#FACC15] font-semibold",
									children: [
										"RELOAD ",
										hud.reloadRemainingSec.toFixed(1),
										"s"
									]
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									disabled: !canManualReload,
									onClick: () => {
										if (canManualReload) gameBridge.input.reloadPressed = true;
									},
									className: `px-1.5 py-0.5 rounded border text-[10px] font-sans font-semibold transition ${canManualReload ? "border-[#E08E26]/60 text-[#E08E26] hover:bg-[#E08E26]/15 active:scale-95" : "border-[#F3EFE6]/15 text-[#F3EFE6]/35 cursor-not-allowed"}`,
									children: "Reload (R)"
								})]
							}),
							hud.isReloading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "w-full h-1.5 rounded-sm bg-[#272B26] overflow-hidden border border-[#0F110F]",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "h-full bg-[#FACC15] transition-all duration-75",
									style: { width: `${reloadProgressPct}%` }
								})
							}) : !isCompactLandscape || hud.maxAmmo <= 10 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex items-center gap-0.5",
								children: Array.from({ length: hud.maxAmmo }).map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: `h-1.5 flex-1 rounded-xs transition-colors ${i < hud.ammo ? hud.ammo <= 2 ? "bg-[#E08E26]" : "bg-[#F3EFE6]/85" : "bg-[#272B26]"}` }, i))
							}) : null,
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between gap-2 pt-0.5 text-[11px] font-mono tabular-nums",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "inline-flex items-center gap-1 text-[#F3EFE6]/75 truncate",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Zap, { className: "w-3 h-3 text-[#E08E26] shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "truncate",
										children: hud.abilityName
									})]
								}), abilityActive ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: `font-bold whitespace-nowrap ${hud.abilityName === "Afterburner" ? "text-[#FACC15]" : hud.abilityName === "Shell Barrage" ? "text-red-400" : hud.abilityName === "Phase Shift" ? "text-violet-300" : "text-sky-300"}`,
									children: [
										"ACTIVE ",
										hud.abilityActiveSec.toFixed(1),
										"s"
									]
								}) : abilityReady ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-emerald-400 font-semibold whitespace-nowrap",
									children: "READY (E)"
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-[#F3EFE6]/55 font-semibold whitespace-nowrap",
									children: [
										"CD ",
										Math.ceil(hud.abilityCooldownSec),
										"s"
									]
								})]
							}),
							(hud.mineCharges > 0 || hud.activeMineCount > 0) && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between gap-2 pt-0.5 text-[10px] font-mono tabular-nums",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "inline-flex items-center gap-1 text-orange-300 font-semibold",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Target, { className: "w-3 h-3 text-orange-400 shrink-0" }),
										"MINES ",
										hud.mineCharges,
										"/",
										hud.maxMineCharges,
										hud.activeMineCount > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "text-[#F3EFE6]/55",
											children: [
												"(",
												hud.activeMineCount,
												" SET)"
											]
										})
									]
								}), hud.mineCharges > 0 && !hud.isPreparing && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => {
										gameBridge.input.deployMinePressed = true;
									},
									className: "px-1.5 py-0.5 rounded border border-orange-400/60 text-orange-300 font-sans font-semibold hover:bg-orange-500/20 active:scale-95 transition",
									children: "Drop (F)"
								})]
							}),
							hud.activeBuffs.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex flex-wrap items-center gap-1.5 pt-0.5 text-[10px] font-mono tabular-nums",
								children: hud.activeBuffs.map((b) => {
									const pct = b.totalSec > 0 ? Math.max(0, Math.min(100, b.remainingSec / b.totalSec * 100)) : 100;
									return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex flex-col rounded border px-1.5 py-0.5 bg-[#0F110F]/75 min-w-[50px]",
										style: { borderColor: `${b.color}88` },
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "font-bold leading-tight",
											style: { color: b.color },
											children: [
												b.shortLabel,
												" ",
												Math.ceil(b.remainingSec),
												"s"
											]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "w-full h-0.5 mt-0.5 rounded-xs bg-[#272B26] overflow-hidden",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "block h-full",
												style: {
													width: `${pct}%`,
													backgroundColor: b.color
												}
											})
										})]
									}, b.id);
								})
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col items-center gap-1",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-2.5 sm:gap-3 bg-[#141714]/85 border border-[#F3EFE6]/20 rounded-lg px-3 py-1.5 backdrop-blur-xs text-xs sm:text-sm font-mono tabular-nums",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-bold text-[#F3EFE6]",
										children: formatTime(hud.timeRemainingSec)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-[#F3EFE6]/35",
										children: "·"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "inline-flex items-center gap-1 text-[#E08E26] font-bold",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Users, { className: "w-3.5 h-3.5" }),
											hud.aliveCount,
											"/",
											hud.totalTanks
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-[#F3EFE6]/35",
										children: "·"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "inline-flex items-center gap-1 text-[#F3EFE6]/90 font-semibold",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Crosshair, { className: "w-3.5 h-3.5" }), hud.eliminations]
									})
								]
							}),
							hud.recentPickupName && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "inline-flex items-center gap-1.5 bg-[#141714]/90 border rounded px-2.5 py-0.5 text-[11px] font-bold tracking-wide shadow",
								style: {
									borderColor: hud.recentPickupColor ?? "#E08E26",
									color: hud.recentPickupColor ?? "#F3EFE6"
								},
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "w-3 h-3 shrink-0" }),
									"PICKUP: ",
									hud.recentPickupName.toUpperCase()
								]
							}),
							hud.radarActive && !hud.isPreparing && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "inline-flex items-center gap-1.5 text-[11px] font-mono font-bold text-emerald-300 bg-[#052E23]/88 border border-emerald-400/55 px-2.5 py-0.5 rounded tabular-nums",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Radio, { className: "w-3 h-3 text-emerald-400 shrink-0" }),
									"RADAR ",
									Math.ceil(hud.radarRemainingSec),
									"s · ",
									hud.radarDetectedCount,
									" DETECTED"
								]
							}),
							hud.killFeedText && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "bg-[#141714]/85 border border-[#E08E26]/40 rounded px-2.5 py-0.5 text-[11px] font-medium text-[#F3EFE6]",
								children: hud.killFeedText
							}),
							hud.isConcealed && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-[11px] font-medium text-emerald-300 bg-[#141714]/75 px-2 py-0.5 rounded",
								children: "Concealed in brush"
							}),
							hud.isPhased && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "text-[11px] font-mono font-bold text-violet-300 bg-[#2E1065]/85 border border-violet-400/50 px-2 py-0.5 rounded tabular-nums",
								children: [
									"PHASED ",
									hud.abilityActiveSec.toFixed(1),
									"s"
								]
							}),
							hud.isSlowed && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "text-[11px] font-mono font-bold text-cyan-300 bg-[#083344]/85 border border-cyan-400/50 px-2 py-0.5 rounded tabular-nums",
								children: [
									"⚡ SLOWED ",
									hud.slowRemainingSec.toFixed(1),
									"s"
								]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "pointer-events-auto flex items-center gap-1.5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => {
									onToggleSound();
									soundFX.configure(!settings.soundEnabled, settings.soundVolume, settings.musicEnabled, settings.musicVolume);
								},
								"aria-label": settings.soundEnabled ? "Mute sound effects" : "Unmute sound effects",
								className: "min-w-[44px] min-h-[44px] flex items-center justify-center rounded-lg bg-[#141714]/85 border border-[#F3EFE6]/25 text-[#F3EFE6] hover:bg-[#242823] active:scale-95 transition",
								children: settings.soundEnabled ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Volume2, { className: "w-4 h-4 text-[#E08E26]" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VolumeX, { className: "w-4 h-4 text-[#F3EFE6]/55" })
							}),
							canFullscreen && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => {
									if (isFullscreen) exitLandscapeFullscreen();
									else enterLandscapeFullscreen();
								},
								"aria-label": isFullscreen ? "Exit fullscreen" : "Landscape fullscreen",
								className: "min-w-[44px] min-h-[44px] flex items-center justify-center rounded-lg bg-[#141714]/85 border border-[#F3EFE6]/25 text-[#F3EFE6] hover:bg-[#242823] active:scale-95 transition",
								children: isFullscreen ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Minimize2, { className: "w-4 h-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Maximize2, { className: "w-4 h-4" })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => gameBridge.sendCommand(hud.isPaused ? "RESUME" : "PAUSE"),
								"aria-label": "Pause match",
								className: "min-w-[44px] min-h-[44px] flex items-center justify-center rounded-lg bg-[#141714]/85 border border-[#F3EFE6]/25 text-[#F3EFE6] hover:bg-[#242823] active:scale-95 transition",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pause, { className: "w-5 h-5" })
							})
						]
					})
				]
			}),
			!hud.isPaused && hud.prepLabel && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "pointer-events-none fixed inset-0 z-30 flex flex-col items-center justify-center px-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col items-center rounded-2xl bg-[#141714]/78 border-2 border-[#E08E26]/65 px-7 py-4 sm:px-10 sm:py-5 shadow-2xl backdrop-blur-xs",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-display text-xs sm:text-sm font-bold tracking-[0.22em] uppercase text-[#F3EFE6]/80",
						children: hud.prepLabel === "GO!" ? "Combat Active" : "Get Ready"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: `font-display font-extrabold tracking-wide leading-none mt-1 tabular-nums drop-shadow ${hud.prepLabel === "GO!" ? "text-5xl sm:text-7xl text-[#4ADE80]" : "text-6xl sm:text-8xl text-[#E08E26]"}`,
						children: hud.prepLabel
					})]
				})
			}),
			showControls && !hud.isPaused && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-end justify-between gap-2 sm:gap-3 pb-0.5 px-1 sm:px-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "pointer-events-auto shrink-0",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TouchJoystick, {
						label: "Move",
						accentColor: "#E08E26",
						size: stickSize,
						sensitivity: settings.controlSensitivity,
						onChange: (nx, ny) => {
							gameBridge.input.moveX = nx;
							gameBridge.input.moveY = ny;
						}
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: `pointer-events-auto flex items-end ${isNarrowScreen ? "flex-col gap-1.5" : "gap-2 sm:gap-3.5"}`,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-end gap-1.5 sm:gap-2.5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								disabled: !abilityReady || abilityActive || hud.isPreparing,
								onPointerDown: (e) => {
									e.preventDefault();
									e.stopPropagation();
									if (abilityReady && !abilityActive && !hud.isPreparing) gameBridge.input.abilityPressed = true;
								},
								"aria-label": `Activate ${hud.abilityName}`,
								className: `touch-none-game relative ${abilitySize} rounded-full border-2 flex flex-col items-center justify-center font-display font-bold transition active:scale-95 select-none ${hud.isPreparing ? "bg-[#141714]/65 border-[#F3EFE6]/20 text-[#F3EFE6]/40 cursor-not-allowed" : abilityActive ? hud.abilityName === "Fortress Shield" ? "bg-sky-500 border-[#F3EFE6] text-[#141714]" : hud.abilityName === "Afterburner" ? "bg-[#FACC15] border-[#FEF08A] text-[#141714]" : hud.abilityName === "Shell Barrage" ? "bg-[#EF4444] border-[#FCA5A5] text-[#F3EFE6]" : hud.abilityName === "EMP Pulse" ? "bg-[#22D3EE] border-[#A5F3FC] text-[#141714]" : hud.abilityName === "Phase Shift" ? "bg-[#A78BFA] border-[#DDD6FE] text-[#141714]" : "bg-[#E08E26] border-[#F3EFE6] text-[#141714]" : abilityReady ? hud.abilityName === "EMP Pulse" ? "bg-[#16343D]/90 border-[#22D3EE] text-[#E0F2FE]" : hud.abilityName === "Phase Shift" ? "bg-[#2B2240]/90 border-[#A78BFA] text-[#EDE9FE]" : "bg-[#2B3329]/90 border-[#E08E26] text-[#F3EFE6]" : "bg-[#141714]/80 border-[#F3EFE6]/25 text-[#F3EFE6]/60"}`,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Zap, { className: "w-4 h-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-[9px] sm:text-[11px] leading-tight mt-0.5 tabular-nums",
									children: abilityActive ? `${Math.ceil(hud.abilityActiveSec)}s` : abilityReady ? "ABILITY" : `${Math.ceil(hud.abilityCooldownSec)}s`
								})]
							}),
							hud.mineCharges > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								disabled: hud.isPreparing,
								onPointerDown: (e) => {
									e.preventDefault();
									e.stopPropagation();
									if (!hud.isPreparing) gameBridge.input.deployMinePressed = true;
								},
								"aria-label": "Deploy proximity mine",
								className: `touch-none-game relative ${reloadBtnSize} rounded-full border-2 flex flex-col items-center justify-center font-display font-bold transition active:scale-95 select-none ${hud.isPreparing ? "bg-[#141714]/65 border-[#F3EFE6]/20 text-[#F3EFE6]/35 cursor-not-allowed" : "bg-[#3D2212]/92 border-orange-400 text-orange-200"}`,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Target, { className: "w-3.5 h-3.5 text-orange-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-[9px] sm:text-[10px] leading-tight mt-0.5 tabular-nums",
									children: [
										"MINE (",
										hud.mineCharges,
										")"
									]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								disabled: !canManualReload,
								onPointerDown: (e) => {
									e.preventDefault();
									e.stopPropagation();
									if (canManualReload) gameBridge.input.reloadPressed = true;
								},
								"aria-label": "Reload magazine",
								className: `touch-none-game relative ${reloadBtnSize} rounded-full border-2 flex flex-col items-center justify-center font-display font-bold transition active:scale-95 select-none ${hud.isReloading ? "bg-[#2E2A16]/90 border-[#FACC15] text-[#FACC15] cursor-wait" : canManualReload ? "bg-[#2B3329]/90 border-[#F3EFE6]/75 text-[#F3EFE6]" : "bg-[#141714]/65 border-[#F3EFE6]/20 text-[#F3EFE6]/35 cursor-not-allowed"}`,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCw, { className: `w-3.5 h-3.5 ${hud.isReloading ? "animate-spin" : ""}` }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-[9px] sm:text-[10px] leading-tight mt-0.5 tabular-nums",
									children: hud.isReloading ? `${hud.reloadRemainingSec.toFixed(1)}s` : "RELOAD"
								})]
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-end gap-2 sm:gap-3.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TouchJoystick, {
							label: "Aim",
							accentColor: "#F3EFE6",
							size: stickSize,
							sensitivity: settings.controlSensitivity,
							onChange: (nx, ny, active) => {
								if (hud.isPreparing) {
									gameBridge.input.aimX = 0;
									gameBridge.input.aimY = 0;
									gameBridge.input.aimActive = false;
									return;
								}
								gameBridge.input.aimX = nx;
								gameBridge.input.aimY = ny;
								gameBridge.input.aimActive = active;
							}
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							disabled: hud.isPreparing,
							onPointerDown: (e) => {
								e.preventDefault();
								e.stopPropagation();
								if (hud.isPreparing) return;
								try {
									e.currentTarget.setPointerCapture(e.pointerId);
								} catch {}
								gameBridge.input.firePressed = true;
								gameBridge.input.firing = true;
							},
							onPointerUp: (e) => {
								e.preventDefault();
								e.stopPropagation();
								try {
									if (e.currentTarget.hasPointerCapture(e.pointerId)) e.currentTarget.releasePointerCapture(e.pointerId);
								} catch {}
								gameBridge.input.firing = false;
							},
							onPointerCancel: (e) => {
								e.stopPropagation();
								gameBridge.input.firing = false;
							},
							onLostPointerCapture: () => {
								gameBridge.input.firing = false;
							},
							"aria-label": "Fire cannon",
							className: `touch-none-game ${fireSize} rounded-full border-2 font-display font-extrabold text-xs sm:text-sm tracking-wide flex flex-col items-center justify-center shadow-lg transition select-none ${hud.isPreparing ? "bg-[#6E2A22]/65 border-[#F3EFE6]/35 text-[#F3EFE6]/50 cursor-not-allowed" : hud.isReloading || hud.ammo <= 0 ? "bg-[#42371B]/90 border-[#FACC15]/75 text-[#FACC15] active:scale-95" : "bg-[#C93A2B] border-[#F3EFE6]/85 text-[#F3EFE6] active:scale-95"}`,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Crosshair, { className: "w-4 h-4 sm:w-5 sm:h-5 mb-0.5" }), hud.isReloading ? "WAIT" : hud.ammo <= 0 ? "EMPTY" : "FIRE"]
						})]
					})]
				})]
			}),
			hud.isPaused && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "pointer-events-auto fixed inset-0 z-40 bg-[#0D0F0D]/80 backdrop-blur-sm flex items-center justify-center p-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "w-full max-w-sm bg-[#1E221D] border-2 border-[#F3EFE6]/25 rounded-xl p-6 shadow-2xl",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display text-3xl font-extrabold tracking-wide text-[#F3EFE6] text-center",
							children: "Match Paused"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-xs text-[#F3EFE6]/65 text-center mt-1 mb-5",
							children: [
								hud.aliveCount,
								" of ",
								hud.totalTanks,
								" tanks remaining · ",
								formatTime(hud.timeRemainingSec),
								" left"
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-col gap-2.5",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: () => gameBridge.sendCommand("RESUME"),
									className: "min-h-[46px] w-full rounded-lg bg-[#E08E26] text-[#141714] font-semibold text-sm flex items-center justify-center gap-2 hover:bg-[#EE9B32] transition whitespace-nowrap",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "w-4 h-4" }), "Resume Match"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: () => {
										gameBridge.clearLastHudSnapshot();
										gameBridge.sendCommand("RESTART");
										onRestartMatch();
									},
									className: "min-h-[44px] w-full rounded-lg bg-[#2B3029] border border-[#F3EFE6]/20 text-[#F3EFE6] font-medium text-sm flex items-center justify-center gap-2 hover:bg-[#353C33] transition whitespace-nowrap",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { className: "w-4 h-4" }), "Restart Match"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid grid-cols-2 gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										onClick: () => {
											onToggleSound();
											soundFX.configure(!settings.soundEnabled, settings.soundVolume, settings.musicEnabled, settings.musicVolume);
										},
										className: "min-h-[44px] px-3 rounded-lg bg-[#2B3029] border border-[#F3EFE6]/20 text-[#F3EFE6] font-medium text-sm flex items-center justify-center gap-2 hover:bg-[#353C33] transition whitespace-nowrap",
										children: [
											settings.soundEnabled ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Volume2, { className: "w-4 h-4 text-[#E08E26]" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VolumeX, { className: "w-4 h-4 text-[#F3EFE6]/60" }),
											"SFX: ",
											settings.soundEnabled ? "On" : "Off"
										]
									}), onToggleMusic && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										onClick: () => {
											onToggleMusic();
											soundFX.configure(settings.soundEnabled, settings.soundVolume, !settings.musicEnabled, settings.musicVolume);
										},
										className: "min-h-[44px] px-3 rounded-lg bg-[#2B3029] border border-[#F3EFE6]/20 text-[#F3EFE6] font-medium text-sm flex items-center justify-center gap-2 hover:bg-[#353C33] transition whitespace-nowrap",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Music, { className: `w-4 h-4 ${settings.musicEnabled ? "text-[#E08E26]" : "text-[#F3EFE6]/60"}` }),
											"Music: ",
											settings.musicEnabled ? "On" : "Off"
										]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: onExitToMenu,
									className: "min-h-[44px] w-full rounded-lg bg-transparent border border-[#F3EFE6]/20 text-[#F3EFE6]/80 font-medium text-sm flex items-center justify-center gap-2 hover:bg-[#2B3029] transition whitespace-nowrap",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(House, { className: "w-4 h-4" }), "Return to Main Menu"]
								})
							]
						})
					]
				})
			})
		]
	});
}
// src/components/ScrapBadge.tsx
function ScrapBadge({ scrap, compact = false, label = "Scrap", className = "" }) {
	const safeScrap = Math.max(0, Math.floor(scrap));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		"aria-label": `Scrap balance: ${safeScrap}`,
		className: `inline-flex items-center gap-2 rounded-xl bg-[#1E221D] border border-sky-400/30 shadow-sm shrink-0 ${compact ? "px-2.5 py-1.5 min-h-[38px]" : "px-3 sm:px-3.5 py-1.5 min-h-[44px]"} ${className}`,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "w-6 h-6 rounded-md bg-sky-500/15 border border-sky-400/40 text-sky-300 flex items-center justify-center shrink-0",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Hexagon, { className: "w-3.5 h-3.5 stroke-[2.4]" })
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "leading-none",
			children: [!compact && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "text-[9px] font-mono uppercase tracking-wider text-sky-300/75",
				children: label
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "font-mono text-sm font-extrabold text-sky-300 tabular-nums mt-0.5",
				children: [safeScrap.toLocaleString(), compact && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "ml-1 text-[10px] font-semibold uppercase text-sky-300/75",
					children: "Scrap"
				})]
			})]
		})]
	});
}
// src/components/TankDecalSvg.tsx
function getStarPoints(rOuter, rInner) {
	const pts = [];
	for (let i = 0; i < 10; i++) {
		const angle = -Math.PI / 2 + i * Math.PI / 5;
		const r = i % 2 === 0 ? rOuter : rInner;
		pts.push(`${(Math.cos(angle) * r).toFixed(2)},${(Math.sin(angle) * r).toFixed(2)}`);
	}
	return pts.join(" ");
}
function getHexPoints(radius) {
	const pts = [];
	for (let i = 0; i < 6; i++) {
		const angle = i * Math.PI / 3;
		pts.push(`${(Math.cos(angle) * radius).toFixed(2)},${(Math.sin(angle) * radius).toFixed(2)}`);
	}
	return pts.join(" ");
}
function TankDecalShape({ decalId, color }) {
	switch (decalId) {
		case "chevron": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", {
			fill: "none",
			stroke: color,
			strokeWidth: 2.4,
			strokeLinecap: "round",
			strokeLinejoin: "round",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("polyline", { points: "-4,-5 4,0 -4,5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("polyline", { points: "-7.5,-3.8 -1,0 -7.5,3.8" })]
		});
		case "iron_crosshair": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: 0,
				cy: 0,
				r: 5.2,
				fill: "none",
				stroke: color,
				strokeWidth: 1.8
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", {
				stroke: color,
				strokeWidth: 1.8,
				strokeLinecap: "round",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
						x1: -7.2,
						y1: 0,
						x2: -2.4,
						y2: 0
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
						x1: 2.4,
						y1: 0,
						x2: 7.2,
						y2: 0
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
						x1: 0,
						y1: -7.2,
						x2: 0,
						y2: -2.4
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
						x1: 0,
						y1: 2.4,
						x2: 0,
						y2: 7.2
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: 0,
				cy: 0,
				r: 1.4,
				fill: color
			})
		] });
		case "shield_crest": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("polygon", {
			points: "-5.2,-5.5 5.2,-5.5 5.2,0.5 0,6.5 -5.2,0.5",
			fill: "none",
			stroke: color,
			strokeWidth: 1.8,
			strokeLinejoin: "round"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("polygon", {
			points: "-2.5,-3 2.5,-3 0,3",
			fill: color
		})] });
		case "command_star": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("polygon", {
			points: getStarPoints(6.8, 2.9),
			fill: color
		});
		case "num_01":
		case "num_07":
		case "num_42":
		case "num_99": {
			const label = decalId.slice(4);
			return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
				x: 0,
				y: .6,
				textAnchor: "middle",
				dominantBaseline: "central",
				fontSize: "9.5",
				fontWeight: "800",
				fontFamily: "'Barlow Condensed', sans-serif",
				fill: color,
				stroke: "#161815",
				strokeWidth: 2.2,
				paintOrder: "stroke fill",
				children: label
			});
		}
		case "twin_stripes": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", {
			fill: color,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: -6.5,
				y: -4,
				width: 13,
				height: 2.6,
				rx: .6
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: -6.5,
				y: 1.4,
				width: 13,
				height: 2.6,
				rx: .6
			})]
		});
		case "hazard_stripes": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", {
			stroke: color,
			strokeWidth: 2.5,
			strokeLinecap: "round",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
					x1: -6.5,
					y1: -4.5,
					x2: -2.5,
					y2: 4.5
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
					x1: -2,
					y1: -4.5,
					x2: 2,
					y2: 4.5
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
					x1: 2.5,
					y1: -4.5,
					x2: 6.5,
					y2: 4.5
				})
			]
		});
		case "apex_diamond": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("polygon", {
			points: "0,-6.5 6.5,0 0,6.5 -6.5,0",
			fill: "none",
			stroke: color,
			strokeWidth: 1.8,
			strokeLinejoin: "round"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("polygon", {
			points: "0,-3 3,0 0,3 -3,0",
			fill: color
		})] });
		case "hex_core": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("polygon", {
			points: getHexPoints(6),
			fill: "none",
			stroke: color,
			strokeWidth: 1.8,
			strokeLinejoin: "round"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
			cx: 0,
			cy: 0,
			r: 2.2,
			fill: color
		})] });
		case "thunder_bolt": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("polygon", {
			points: "1.8,-6.8 -4.2,0.5 -0.3,0.5 -2.2,6.8 4.2,-0.8 0.2,-0.8",
			fill: color
		});
		case "apex_crown": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("polygon", {
			points: "-5.8,4.5 -5.8,-3.5 -2.5,0.5 0,-5 2.5,0.5 5.8,-3.5 5.8,4.5",
			fill: color
		});
		case "winged_crest": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("polygon", {
			points: "-7,-3.5 -1.5,-1 0,-5 1.5,-1 7,-3.5 4.5,3 0,5.2 -4.5,3",
			fill: color
		});
		default: return null;
	}
}
function TankDecalSvg({ decalId, decalColor, position, silhouette, layer }) {
	if (decalId === "none") return null;
	const placements = getDecalPlacements(position, silhouette, layer, 1);
	if (placements.length === 0) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("g", {
		className: "pointer-events-none",
		children: placements.map((p, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("g", {
			transform: `translate(${p.x.toFixed(2)}, ${p.y.toFixed(2)}) rotate(${p.rotationDeg}) scale(${p.scale.toFixed(3)})`,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TankDecalShape, {
				decalId,
				color: decalColor
			})
		}, `${layer}-${idx}`))
	});
}
function TankDecalIcon({ decalId, color = "#F3EFE6", size = 22, className = "" }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
		width: size,
		height: size,
		viewBox: "-9 -9 18 18",
		className,
		"aria-hidden": "true",
		children: decalId === "none" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
			cx: 0,
			cy: 0,
			r: 5.5,
			fill: "none",
			stroke: color,
			strokeOpacity: .35,
			strokeWidth: 1.6,
			strokeDasharray: "2.2 2"
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TankDecalShape, {
			decalId,
			color
		})
	});
}
// src/components/TankPreviewSvg.tsx
function TankPreviewSvg({ tank, cosmeticId = "default", customization = null, size = 96, hullAngleDeg = -18, turretAngleDeg, className = "" }) {
	const visual = resolveEffectiveTankVisual(tank, cosmeticId, customization);
	const barrelColor = visual.barrelColor ?? visual.hullSecondary;
	const ink = "#161815";
	const relativeTurretDeg = (turretAngleDeg ?? hullAngleDeg) - hullAngleDeg;
	const treadW = visual.silhouette === "heavy" ? 62 : visual.silhouette === "sleek" ? 52 : visual.silhouette === "long_barrel" ? 58 : 56;
	const treadH = visual.silhouette === "heavy" ? 14 : visual.silhouette === "sleek" ? 9 : 10.5;
	const treadYOffset = visual.silhouette === "heavy" ? 20 : visual.silhouette === "sleek" ? 16 : 17;
	const turretR = visual.silhouette === "heavy" ? 18 : visual.silhouette === "sleek" ? 13 : 15;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
		width: size,
		height: size,
		viewBox: "0 0 110 110",
		className,
		"aria-label": `${tank.name} illustration`,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", {
			transform: `translate(50, 55) rotate(${hullAngleDeg})`,
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
					x: -28,
					y: -24,
					width: visual.silhouette === "heavy" ? 62 : 58,
					height: visual.silhouette === "heavy" ? 54 : 48,
					rx: 9,
					fill: "rgba(0,0,0,0.28)"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
					x: -treadW / 2,
					y: -treadYOffset - treadH / 2,
					width: treadW,
					height: treadH,
					rx: 4,
					fill: visual.treadColor,
					stroke: ink,
					strokeWidth: 3
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
					x: -treadW / 2,
					y: treadYOffset - treadH / 2,
					width: treadW,
					height: treadH,
					rx: 4,
					fill: visual.treadColor,
					stroke: ink,
					strokeWidth: 3
				}),
				visual.silhouette === "angular" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("polygon", {
					points: "28,0 14,-18 -24,-16 -19,0 -24,16 14,18",
					fill: visual.hullPrimary,
					stroke: ink,
					strokeWidth: 3,
					strokeLinejoin: "round"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("polygon", {
					points: "18,0 8,-11 -16,-9 -13,0 -16,9 8,11",
					fill: visual.hullSecondary,
					stroke: ink,
					strokeWidth: 1.8,
					strokeLinejoin: "round"
				})] }) : visual.silhouette === "sleek" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("polygon", {
					points: "26,-9 26,9 7,13 -24,13 -24,-13 7,-13",
					fill: visual.hullPrimary,
					stroke: ink,
					strokeWidth: 3,
					strokeLinejoin: "round"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
					x: -18,
					y: -9,
					width: 30,
					height: 18,
					rx: 4,
					fill: visual.hullSecondary,
					stroke: ink,
					strokeWidth: 2
				})] }) : visual.silhouette === "heavy" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
						x: -28,
						y: -19,
						width: 56,
						height: 38,
						rx: 7,
						fill: visual.hullPrimary,
						stroke: ink,
						strokeWidth: 3
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
						x: -21,
						y: -13,
						width: 38,
						height: 26,
						rx: 4,
						fill: visual.hullSecondary,
						stroke: ink,
						strokeWidth: 2
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
						x: -25,
						y: -10,
						width: 5,
						height: 7,
						rx: 1.5,
						fill: visual.accentColor,
						stroke: ink,
						strokeWidth: 1.5
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
						x: -25,
						y: 3,
						width: 5,
						height: 7,
						rx: 1.5,
						fill: visual.accentColor,
						stroke: ink,
						strokeWidth: 1.5
					})
				] }) : visual.silhouette === "long_barrel" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
						x: -28,
						y: -15,
						width: 7,
						height: 7,
						rx: 1.5,
						fill: "#3B342C",
						stroke: ink,
						strokeWidth: 2
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
						x: -28,
						y: 8,
						width: 7,
						height: 7,
						rx: 1.5,
						fill: "#3B342C",
						stroke: ink,
						strokeWidth: 2
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
						x: -25,
						y: -17,
						width: 50,
						height: 34,
						rx: 6,
						fill: visual.hullPrimary,
						stroke: ink,
						strokeWidth: 3
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
						x: -19,
						y: -11,
						width: 34,
						height: 22,
						rx: 3,
						fill: visual.hullSecondary,
						stroke: ink,
						strokeWidth: 2
					})
				] }) : visual.silhouette === "coil" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
						x: -26,
						y: -16,
						width: 52,
						height: 32,
						rx: 7,
						fill: visual.hullPrimary,
						stroke: ink,
						strokeWidth: 3
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
						x: -19,
						y: -11,
						width: 34,
						height: 22,
						rx: 4,
						fill: visual.hullSecondary,
						stroke: ink,
						strokeWidth: 2
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
						x: -14,
						y: -17,
						width: 24,
						height: 6,
						rx: 2,
						fill: visual.accentColor,
						stroke: ink,
						strokeWidth: 1.6
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
						x: -14,
						y: 11,
						width: 24,
						height: 6,
						rx: 2,
						fill: visual.accentColor,
						stroke: ink,
						strokeWidth: 1.6
					})
				] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
					x: -26,
					y: -16,
					width: 52,
					height: 32,
					rx: 7,
					fill: visual.hullPrimary,
					stroke: ink,
					strokeWidth: 3
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
					x: -19,
					y: -11,
					width: 34,
					height: 22,
					rx: 4,
					fill: visual.hullSecondary,
					stroke: ink,
					strokeWidth: 2
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
					x: 13,
					y: -8,
					width: 6,
					height: 16,
					rx: 2,
					fill: visual.accentColor,
					stroke: ink,
					strokeWidth: 2
				}),
				customization && customization.decalId !== "none" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TankDecalSvg, {
					decalId: customization.decalId,
					decalColor: customization.decalColor,
					position: customization.decalPosition,
					silhouette: visual.silhouette,
					layer: "hull"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", {
					transform: `rotate(${relativeTurretDeg})`,
					children: [
						visual.silhouette === "long_barrel" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
								x: 7,
								y: -7,
								width: 14,
								height: 14,
								rx: 3,
								fill: visual.hullPrimary,
								stroke: ink,
								strokeWidth: 2.2
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
								x: 12,
								y: -4.5,
								width: 43,
								height: 9,
								rx: 2,
								fill: barrelColor,
								stroke: ink,
								strokeWidth: 2.5
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
								x: 49,
								y: -6.5,
								width: 8.5,
								height: 13,
								rx: 2,
								fill: visual.accentColor,
								stroke: ink,
								strokeWidth: 2
							})
						] }) : visual.silhouette === "heavy" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
								x: 6,
								y: -8,
								width: 13,
								height: 16,
								rx: 3,
								fill: visual.hullPrimary,
								stroke: ink,
								strokeWidth: 2.2
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
								x: 11,
								y: -6,
								width: 29,
								height: 12,
								rx: 3,
								fill: barrelColor,
								stroke: ink,
								strokeWidth: 2.5
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
								x: 35,
								y: -7.5,
								width: 8,
								height: 15,
								rx: 2,
								fill: visual.accentColor,
								stroke: ink,
								strokeWidth: 2
							})
						] }) : visual.silhouette === "coil" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
								x: 8,
								y: -5,
								width: 32,
								height: 10,
								rx: 3,
								fill: barrelColor,
								stroke: ink,
								strokeWidth: 2.5
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
								x1: 35,
								y1: -4,
								x2: 45,
								y2: -9,
								stroke: ink,
								strokeWidth: 4.5,
								strokeLinecap: "round"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
								x1: 35,
								y1: 4,
								x2: 45,
								y2: 9,
								stroke: ink,
								strokeWidth: 4.5,
								strokeLinecap: "round"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
								x1: 35,
								y1: -4,
								x2: 45,
								y2: -9,
								stroke: visual.accentColor,
								strokeWidth: 2.2,
								strokeLinecap: "round"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
								x1: 35,
								y1: 4,
								x2: 45,
								y2: 9,
								stroke: visual.accentColor,
								strokeWidth: 2.2,
								strokeLinecap: "round"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
								x1: 17,
								y1: -8,
								x2: 17,
								y2: 8,
								stroke: visual.accentColor,
								strokeWidth: 3.2
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
								x1: 24,
								y1: -8,
								x2: 24,
								y2: 8,
								stroke: visual.accentColor,
								strokeWidth: 3.2
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
								x1: 31,
								y1: -8,
								x2: 31,
								y2: 8,
								stroke: visual.accentColor,
								strokeWidth: 3.2
							})
						] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
							x: 8,
							y: -5,
							width: 34,
							height: 10,
							rx: 3,
							fill: barrelColor,
							stroke: ink,
							strokeWidth: 2.5
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
							x: 37,
							y: -6,
							width: 7,
							height: 12,
							rx: 2,
							fill: visual.accentColor,
							stroke: ink,
							strokeWidth: 2
						})] }),
						visual.silhouette === "angular" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("polygon", {
							points: "16,0 3,-14 -14,-10 -14,10 3,14",
							fill: visual.turretColor,
							stroke: ink,
							strokeWidth: 3,
							strokeLinejoin: "round"
						}) : visual.silhouette === "heavy" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("polygon", {
							points: "17,-9 17,9 6,17 -12,16 -17,8 -17,-8 -12,-16 6,-17",
							fill: visual.turretColor,
							stroke: ink,
							strokeWidth: 3,
							strokeLinejoin: "round"
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
							cx: 0,
							cy: 0,
							r: turretR,
							fill: visual.turretColor,
							stroke: ink,
							strokeWidth: 3
						}),
						visual.silhouette === "sleek" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
							x1: -8,
							y1: -6,
							x2: -19,
							y2: -13,
							stroke: visual.accentColor,
							strokeWidth: 2.2,
							strokeLinecap: "round"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
							cx: -3,
							cy: -2,
							r: 5,
							fill: visual.silhouette === "coil" || visual.silhouette === "angular" ? visual.accentColor : visual.hullSecondary,
							stroke: ink,
							strokeWidth: 2
						}),
						customization && customization.decalId !== "none" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TankDecalSvg, {
							decalId: customization.decalId,
							decalColor: customization.decalColor,
							position: customization.decalPosition,
							silhouette: visual.silhouette,
							layer: "turret"
						})
					]
				})
			]
		})
	});
}
// src/components/TankCustomizationPanel.tsx
var PAINT_ZONES = [
	{
		key: "primaryColor",
		label: "Primary Hull",
		shortLabel: "Primary"
	},
	{
		key: "secondaryColor",
		label: "Secondary Trim",
		shortLabel: "Secondary"
	},
	{
		key: "turretColor",
		label: "Turret Dome",
		shortLabel: "Turret"
	},
	{
		key: "barrelColor",
		label: "Main Barrel",
		shortLabel: "Barrel"
	}
];
var DECAL_CATEGORIES = [
	"All",
	"Insignia",
	"Star",
	"Number",
	"Stripes",
	"Geometric",
	"Special"
];
function TankCustomizationPanel({ tank, progression, draft, appliedCustomization, onChangeDraft, onApply, onReset, onPurchasePreset, onPurchasePaintColor, onPurchaseCustomPaint, onPurchaseDecal, onPurchaseCosmetic, onEquipCosmetic }) {
	const [subTab, setSubTab] = (0, import_react.useState)("presets");
	const [activeZone, setActiveZone] = (0, import_react.useState)("primaryColor");
	const [decalCategory, setDecalCategory] = (0, import_react.useState)("All");
	const [shopFeedback, setShopFeedback] = (0, import_react.useState)(null);
	const cosmeticId = progression.equippedCosmetic;
	const defaultLook = (0, import_react.useMemo)(() => createDefaultTankCustomization(tank, cosmeticId), [tank, cosmeticId]);
	const effectiveApplied = appliedCustomization ?? defaultLook;
	const presets = (0, import_react.useMemo)(() => getTankPresets(tank.id), [tank.id]);
	const hasUnappliedChanges = !areCustomizationsEqual(draft, effectiveApplied);
	const isDefaultLook = areCustomizationsEqual(draft, defaultLook) && appliedCustomization === null;
	const lockedItems = (0, import_react.useMemo)(() => getLockedItemsInCustomization(progression, tank, draft), [
		progression,
		tank,
		draft
	]);
	const filteredDecals = (0, import_react.useMemo)(() => {
		if (decalCategory === "All") return TANK_DECAL_LIST;
		return TANK_DECAL_LIST.filter((d) => d.id === "none" || d.category === decalCategory);
	}, [decalCategory]);
	const currentZoneHex = normalizeHexColor(draft[activeZone], defaultLook[activeZone]);
	const currentDecalHex = normalizeHexColor(draft.decalColor, defaultLook.decalColor);
	const activeZoneSwatch = PAINT_COLOR_SWATCHES.find((s) => s.hex.toUpperCase() === currentZoneHex);
	const activeZoneUnlocked = isPaintColorUnlocked(progression, currentZoneHex, tank);
	const activeDecalSwatch = DECAL_COLOR_SWATCHES.find((s) => s.hex.toUpperCase() === currentDecalHex);
	const activeDecalColorUnlocked = isPaintColorUnlocked(progression, currentDecalHex, tank);
	const activeDecalDef = TANK_DECAL_MAP[draft.decalId];
	const activeDecalUnlocked = isDecalUnlocked(progression, draft.decalId);
	const matchingPreset = (0, import_react.useMemo)(() => presets.find((p) => draft.presetId && draft.presetId === p.id || areCustomizationsEqual(draft, p.customization)) ?? null, [draft, presets]);
	const reportPurchase = (outcome, itemName) => {
		if (outcome.success) setShopFeedback({
			type: "success",
			text: `Unlocked ${itemName} (-${outcome.cost} Scrap)`
		});
		else if (outcome.reason === "insufficient_scrap") {
			const missing = Math.max(0, outcome.cost - outcome.remainingScrap);
			setShopFeedback({
				type: "error",
				text: `Need ${missing} more Scrap to unlock ${itemName}.`
			});
		}
	};
	const cyclePreset = (dir) => {
		if (presets.length === 0) return;
		const activeIdx = presets.findIndex((p) => areCustomizationsEqual(draft, p.customization));
		const nextIdx = activeIdx === -1 ? 0 : (activeIdx + dir + presets.length) % presets.length;
		onChangeDraft({ ...presets[nextIdx].customization });
	};
	const cyclePaintSwatch = (dir) => {
		const idx = PAINT_COLOR_SWATCHES.findIndex((s) => s.hex.toUpperCase() === currentZoneHex);
		const nextIdx = idx === -1 ? 0 : (idx + dir + PAINT_COLOR_SWATCHES.length) % PAINT_COLOR_SWATCHES.length;
		onChangeDraft({
			...draft,
			[activeZone]: PAINT_COLOR_SWATCHES[nextIdx].hex.toUpperCase(),
			presetId: null
		});
	};
	const cycleDecal = (dir) => {
		const idx = TANK_DECAL_LIST.findIndex((d) => d.id === draft.decalId);
		const nextIdx = idx === -1 ? 0 : (idx + dir + TANK_DECAL_LIST.length) % TANK_DECAL_LIST.length;
		onChangeDraft({
			...draft,
			decalId: TANK_DECAL_LIST[nextIdx].id,
			presetId: null
		});
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-3 flex-1 min-h-0",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				role: "tablist",
				"aria-label": "Customization categories",
				className: "grid grid-cols-4 gap-1.5 bg-[#141714] p-1 rounded-xl border border-[#F3EFE6]/12",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						role: "tab",
						"aria-selected": subTab === "presets",
						onClick: () => setSubTab("presets"),
						className: `min-h-[44px] rounded-lg text-xs sm:text-sm font-semibold flex items-center justify-center gap-1.5 transition ${subTab === "presets" ? "bg-[#E08E26] text-[#141714] font-bold shadow" : "text-[#F3EFE6]/75 hover:text-[#F3EFE6] hover:bg-[#1E221D]"}`,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "w-3.5 h-3.5" }), "Presets"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						role: "tab",
						"aria-selected": subTab === "paint",
						onClick: () => setSubTab("paint"),
						className: `min-h-[44px] rounded-lg text-xs sm:text-sm font-semibold flex items-center justify-center gap-1.5 transition ${subTab === "paint" ? "bg-[#E08E26] text-[#141714] font-bold shadow" : "text-[#F3EFE6]/75 hover:text-[#F3EFE6] hover:bg-[#1E221D]"}`,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Palette, { className: "w-3.5 h-3.5" }), "Paint"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						role: "tab",
						"aria-selected": subTab === "decals",
						onClick: () => setSubTab("decals"),
						className: `min-h-[44px] rounded-lg text-xs sm:text-sm font-semibold flex items-center justify-center gap-1.5 transition ${subTab === "decals" ? "bg-[#E08E26] text-[#141714] font-bold shadow" : "text-[#F3EFE6]/75 hover:text-[#F3EFE6] hover:bg-[#1E221D]"}`,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stamp, { className: "w-3.5 h-3.5" }), "Decals"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						role: "tab",
						"aria-selected": subTab === "skins",
						onClick: () => setSubTab("skins"),
						className: `min-h-[44px] rounded-lg text-xs sm:text-sm font-semibold flex items-center justify-center gap-1.5 transition ${subTab === "skins" ? "bg-[#E08E26] text-[#141714] font-bold shadow" : "text-[#F3EFE6]/75 hover:text-[#F3EFE6] hover:bg-[#1E221D]"}`,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Star, { className: "w-3.5 h-3.5" }), "Skins"]
					})
				]
			}),
			shopFeedback && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: `rounded-xl px-3 py-2 text-xs font-semibold border flex items-center justify-between gap-2 shrink-0 ${shopFeedback.type === "success" ? "bg-[#1A2B1D] border-[#22C55E]/50 text-[#86EFAC]" : "bg-[#2B1B1B] border-red-400/45 text-red-300"}`,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: shopFeedback.text }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setShopFeedback(null),
					className: "text-[11px] font-mono opacity-75 hover:opacity-100",
					children: "Dismiss"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex-1 min-h-0 overflow-y-auto pr-0.5 space-y-3",
				children: [
					subTab === "presets" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-2.5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-[11px] font-mono uppercase tracking-wider text-[#F3EFE6]/60",
									children: [tank.name, " Signature Looks (Visual Only)"]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: () => cyclePreset(-1),
										"aria-label": "Previous preset",
										className: "min-w-[44px] min-h-[44px] rounded-lg bg-[#141714] border border-[#F3EFE6]/15 flex items-center justify-center hover:border-[#E08E26]/65 transition",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "w-4 h-4" })
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: () => cyclePreset(1),
										"aria-label": "Next preset",
										className: "min-w-[44px] min-h-[44px] rounded-lg bg-[#141714] border border-[#F3EFE6]/15 flex items-center justify-center hover:border-[#E08E26]/65 transition",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "w-4 h-4" })
									})]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => onChangeDraft({ ...defaultLook }),
								className: `w-full min-h-[54px] text-left rounded-xl p-3 border transition flex items-center justify-between gap-3 ${areCustomizationsEqual(draft, defaultLook) ? "bg-[#252B23] border-[#E08E26]" : "bg-[#141714] border-[#F3EFE6]/12 hover:border-[#F3EFE6]/30"}`,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "min-w-0",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "font-display text-base font-bold text-[#F3EFE6] leading-tight",
											children: "Factory Standard"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-[10px] font-mono uppercase text-[#86EFAC]",
											children: "Owned"
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "text-[11px] text-[#F3EFE6]/60 mt-0.5 truncate",
										children: [
											"Original ",
											tank.name,
											" combat livery"
										]
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "flex items-center gap-1 shrink-0",
									children: [
										defaultLook.primaryColor,
										defaultLook.secondaryColor,
										defaultLook.turretColor,
										defaultLook.barrelColor
									].map((hex, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "w-4 h-4 rounded border border-black/50",
										style: { backgroundColor: hex }
									}, `std-${i}`))
								})]
							}),
							presets.map((preset) => {
								const active = areCustomizationsEqual(draft, preset.customization);
								const unlocked = isPresetUnlocked(progression, preset.id);
								const cost = preset.scrapCost ?? 0;
								const affordable = progression.scrap >= cost;
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: `rounded-xl p-3 border transition space-y-2 ${active ? "bg-[#252B23] border-[#E08E26] shadow" : "bg-[#141714] border-[#F3EFE6]/12 hover:border-[#F3EFE6]/30"}`,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										onClick: () => onChangeDraft({ ...preset.customization }),
										className: "w-full text-left flex items-center justify-between gap-3",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "min-w-0 flex-1",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center gap-2 flex-wrap",
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "font-display text-base font-bold text-[#F3EFE6] leading-tight truncate",
														children: preset.name
													}),
													unlocked ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "text-[10px] font-mono uppercase text-[#86EFAC] font-bold",
														children: "Owned"
													}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
														className: "inline-flex items-center gap-1 px-1.5 py-0.5 rounded bg-[#1E221D] border border-sky-400/35 text-[10px] font-mono font-bold text-sky-300",
														children: [
															/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, { className: "w-2.5 h-2.5" }),
															cost,
															" Scrap"
														]
													}),
													active && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "text-[10px] font-mono uppercase text-[#E08E26] font-bold",
														children: "Previewing"
													})
												]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-[11px] text-[#F3EFE6]/60 mt-0.5 leading-snug",
												children: preset.description
											})]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center gap-1.5 shrink-0",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "w-7 h-7 rounded-md bg-[#1B1F1A] border border-[#F3EFE6]/15 flex items-center justify-center",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TankDecalIcon, {
													decalId: preset.customization.decalId,
													color: preset.customization.decalColor,
													size: 18
												})
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "grid grid-cols-2 gap-0.5",
												children: [
													preset.customization.primaryColor,
													preset.customization.secondaryColor,
													preset.customization.turretColor,
													preset.customization.barrelColor
												].map((hex, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "w-3.5 h-3.5 rounded-[3px] border border-black/50",
													style: { backgroundColor: hex }
												}, `${preset.id}-c-${idx}`))
											})]
										})]
									}), !unlocked && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "flex items-center justify-end pt-1 border-t border-[#F3EFE6]/10",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
											type: "button",
											disabled: !affordable,
											onClick: () => {
												const outcome = onPurchasePreset(preset.id);
												reportPurchase(outcome, preset.name);
												if (outcome.success) onChangeDraft({ ...preset.customization });
											},
											className: `min-h-[38px] px-3 rounded-lg text-xs font-bold flex items-center gap-1.5 transition ${affordable ? "bg-sky-400 text-[#141714] hover:bg-sky-300" : "bg-[#1E221D] border border-[#F3EFE6]/12 text-[#F3EFE6]/45 cursor-not-allowed"}`,
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShoppingCart, { className: "w-3.5 h-3.5" }), affordable ? `Unlock Preset · ${cost} Scrap` : `Need ${cost - progression.scrap} Scrap`]
										})
									})]
								}, preset.id);
							})
						]
					}),
					subTab === "paint" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between mb-1.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-[11px] font-mono uppercase tracking-wider text-[#F3EFE6]/60",
									children: "Select Component Zone"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: () => cyclePaintSwatch(-1),
										"aria-label": "Previous color swatch",
										className: "min-w-[36px] min-h-[36px] rounded-lg bg-[#141714] border border-[#F3EFE6]/15 flex items-center justify-center hover:border-[#E08E26]/65 transition",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "w-4 h-4" })
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: () => cyclePaintSwatch(1),
										"aria-label": "Next color swatch",
										className: "min-w-[36px] min-h-[36px] rounded-lg bg-[#141714] border border-[#F3EFE6]/15 flex items-center justify-center hover:border-[#E08E26]/65 transition",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "w-4 h-4" })
									})]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "grid grid-cols-2 sm:grid-cols-4 gap-1.5",
								children: PAINT_ZONES.map((zone) => {
									const selected = activeZone === zone.key;
									const hex = normalizeHexColor(draft[zone.key], defaultLook[zone.key]);
									return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										onClick: () => setActiveZone(zone.key),
										className: `min-h-[48px] px-2.5 py-1.5 rounded-xl border text-left flex items-center gap-2 transition ${selected ? "bg-[#252B23] border-[#E08E26]" : "bg-[#141714] border-[#F3EFE6]/12 hover:border-[#F3EFE6]/30"}`,
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "w-5 h-5 rounded-md border border-black/60 shrink-0",
											style: { backgroundColor: hex }
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "min-w-0",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "text-xs font-semibold text-[#F3EFE6] leading-tight truncate",
												children: zone.shortLabel
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "text-[10px] font-mono text-[#F3EFE6]/50 truncate",
												children: hex
											})]
										})]
									}, zone.key);
								})
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between text-[11px] font-mono uppercase tracking-wider text-[#F3EFE6]/60 mb-1.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["Armor Swatches · ", PAINT_ZONES.find((z) => z.key === activeZone)?.label] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-[10px] text-sky-300",
										children: "Locked paints preview live"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "grid grid-cols-5 sm:grid-cols-7 gap-1.5 sm:gap-2",
									children: PAINT_COLOR_SWATCHES.map((swatch) => {
										const active = swatch.hex.toUpperCase() === currentZoneHex;
										const unlocked = isPaintColorUnlocked(progression, swatch.hex, tank);
										return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
											type: "button",
											title: unlocked ? `${swatch.name} (Owned)` : `${swatch.name} (${swatch.scrapCost} Scrap)`,
											"aria-label": `${swatch.name} (${swatch.hex})`,
											onClick: () => onChangeDraft({
												...draft,
												[activeZone]: swatch.hex.toUpperCase(),
												presetId: null
											}),
											className: `relative min-h-[46px] w-full rounded-lg border-2 flex items-center justify-center transition ${active ? "border-[#F3EFE6] scale-105 shadow-md" : "border-[#161815] hover:border-[#F3EFE6]/50"}`,
											style: { backgroundColor: swatch.hex },
											children: [active ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "w-4 h-4 text-white drop-shadow-[0_1px_2px_rgba(0,0,0,0.95)] stroke-[3]" }) : !unlocked ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, { className: "w-3.5 h-3.5 text-white drop-shadow-[0_1px_2px_rgba(0,0,0,0.95)]" }) : null, !unlocked && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "absolute -bottom-1 right-0.5 px-1 rounded bg-[#141714]/95 border border-sky-400/50 text-[9px] font-mono font-bold text-sky-300 leading-tight",
												children: swatch.scrapCost
											})]
										}, swatch.hex);
									})
								}),
								!activeZoneUnlocked && activeZoneSwatch && activeZoneSwatch.scrapCost > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-2.5 bg-[#141714] border border-sky-400/40 rounded-xl p-2.5 flex items-center justify-between gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-2 min-w-0",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "w-5 h-5 rounded border border-white/25 shrink-0",
											style: { backgroundColor: activeZoneSwatch.hex }
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "min-w-0",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "text-xs font-bold text-[#F3EFE6] truncate",
												children: [activeZoneSwatch.name, " (Locked Paint)"]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "text-[11px] font-mono text-sky-300",
												children: [
													"Unlock permanently for ",
													activeZoneSwatch.scrapCost,
													" Scrap"
												]
											})]
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										disabled: progression.scrap < activeZoneSwatch.scrapCost,
										onClick: () => reportPurchase(onPurchasePaintColor(activeZoneSwatch.hex), activeZoneSwatch.name),
										className: `min-h-[40px] px-3 rounded-lg text-xs font-bold flex items-center gap-1.5 shrink-0 transition ${progression.scrap >= activeZoneSwatch.scrapCost ? "bg-sky-400 text-[#141714] hover:bg-sky-300" : "bg-[#1E221D] border border-[#F3EFE6]/15 text-[#F3EFE6]/45 cursor-not-allowed"}`,
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShoppingCart, { className: "w-3.5 h-3.5" }), progression.scrap >= activeZoneSwatch.scrapCost ? `Buy · ${activeZoneSwatch.scrapCost}` : `Need ${activeZoneSwatch.scrapCost - progression.scrap}`]
									})]
								})
							] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "bg-[#141714] border border-[#F3EFE6]/12 rounded-xl p-2.5 flex items-center justify-between gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-1.5 text-xs font-semibold text-[#F3EFE6]",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Custom Zone Color Studio" }), progression.customPaintUnlocked ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-[10px] font-mono uppercase text-[#86EFAC]",
										children: "Owned"
									}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "text-[10px] font-mono text-sky-300",
										children: [60, " Scrap"]
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-[11px] text-[#F3EFE6]/55",
									children: progression.customPaintUnlocked ? `Pick any custom hex for ${PAINT_ZONES.find((z) => z.key === activeZone)?.label}` : "Unlock full RGB color spectrum for all paint zones"
								})] }), progression.customPaintUnlocked ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "min-h-[44px] px-3 rounded-lg bg-[#1E221D] border border-[#F3EFE6]/20 hover:border-[#E08E26]/65 flex items-center gap-2 cursor-pointer transition shrink-0",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										type: "color",
										"aria-label": "Custom zone color picker",
										value: currentZoneHex,
										onChange: (e) => onChangeDraft({
											...draft,
											[activeZone]: normalizeHexColor(e.target.value, currentZoneHex),
											presetId: null
										}),
										className: "w-7 h-7 bg-transparent border-0 p-0 cursor-pointer"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-mono text-xs text-[#F3EFE6] tabular-nums",
										children: currentZoneHex
									})]
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									disabled: progression.scrap < 60,
									onClick: () => reportPurchase(onPurchaseCustomPaint(), "Custom Paint Studio"),
									className: `min-h-[42px] px-3 rounded-lg text-xs font-bold flex items-center gap-1.5 shrink-0 transition ${progression.scrap >= 60 ? "bg-sky-400 text-[#141714] hover:bg-sky-300" : "bg-[#1E221D] border border-[#F3EFE6]/15 text-[#F3EFE6]/45 cursor-not-allowed"}`,
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, { className: "w-3.5 h-3.5" }),
										"Unlock · ",
										60
									]
								})]
							})
						]
					}),
					subTab === "decals" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between mb-1.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-[11px] font-mono uppercase tracking-wider text-[#F3EFE6]/60",
									children: "Decal Placement"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: () => cycleDecal(-1),
										"aria-label": "Previous decal",
										className: "min-w-[36px] min-h-[36px] rounded-lg bg-[#141714] border border-[#F3EFE6]/15 flex items-center justify-center hover:border-[#E08E26]/65 transition",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "w-4 h-4" })
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: () => cycleDecal(1),
										"aria-label": "Next decal",
										className: "min-w-[36px] min-h-[36px] rounded-lg bg-[#141714] border border-[#F3EFE6]/15 flex items-center justify-center hover:border-[#E08E26]/65 transition",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "w-4 h-4" })
									})]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "grid grid-cols-4 gap-1.5",
								children: DECAL_POSITION_OPTIONS.map((pos) => {
									const active = draft.decalPosition === pos.id;
									return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: () => onChangeDraft({
											...draft,
											decalPosition: pos.id,
											presetId: null
										}),
										className: `min-h-[44px] px-2 rounded-lg border text-xs font-semibold transition ${active ? "bg-[#252B23] border-[#E08E26] text-[#F3EFE6]" : "bg-[#141714] border-[#F3EFE6]/12 text-[#F3EFE6]/70 hover:border-[#F3EFE6]/30"}`,
										children: pos.shortLabel
									}, pos.id);
								})
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex flex-wrap gap-1.5",
								children: DECAL_CATEGORIES.map((cat) => {
									return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: () => setDecalCategory(cat),
										className: `min-h-[36px] px-2.5 rounded-lg border text-[11px] font-semibold transition ${decalCategory === cat ? "bg-[#E08E26]/20 border-[#E08E26] text-[#FDE68A]" : "bg-[#141714] border-[#F3EFE6]/12 text-[#F3EFE6]/65 hover:text-[#F3EFE6]"}`,
										children: cat
									}, cat);
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "grid grid-cols-3 sm:grid-cols-4 gap-1.5",
								children: filteredDecals.map((decal) => {
									const active = draft.decalId === decal.id;
									const unlocked = isDecalUnlocked(progression, decal.id);
									const cost = decal.scrapCost ?? 0;
									return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										title: decal.description,
										onClick: () => onChangeDraft({
											...draft,
											decalId: decal.id,
											presetId: null
										}),
										className: `relative min-h-[60px] p-2 rounded-xl border flex flex-col items-center justify-center gap-1 transition ${active ? "bg-[#252B23] border-[#E08E26] shadow" : "bg-[#141714] border-[#F3EFE6]/12 hover:border-[#F3EFE6]/30"}`,
										children: [
											!unlocked && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "absolute top-1 right-1 inline-flex items-center gap-0.5 px-1 rounded bg-[#1E221D] border border-sky-400/40 text-[9px] font-mono font-bold text-sky-300",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, { className: "w-2 h-2" }), cost]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TankDecalIcon, {
												decalId: decal.id,
												color: decal.id === "none" ? "#F3EFE6" : draft.decalColor,
												size: 22
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-[10px] font-semibold text-[#F3EFE6]/85 truncate w-full text-center",
												children: decal.name
											})
										]
									}, decal.id);
								})
							}),
							!activeDecalUnlocked && activeDecalDef && (activeDecalDef.scrapCost ?? 0) > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "bg-[#141714] border border-sky-400/40 rounded-xl p-2.5 flex items-center justify-between gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-2.5 min-w-0",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "w-8 h-8 rounded-lg bg-[#1E221D] border border-[#F3EFE6]/15 flex items-center justify-center shrink-0",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TankDecalIcon, {
											decalId: activeDecalDef.id,
											color: draft.decalColor,
											size: 20
										})
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "min-w-0",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "text-xs font-bold text-[#F3EFE6] truncate",
											children: [activeDecalDef.name, " (Locked Decal)"]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "text-[11px] font-mono text-sky-300",
											children: [
												"Unlock permanently for ",
												activeDecalDef.scrapCost,
												" Scrap"
											]
										})]
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									disabled: progression.scrap < (activeDecalDef.scrapCost ?? 0),
									onClick: () => reportPurchase(onPurchaseDecal(activeDecalDef.id), activeDecalDef.name),
									className: `min-h-[40px] px-3 rounded-lg text-xs font-bold flex items-center gap-1.5 shrink-0 transition ${progression.scrap >= (activeDecalDef.scrapCost ?? 0) ? "bg-sky-400 text-[#141714] hover:bg-sky-300" : "bg-[#1E221D] border border-[#F3EFE6]/15 text-[#F3EFE6]/45 cursor-not-allowed"}`,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShoppingCart, { className: "w-3.5 h-3.5" }), progression.scrap >= (activeDecalDef.scrapCost ?? 0) ? `Buy · ${activeDecalDef.scrapCost}` : `Need ${(activeDecalDef.scrapCost ?? 0) - progression.scrap}`]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-2 bg-[#141714] border border-[#F3EFE6]/12 rounded-xl p-2.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between gap-2 flex-wrap",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "flex items-center gap-1.5 flex-wrap",
										children: DECAL_COLOR_SWATCHES.map((swatch) => {
											const active = swatch.hex.toUpperCase() === currentDecalHex;
											const unlocked = isPaintColorUnlocked(progression, swatch.hex, tank);
											return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												type: "button",
												title: unlocked ? swatch.name : `${swatch.name} (${swatch.scrapCost} Scrap)`,
												"aria-label": `Decal color ${swatch.name}`,
												onClick: () => onChangeDraft({
													...draft,
													decalColor: swatch.hex.toUpperCase(),
													presetId: null
												}),
												className: `relative w-9 h-9 rounded-lg border-2 flex items-center justify-center transition ${active ? "border-[#E08E26] scale-105" : "border-[#2A2E29] hover:border-[#F3EFE6]/50"}`,
												style: { backgroundColor: swatch.hex },
												children: active ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "w-3.5 h-3.5 text-white drop-shadow-[0_1px_2px_rgba(0,0,0,0.95)] stroke-[3]" }) : !unlocked ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, { className: "w-3 h-3 text-white drop-shadow-[0_1px_2px_rgba(0,0,0,0.95)]" }) : null
											}, swatch.hex);
										})
									}), progression.customPaintUnlocked && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
										className: "min-h-[40px] px-2.5 rounded-lg bg-[#1E221D] border border-[#F3EFE6]/18 flex items-center gap-1.5 cursor-pointer",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											type: "color",
											"aria-label": "Custom decal color",
											value: currentDecalHex,
											onChange: (e) => onChangeDraft({
												...draft,
												decalColor: normalizeHexColor(e.target.value, draft.decalColor),
												presetId: null
											}),
											className: "w-6 h-6 bg-transparent border-0 p-0 cursor-pointer"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-[11px] font-mono text-[#F3EFE6]/85",
											children: "Custom"
										})]
									})]
								}), !activeDecalColorUnlocked && activeDecalSwatch && activeDecalSwatch.scrapCost > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "pt-2 border-t border-[#F3EFE6]/10 flex items-center justify-between gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "text-[11px] font-mono text-sky-300",
										children: [
											activeDecalSwatch.name,
											" Decal Ink · ",
											activeDecalSwatch.scrapCost,
											" Scrap"
										]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										disabled: progression.scrap < activeDecalSwatch.scrapCost,
										onClick: () => reportPurchase(onPurchasePaintColor(activeDecalSwatch.hex), activeDecalSwatch.name),
										className: `min-h-[34px] px-2.5 rounded-lg text-xs font-bold flex items-center gap-1 transition ${progression.scrap >= activeDecalSwatch.scrapCost ? "bg-sky-400 text-[#141714] hover:bg-sky-300" : "bg-[#1E221D] border border-[#F3EFE6]/15 text-[#F3EFE6]/45 cursor-not-allowed"}`,
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShoppingCart, { className: "w-3 h-3" }),
											"Buy · ",
											activeDecalSwatch.scrapCost
										]
									})]
								})]
							})
						]
					}),
					subTab === "skins" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-[11px] font-mono uppercase tracking-wider text-[#F3EFE6]/60",
							children: "Special Appearances & Workshop Skins (All Tanks · Visual Only)"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid grid-cols-1 sm:grid-cols-2 gap-2",
							children: COSMETIC_LIST.map((skin) => {
								const unlocked = isSpecialCosmeticUnlocked(progression, skin.id);
								const equipped = progression.equippedCosmetic === skin.id;
								const cost = skin.scrapCost ?? 0;
								const isShopSkin = !unlocked && cost > 0;
								const affordable = progression.scrap >= cost;
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: `rounded-xl p-2.5 border flex items-center gap-2.5 transition ${equipped ? "bg-[#252B23] border-[#E08E26]" : unlocked ? "bg-[#141714] border-[#F3EFE6]/15" : "bg-[#141714]/80 border-[#F3EFE6]/10"}`,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TankPreviewSvg, {
										tank,
										cosmeticId: skin.id,
										size: 48,
										className: "shrink-0"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "min-w-0 flex-1",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "text-xs font-bold text-[#F3EFE6] truncate",
												children: skin.name
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "text-[10px] text-[#F3EFE6]/60 line-clamp-2 leading-snug mt-0.5",
												children: skin.description
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "mt-1.5",
												children: equipped ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
													className: "inline-flex items-center gap-1 px-2 py-0.5 rounded bg-[#E08E26] text-[#141714] text-[10px] font-mono font-bold uppercase",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "w-2.5 h-2.5 stroke-[3]" }), "Equipped"]
												}) : unlocked ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
													type: "button",
													onClick: () => onEquipCosmetic(skin.id),
													className: "min-h-[32px] px-2.5 rounded-lg bg-[#22C55E]/15 border border-[#22C55E]/40 text-[#86EFAC] text-[11px] font-bold hover:bg-[#22C55E]/25 transition",
													children: "Equip Base Skin"
												}) : isShopSkin ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
													type: "button",
													disabled: !affordable,
													onClick: () => {
														const outcome = onPurchaseCosmetic(skin.id);
														reportPurchase(outcome, skin.name);
														if (outcome.success) onEquipCosmetic(skin.id);
													},
													className: `min-h-[32px] px-2.5 rounded-lg text-[11px] font-bold inline-flex items-center gap-1 transition ${affordable ? "bg-sky-400 text-[#141714] hover:bg-sky-300" : "bg-[#1E221D] border border-[#F3EFE6]/15 text-[#F3EFE6]/45 cursor-not-allowed"}`,
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Hexagon, { className: "w-3 h-3" }), affordable ? `Buy · ${cost} Scrap` : `Need ${cost - progression.scrap} Scrap`]
												}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
													className: "inline-flex items-center gap-1 px-2 py-0.5 rounded bg-[#1E221D] text-[10px] font-mono text-[#F3EFE6]/60",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, { className: "w-2.5 h-2.5" }), skin.unlockSourceLabel ?? `Level ${skin.unlockLevel}`]
												})
											})
										]
									})]
								}, skin.id);
							})
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "pt-2 border-t border-[#F3EFE6]/10 space-y-2 shrink-0",
				children: [lockedItems.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center justify-between gap-2 rounded-lg bg-[#141714] border border-sky-400/35 px-3 py-1.5 text-[11px] text-sky-300",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "truncate",
						children: ["Locked preview: ", lockedItems.join(", ")]
					}), matchingPreset && !isPresetUnlocked(progression, matchingPreset.id) && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						disabled: progression.scrap < (matchingPreset.scrapCost ?? 0),
						onClick: () => {
							const outcome = onPurchasePreset(matchingPreset.id);
							reportPurchase(outcome, matchingPreset.name);
						},
						className: "px-2.5 py-1 rounded bg-sky-400 text-[#141714] font-bold disabled:opacity-45 shrink-0",
						children: [
							"Unlock · ",
							matchingPreset.scrapCost,
							" Scrap"
						]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center justify-between gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: `text-[11px] font-mono uppercase tracking-wider ${lockedItems.length > 0 ? "text-sky-300 font-bold" : hasUnappliedChanges ? "text-[#E08E26] font-bold" : appliedCustomization ? "text-emerald-400" : "text-[#F3EFE6]/50"}`,
						children: lockedItems.length > 0 ? "Unlock Preview Items to Apply" : hasUnappliedChanges ? "Unapplied Preview" : appliedCustomization ? "Saved Customization" : "Factory Default"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2 ml-auto",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: onReset,
							disabled: isDefaultLook,
							className: "min-h-[44px] px-3 rounded-xl bg-[#141714] border border-[#F3EFE6]/18 text-xs font-semibold flex items-center gap-1.5 text-[#F3EFE6]/80 hover:border-[#F3EFE6]/45 disabled:opacity-40 disabled:cursor-not-allowed transition whitespace-nowrap",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { className: "w-3.5 h-3.5" }), "Reset Customization"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: onApply,
							disabled: lockedItems.length > 0 || !hasUnappliedChanges && appliedCustomization !== null,
							className: `min-h-[44px] px-4 rounded-xl text-xs sm:text-sm font-bold flex items-center gap-1.5 transition whitespace-nowrap disabled:opacity-45 disabled:cursor-not-allowed ${hasUnappliedChanges && lockedItems.length === 0 ? "bg-[#22C55E] text-[#141714] hover:bg-[#4ADE80] shadow" : "bg-[#272D25] border border-[#F3EFE6]/20 text-[#F3EFE6]/85 hover:bg-[#31382E]"}`,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "w-4 h-4 stroke-[2.6]" }), hasUnappliedChanges ? "Apply & Save" : "Applied"]
						})]
					})]
				})]
			})
		]
	});
}
// src/ui/GarageScreen.tsx
function GarageScreen({ progression, sessionCustomizations, onApplyCustomization, onResetCustomization, onSelectTank, onPurchaseTank, onPurchasePreset, onPurchasePaintColor, onPurchaseCustomPaint, onPurchaseDecal, onPurchaseCosmetic, onEquipCosmetic, onOpenCollection, onBack, onStartBattle }) {
	const [inspectedId, setInspectedId] = (0, import_react.useState)(progression.selectedTank);
	const [rightMode, setRightMode] = (0, import_react.useState)("customize");
	const [hullAngleDeg, setHullAngleDeg] = (0, import_react.useState)(-24);
	const [turretOffsetDeg, setTurretOffsetDeg] = (0, import_react.useState)(0);
	const dragStartRef = (0, import_react.useRef)(null);
	const availableTanks = TANK_LIST;
	const tank = TANK_DEFINITIONS[inspectedId] || availableTanks[0] || TANK_DEFINITIONS.assault;
	const tankUnlocked = isTankUnlocked(progression, tank.id);
	const isSelected = tankUnlocked && progression.selectedTank === tank.id;
	const appliedCustomization = sessionCustomizations?.[tank.id] ?? progression.tankCustomizations?.[tank.id] ?? null;
	const [draftCustomization, setDraftCustomization] = (0, import_react.useState)(() => {
		return sessionCustomizations?.[inspectedId] ?? progression.tankCustomizations?.[inspectedId] ?? createDefaultTankCustomization(tank, progression.equippedCosmetic);
	});
	(0, import_react.useEffect)(() => {
		setDraftCustomization(appliedCustomization ?? createDefaultTankCustomization(tank, progression.equippedCosmetic));
	}, [
		appliedCustomization,
		progression.equippedCosmetic,
		tank
	]);
	const effectiveDefault = (0, import_react.useMemo)(() => createDefaultTankCustomization(tank, progression.equippedCosmetic), [progression.equippedCosmetic, tank]);
	const isPreviewingUnapplied = rightMode === "customize" && !areCustomizationsEqual(draftCustomization, appliedCustomization ?? effectiveDefault);
	const previewCustomization = rightMode === "customize" ? draftCustomization : appliedCustomization;
	const effectiveMaxHp = getEffectiveTankMaxHp(tank);
	const effectiveSpeed = getEffectiveTankMoveSpeed(tank);
	const effectiveRange = getEffectiveTankProjectileRange(tank);
	const effectiveReload = getEffectiveTankReloadSec(tank);
	const currentIdx = availableTanks.findIndex((t) => t.id === tank.id);
	const cycleTank = (dir) => {
		const nextIdx = ((currentIdx >= 0 ? currentIdx : 0) + dir + availableTanks.length) % availableTanks.length;
		setInspectedId(availableTanks[nextIdx].id);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "w-full h-full overflow-y-auto bg-[#141714] tactical-bg-grid text-[#F3EFE6] flex flex-col",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
			className: "w-full max-w-6xl mx-auto px-4 sm:px-7 py-3 flex flex-wrap items-center justify-between gap-3 border-b border-[#F3EFE6]/12 shrink-0 bg-[#141714]/80",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: onBack,
					className: "min-h-[44px] px-3.5 rounded-xl border border-[#F3EFE6]/20 bg-[#1E221D] flex items-center gap-1.5 text-sm font-semibold hover:bg-[#282D26] transition whitespace-nowrap",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "w-4 h-4" }), "Back"]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-2xl sm:text-3xl font-extrabold tracking-wide leading-none",
					children: "Garage & Cosmetic Shop"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[11px] text-[#F3EFE6]/55 mt-0.5",
					children: "Customize paint, decals, presets & skins · Drag preview to rotate hull"
				})] })]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-2.5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScrapBadge, { scrap: progression.scrap }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: onOpenCollection,
					className: "min-h-[44px] px-3.5 sm:px-4 rounded-xl bg-[#1E221D] border border-[#F3EFE6]/20 text-xs sm:text-sm font-semibold flex items-center gap-2 hover:border-[#E08E26]/65 hover:bg-[#262C24] transition whitespace-nowrap",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Layers, { className: "w-4 h-4 text-[#E08E26]" }), "Tank Shop"]
				})]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
			className: "screen-transition flex-1 w-full max-w-6xl mx-auto px-4 sm:px-7 py-3.5 sm:py-5 grid grid-cols-1 landscape:grid-cols-12 lg:grid-cols-12 gap-4 sm:gap-5 items-stretch",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "landscape:col-span-5 lg:col-span-5 bg-[#1B1F1A]/95 border border-[#F3EFE6]/15 rounded-2xl p-4 sm:p-5 flex flex-col justify-between gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => cycleTank(-1),
								"aria-label": "Previous tank",
								className: "min-w-[44px] min-h-[44px] rounded-xl bg-[#141714] border border-[#F3EFE6]/18 flex items-center justify-center hover:border-[#E08E26]/60 transition",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "w-5 h-5" })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "text-center min-w-0",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-[11px] font-mono uppercase tracking-wider text-[#E08E26]",
									children: tank.role
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "font-display text-2xl sm:text-3xl font-extrabold text-[#F3EFE6] leading-none truncate",
									children: tank.name
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => cycleTank(1),
								"aria-label": "Next tank",
								className: "min-w-[44px] min-h-[44px] rounded-xl bg-[#141714] border border-[#F3EFE6]/18 flex items-center justify-center hover:border-[#E08E26]/60 transition",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "w-5 h-5" })
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						role: "region",
						"aria-label": `${tank.name} rotatable preview`,
						className: "touch-none-game relative flex-1 min-h-[205px] sm:min-h-[260px] rounded-xl bg-[#141714] border border-[#F3EFE6]/12 flex items-center justify-center overflow-hidden cursor-grab active:cursor-grabbing select-none",
						onPointerDown: (e) => {
							e.currentTarget.setPointerCapture(e.pointerId);
							dragStartRef.current = {
								x: e.clientX,
								startAngle: hullAngleDeg
							};
						},
						onPointerMove: (e) => {
							if (!dragStartRef.current) return;
							const dx = e.clientX - dragStartRef.current.x;
							setHullAngleDeg(dragStartRef.current.startAngle + dx * .75);
						},
						onPointerUp: (e) => {
							if (e.currentTarget.hasPointerCapture(e.pointerId)) e.currentTarget.releasePointerCapture(e.pointerId);
							dragStartRef.current = null;
						},
						onPointerCancel: () => {
							dragStartRef.current = null;
						},
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								"aria-hidden": "true",
								className: "pointer-events-none absolute w-52 h-52 sm:w-64 sm:h-64 rounded-full border border-dashed border-[#E08E26]/25"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								"aria-hidden": "true",
								className: "pointer-events-none absolute w-36 h-36 sm:w-44 sm:h-44 rounded-full border border-[#F3EFE6]/10"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TankPreviewSvg, {
								tank,
								cosmeticId: progression.equippedCosmetic,
								customization: previewCustomization,
								size: 208,
								hullAngleDeg,
								turretAngleDeg: hullAngleDeg + turretOffsetDeg,
								className: "pointer-events-none drop-shadow-2xl"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "pointer-events-none absolute top-3 left-3 flex flex-wrap items-center gap-1.5",
								children: [!tankUnlocked ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "inline-flex items-center gap-1 rounded-md bg-[#141714]/95 border border-sky-400/50 text-sky-300 px-2.5 py-0.5 text-[11px] font-bold uppercase tracking-wide",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, { className: "w-3 h-3" }),
										"Locked · ",
										tank.unlockCost,
										" Scrap"
									]
								}) : isSelected ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "inline-flex items-center gap-1 rounded-md bg-[#22C55E] text-[#141714] px-2.5 py-0.5 text-[11px] font-bold uppercase tracking-wide",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "w-3.5 h-3.5 stroke-[3]" }), "Selected"]
								}) : null, isPreviewingUnapplied && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "inline-flex items-center gap-1 rounded-md bg-[#E08E26] text-[#141714] px-2.5 py-0.5 text-[11px] font-bold uppercase tracking-wide",
									children: "Preview"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "pointer-events-none absolute bottom-2.5 right-3 text-[10px] font-mono text-[#F3EFE6]/45 tabular-nums",
								children: [
									"Hull ",
									Math.round((hullAngleDeg % 360 + 360) % 360),
									"° · Turret",
									" ",
									Math.round(((hullAngleDeg + turretOffsetDeg) % 360 + 360) % 360),
									"°"
								]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-center justify-between gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => setHullAngleDeg((a) => a - 45),
								className: "min-h-[44px] px-3 rounded-lg bg-[#141714] border border-[#F3EFE6]/18 text-xs font-semibold flex items-center gap-1.5 hover:border-[#E08E26]/60 transition",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { className: "w-3.5 h-3.5" }), "-45°"]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => setHullAngleDeg((a) => a + 45),
								className: "min-h-[44px] px-3 rounded-lg bg-[#141714] border border-[#F3EFE6]/18 text-xs font-semibold flex items-center gap-1.5 hover:border-[#E08E26]/60 transition",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCw, { className: "w-3.5 h-3.5" }), "+45°"]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => setTurretOffsetDeg((o) => (o + 45) % 360),
								className: "min-h-[44px] px-3 rounded-lg bg-[#141714] border border-[#F3EFE6]/18 text-xs font-semibold hover:border-[#E08E26]/60 transition whitespace-nowrap",
								children: "Aim Turret +45°"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => {
									setHullAngleDeg(-24);
									setTurretOffsetDeg(0);
								},
								className: "min-h-[44px] px-3 rounded-lg bg-[#141714] border border-[#F3EFE6]/18 text-xs font-medium text-[#F3EFE6]/75 hover:text-[#F3EFE6] transition",
								children: "Center"
							})]
						})]
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
				className: "landscape:col-span-7 lg:col-span-7 bg-[#1B1F1A]/95 border border-[#F3EFE6]/15 rounded-2xl p-4 sm:p-5 flex flex-col justify-between gap-3.5 min-h-0",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between gap-2 shrink-0",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-2 gap-1.5 bg-[#141714] p-1 rounded-xl border border-[#F3EFE6]/12 w-full sm:w-auto sm:min-w-[270px]",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => setRightMode("customize"),
								className: `min-h-[44px] px-4 rounded-lg text-xs sm:text-sm font-bold flex items-center justify-center gap-2 transition ${rightMode === "customize" ? "bg-[#E08E26] text-[#141714] shadow" : "text-[#F3EFE6]/75 hover:text-[#F3EFE6]"}`,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Palette, { className: "w-4 h-4" }), "Customize"]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => setRightMode("inspect"),
								className: `min-h-[44px] px-4 rounded-lg text-xs sm:text-sm font-bold flex items-center justify-center gap-2 transition ${rightMode === "inspect" ? "bg-[#E08E26] text-[#141714] shadow" : "text-[#F3EFE6]/75 hover:text-[#F3EFE6]"}`,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SlidersVertical, { className: "w-4 h-4" }), "Specs & Abilities"]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "hidden sm:inline-block text-[11px] font-mono text-[#F3EFE6]/50",
							children: [
								currentIdx + 1,
								" / ",
								availableTanks.length,
								" Tanks"
							]
						})]
					}),
					rightMode === "customize" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TankCustomizationPanel, {
						tank,
						progression,
						draft: draftCustomization,
						appliedCustomization,
						onChangeDraft: setDraftCustomization,
						onApply: () => {
							onApplyCustomization(tank.id, draftCustomization);
						},
						onReset: () => {
							onResetCustomization(tank.id);
							setDraftCustomization(createDefaultTankCustomization(tank, progression.equippedCosmetic));
						},
						onPurchasePreset,
						onPurchasePaintColor,
						onPurchaseCustomPaint,
						onPurchaseDecal,
						onPurchaseCosmetic,
						onEquipCosmetic
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex-1 min-h-0 overflow-y-auto pr-0.5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs sm:text-sm text-[#F3EFE6]/75 leading-relaxed",
								children: tank.description
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-3 gap-2 mt-3.5 font-mono tabular-nums text-xs",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "bg-[#141714] border border-[#F3EFE6]/10 rounded-xl px-3 py-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "text-[10px] font-sans text-[#F3EFE6]/55",
											children: "Health"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "text-sm font-bold text-[#F3EFE6] mt-0.5",
											children: [effectiveMaxHp, " HP"]
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "bg-[#141714] border border-[#F3EFE6]/10 rounded-xl px-3 py-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "text-[10px] font-sans text-[#F3EFE6]/55",
											children: "Move Speed"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "text-sm font-bold text-[#F3EFE6] mt-0.5",
											children: effectiveSpeed
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "bg-[#141714] border border-[#F3EFE6]/10 rounded-xl px-3 py-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "text-[10px] font-sans text-[#F3EFE6]/55",
											children: "Proj. Range"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "text-sm font-bold text-[#F3EFE6] mt-0.5",
											children: effectiveRange
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "bg-[#141714] border border-[#F3EFE6]/10 rounded-xl px-3 py-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "text-[10px] font-sans text-[#F3EFE6]/55",
											children: "Magazine"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "text-sm font-bold text-[#E08E26] mt-0.5",
											children: [tank.stats.magazineCapacity, " Rounds"]
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "bg-[#141714] border border-[#F3EFE6]/10 rounded-xl px-3 py-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "text-[10px] font-sans text-[#F3EFE6]/55",
											children: "Reload"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "text-sm font-bold text-emerald-400 mt-0.5",
											children: [effectiveReload.toFixed(2), "s"]
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "bg-[#141714] border border-[#F3EFE6]/10 rounded-xl px-3 py-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "text-[10px] font-sans text-[#F3EFE6]/55",
											children: "Shell Damage"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "text-sm font-bold text-[#F3EFE6] mt-0.5",
											children: tank.stats.projectileDamage
										})]
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-col gap-2.5 mt-3.5 text-xs",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "bg-[#141714] border border-[#F3EFE6]/10 rounded-xl p-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center justify-between font-semibold text-[#E08E26]",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "inline-flex items-center gap-1.5",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Zap, { className: "w-3.5 h-3.5" }),
												"Active: ",
												tank.activeAbility.name
											]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "font-mono tabular-nums text-[#F3EFE6]/65",
											children: [tank.activeAbility.cooldownSec, "s CD"]
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-[#F3EFE6]/75 mt-1 leading-relaxed",
										children: tank.activeAbility.description
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "bg-[#141714] border border-[#F3EFE6]/10 rounded-xl p-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "inline-flex items-center gap-1.5 font-semibold text-emerald-400",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shield, { className: "w-3.5 h-3.5" }),
											"Passive: ",
											tank.passiveAbility.name
										]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-[#F3EFE6]/75 mt-1 leading-relaxed",
										children: tank.passiveAbility.description
									})]
								})]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex flex-wrap items-center gap-2.5 pt-1 border-t border-[#F3EFE6]/10 shrink-0",
						children: !tankUnlocked ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							disabled: progression.scrap < tank.unlockCost,
							onClick: () => onPurchaseTank(tank.id),
							className: `min-h-[48px] flex-1 px-5 rounded-xl font-display text-lg font-extrabold tracking-wide flex items-center justify-center gap-2 transition whitespace-nowrap ${progression.scrap >= tank.unlockCost ? "bg-sky-400 text-[#141714] hover:bg-sky-300 shadow-lg" : "bg-[#141714] border border-[#F3EFE6]/15 text-[#F3EFE6]/45 cursor-not-allowed"}`,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShoppingCart, { className: "w-4 h-4" }), progression.scrap >= tank.unlockCost ? `Unlock ${tank.name} · ${tank.unlockCost} Scrap` : `Need ${tank.unlockCost - progression.scrap} More Scrap`]
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => onSelectTank(tank.id),
							className: `min-h-[48px] flex-1 px-4 rounded-xl font-semibold text-sm flex items-center justify-center gap-2 transition whitespace-nowrap ${isSelected ? "bg-[#22C55E]/20 border-2 border-[#22C55E] text-[#86EFAC]" : "bg-[#272D25] border border-[#F3EFE6]/25 text-[#F3EFE6] hover:bg-[#31382E]"}`,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "w-4 h-4" }), isSelected ? "Selected" : "SELECT"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => {
								onSelectTank(tank.id);
								onStartBattle(tank.id);
							},
							className: "min-h-[48px] flex-1 px-5 rounded-xl bg-[#E08E26] text-[#141714] font-display text-xl font-extrabold tracking-wide flex items-center justify-center gap-2 hover:bg-[#EE9B32] transition whitespace-nowrap",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "w-4 h-4 fill-current" }), "Play Match"]
						})] })
					})
				]
			})]
		})]
	});
}
// src/ui/HowToPlayScreen.tsx
var OBSTACLE_GUIDE = [
	{
		name: "Brick Barrier",
		rule: "Destructible cover. Absorbs shells until shattered.",
		swatch: "#A84B36"
	},
	{
		name: "Steel Barrier",
		rule: "Indestructible armor wall. Blocks both movement and fire.",
		swatch: "#646D75"
	},
	{
		name: "Wooden Crate",
		rule: "Light destructible cover that clears quickly under fire.",
		swatch: "#B57B42"
	},
	{
		name: "Brush & Bushes",
		rule: "Conceals your tank from enemies unless revealed by Radar.",
		swatch: "#4A8544"
	},
	{
		name: "Water Pool",
		rule: "Blocks tank treads, but cannon shells fly cleanly over.",
		swatch: "#387D9C"
	},
	{
		name: "Explosive Barrel",
		rule: "Detonates on destruction, damaging nearby tanks and walls.",
		swatch: "#C93A2B"
	}
];
function HowToPlayScreen({ onBack }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "w-full h-full overflow-y-auto bg-[#161915] text-[#F3EFE6] flex flex-col",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
			className: "w-full max-w-5xl mx-auto px-4 sm:px-8 py-3.5 flex items-center justify-between border-b border-[#F3EFE6]/10 shrink-0",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: onBack,
					className: "min-h-[44px] px-3 rounded-lg border border-[#F3EFE6]/20 flex items-center gap-1.5 text-sm font-medium hover:bg-[#232721] transition whitespace-nowrap",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "w-4 h-4" }), "Back"]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-2xl sm:text-3xl font-extrabold tracking-wide",
					children: "How to Play"
				})]
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
			className: "flex-1 w-full max-w-5xl mx-auto px-4 sm:px-8 py-5 flex flex-col gap-5",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-1 md:grid-cols-2 gap-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "bg-[#1E221D] border border-[#F3EFE6]/12 rounded-xl p-4 sm:p-5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
							className: "font-display text-xl font-bold flex items-center gap-2 mb-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Crosshair, { className: "w-5 h-5 text-[#E08E26]" }), "Controls"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
							className: "space-y-2 text-xs sm:text-sm text-[#F3EFE6]/80 leading-relaxed",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
									className: "text-[#F3EFE6]",
									children: "Touchscreen (Landscape):"
								}),
								" Use the left joystick to drive in any direction and the right joystick to rotate your turret independently. Tap ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "FIRE" }),
								" to shoot, ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "RELOAD" }),
								" to reload early, ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "ABILITY" }),
								" to trigger your tank special, and ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "MINE" }),
								" when holding Mine Kit charges."
							] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
									className: "text-[#F3EFE6]",
									children: "Keyboard & Mouse:"
								}),
								" Move with ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "WASD" }),
								" or ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Arrow Keys" }),
								", aim with the mouse cursor, shoot with ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Left Click" }),
								" or ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Space" }),
								", reload with ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "R" }),
								", activate ability with ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "E" }),
								" or ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Shift" }),
								", drop mines with ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "F" }),
								" or ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Q" }),
								", and pause with ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "P" }),
								" or ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Esc" }),
								"."
							] })]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "bg-[#1E221D] border border-[#F3EFE6]/12 rounded-xl p-4 sm:p-5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
							className: "font-display text-xl font-bold flex items-center gap-2 mb-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trophy, { className: "w-5 h-5 text-[#E08E26]" }), "Match Rules & Victory"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
							className: "space-y-2 text-xs sm:text-sm text-[#F3EFE6]/80 leading-relaxed",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Eight tanks enter each Free-for-All match (1 human commander vs 7 autonomous AI opponents)." }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
									"Be the last surviving tank to claim ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Victory" }),
									". If the match clock expires first, the survivor with the highest remaining HP wins (eliminations break ties)."
								] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
									"All six tank classes are ready to deploy in the ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Garage" }),
									" and ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Tank Collection" }),
									"; matches also tally ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Scrap" }),
									" based on placement and eliminations."
								] })
							]
						})]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "bg-[#1E221D] border border-[#F3EFE6]/12 rounded-xl p-4 sm:p-5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
						className: "font-display text-xl font-bold flex items-center gap-2 mb-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shield, { className: "w-5 h-5 text-[#E08E26]" }), "Arena Obstacles & Terrain"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3",
						children: OBSTACLE_GUIDE.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "bg-[#161915] border border-[#F3EFE6]/10 rounded-lg p-3 flex items-start gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "w-5 h-5 rounded-sm border border-[#141714] shrink-0 mt-0.5",
								style: { backgroundColor: item.swatch }
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-xs font-bold text-[#F3EFE6]",
								children: item.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-xs text-[#F3EFE6]/70 mt-0.5 leading-snug",
								children: item.rule
							})] })]
						}, item.name))
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "bg-[#1E221D] border border-[#F3EFE6]/12 rounded-xl p-4 sm:p-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
							className: "font-display text-xl font-bold flex items-center gap-2 mb-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "w-5 h-5 text-[#E08E26]" }), "Field Powerups (Max 3 Active on Map)"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid grid-cols-1 sm:grid-cols-2 gap-2.5",
							children: POWERUP_IDS.map((id) => {
								const p = POWERUP_DEFINITIONS[id];
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "bg-[#161915] border border-[#F3EFE6]/10 rounded-lg px-3 py-2.5 flex items-center gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "w-9 h-9 rounded-md border border-[#141714] flex items-center justify-center font-display text-xs font-extrabold text-[#141714] shrink-0",
										style: { backgroundColor: p.color },
										children: p.shortLabel
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "min-w-0",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "text-xs font-bold text-[#F3EFE6] flex items-center gap-1.5",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: p.name }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-[#F3EFE6]/45 font-mono text-[11px]",
												children: p.durationSec > 0 ? `${p.durationSec}s` : "Instant"
											})]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "text-xs text-[#F3EFE6]/70 truncate",
											children: p.description
										})]
									})]
								}, id);
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-xs text-[#F3EFE6]/55 mt-3 flex items-center gap-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Flame, { className: "w-3.5 h-3.5 text-[#E08E26]" }), "Picking up a duplicate temporary powerup refreshes its timer."]
						})
					]
				})
			]
		})]
	});
}
// src/ui/LevelUpModal.tsx
function LevelUpModal({ summary, activeTankId, onDismiss }) {
	const tank = TANK_DEFINITIONS[activeTankId] || TANK_DEFINITIONS.assault;
	const xpPct = Math.max(0, Math.min(100, summary.newXp / Math.max(1, summary.newXpToNext) * 100));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		role: "dialog",
		"aria-modal": "true",
		"aria-labelledby": "levelup-modal-title",
		className: "fixed inset-0 z-40 bg-[#141714]/82 backdrop-blur-sm flex items-center justify-center p-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "levelup-pop relative w-full max-w-md bg-[#1E221D] border-2 border-[#E08E26] rounded-2xl p-5 sm:p-6 text-[#F3EFE6] shadow-2xl",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: onDismiss,
					"aria-label": "Dismiss level up notification",
					className: "absolute top-3.5 right-3.5 min-w-[40px] min-h-[40px] rounded-xl bg-[#141714] border border-[#F3EFE6]/15 text-[#F3EFE6]/75 hover:text-[#F3EFE6] hover:border-[#E08E26]/60 flex items-center justify-center transition",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X$1, { className: "w-4 h-4" })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col items-center text-center",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "relative w-16 h-16 rounded-2xl bg-[#E08E26]/20 border-2 border-[#E08E26] text-[#E08E26] flex items-center justify-center mb-3 shadow-lg",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Star, { className: "w-8 h-8 fill-current" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "absolute -bottom-2 px-2 py-0.5 rounded-md bg-[#E08E26] text-[#141714] font-mono text-[10px] font-extrabold uppercase tracking-wider",
								children: [
									"+",
									summary.levelsGained,
									" ",
									summary.levelsGained === 1 ? "LVL" : "LVLS"
								]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "inline-flex items-center gap-1.5 text-[11px] font-mono uppercase tracking-[0.2em] text-[#E08E26]",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "w-3.5 h-3.5" }), "Promotion Achieved"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
							id: "levelup-modal-title",
							className: "font-display text-3xl sm:text-4xl font-extrabold tracking-wide text-[#F3EFE6] mt-0.5",
							children: [
								"Level ",
								summary.newLevel,
								" Reached!"
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-xs font-mono text-[#F3EFE6]/70 mt-1 tabular-nums",
							children: [
								"Level ",
								summary.previousLevel,
								" → Level ",
								summary.newLevel,
								" · +",
								summary.xpBreakdown.totalXp,
								" XP Earned"
							]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 bg-[#141714] border border-[#F3EFE6]/12 rounded-xl p-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between text-xs font-mono tabular-nums mb-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "text-[#E08E26] font-bold",
							children: [
								"Level ",
								summary.newLevel,
								" Progress"
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "text-[#F3EFE6]/75",
							children: [
								summary.newXp,
								" / ",
								summary.newXpToNext,
								" XP"
							]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "w-full h-2.5 rounded-full bg-[#1E221D] overflow-hidden border border-[#F3EFE6]/10",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "h-full bg-[#E08E26] transition-all duration-500",
							style: { width: `${xpPct}%` }
						})
					})]
				}),
				summary.unlockedMilestones.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "text-[11px] font-mono uppercase tracking-wider text-[#22C55E] mb-2 flex items-center gap-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Award, { className: "w-3.5 h-3.5" }), "Milestone Rewards Unlocked"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex flex-col gap-2 max-h-48 overflow-y-auto pr-0.5",
						children: summary.unlockedMilestones.map((m) => {
							const cosmetic = m.cosmeticId ? COSMETIC_DEFINITIONS[m.cosmeticId] : null;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "bg-[#141714] border border-[#22C55E]/35 rounded-xl p-2.5 flex items-center gap-3",
								children: [cosmetic ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TankPreviewSvg, {
									tank,
									cosmeticId: cosmetic.id,
									size: 48,
									className: "shrink-0"
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "w-11 h-11 rounded-lg bg-[#E08E26]/15 border border-[#E08E26]/45 text-[#E08E26] flex items-center justify-center font-mono text-xs font-extrabold shrink-0",
									children: ["+", m.scrapAmount]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "min-w-0 flex-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-xs font-bold text-[#F3EFE6] truncate",
											children: m.title
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "text-[10px] font-mono px-1.5 py-0.5 rounded bg-[#22C55E]/15 text-[#86EFAC] shrink-0",
											children: ["LVL ", m.level]
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-[11px] text-[#F3EFE6]/65 leading-snug mt-0.5",
										children: m.description
									})]
								})]
							}, m.id);
						})
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: onDismiss,
					className: "mt-5 min-h-[46px] w-full rounded-xl bg-[#E08E26] text-[#141714] font-display text-xl font-extrabold tracking-wide flex items-center justify-center gap-2 hover:bg-[#EE9B32] transition",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "w-5 h-5 stroke-[2.5]" }), "Continue"]
				})
			]
		})
	});
}
// src/ui/MainMenu.tsx
function MainMenu({ progression, sessionCustomizations, unclaimedMissionsCount = 0, onNavigate, onStartBattle }) {
	const activeTank = TANK_DEFINITIONS[progression.selectedTank] || TANK_DEFINITIONS.assault;
	const activeArena = ARENA_DEFINITIONS[progression.selectedArena] || ARENA_DEFINITIONS.training_grounds;
	const { isCompactLandscape, isFullscreen, canFullscreen } = useViewportOrientation();
	const xpPct = Math.max(0, Math.min(100, progression.xp / Math.max(1, progression.xpToNext) * 100));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative w-full h-full overflow-y-auto bg-[#141714] tactical-bg-grid text-[#F3EFE6] flex flex-col",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				"aria-hidden": "true",
				className: "pointer-events-none fixed inset-0 overflow-hidden",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "tactical-ambient-glow absolute -top-24 -left-24 w-[420px] h-[420px] rounded-full bg-[#E08E26]/10 blur-3xl" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "tactical-ambient-glow absolute -bottom-32 -right-24 w-[440px] h-[440px] rounded-full bg-[#5B7048]/12 blur-3xl" })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: `relative z-10 w-full max-w-6xl mx-auto px-4 sm:px-7 flex flex-wrap items-center justify-between gap-2.5 sm:gap-3 border-b border-[#F3EFE6]/12 shrink-0 bg-[#141714]/75 backdrop-blur-xs ${isCompactLandscape ? "py-2" : "py-3"}`,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2.5 min-w-0",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "w-9 h-9 sm:w-10 sm:h-10 rounded-lg bg-[#E08E26] text-[#141714] flex items-center justify-center shadow shrink-0 border border-[#FEF08A]/40",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Crosshair, { className: "w-5 h-5 sm:w-6 sm:h-6 stroke-[2.5]" })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "font-display text-xl sm:text-3xl font-extrabold tracking-wider uppercase text-[#F3EFE6] leading-none truncate",
							children: "TANKBOUND ARENA"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[10px] sm:text-[11px] font-mono uppercase tracking-[0.18em] text-[#E08E26] mt-0.5 truncate",
							children: "8-Tank Free-For-All Combat"
						})]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center gap-1.5 sm:gap-2.5 ml-auto",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScrapBadge, {
							scrap: progression.scrap,
							compact: true
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => onNavigate("PROFILE"),
							"aria-label": "Open Commander Profile",
							title: "Commander Profile & Milestones",
							className: "min-h-[44px] flex items-center gap-2.5 bg-[#1E221D] border border-[#F3EFE6]/15 hover:border-[#E08E26]/70 hover:bg-[#252A23] rounded-xl px-2.5 sm:px-3.5 py-1.5 text-left transition group",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "w-7 h-7 sm:w-8 sm:h-8 rounded-lg bg-[#2A3027] border border-[#E08E26]/45 flex items-center justify-center font-display font-extrabold text-sm text-[#E08E26] shrink-0",
								children: progression.level
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-1.5 text-xs font-bold text-[#F3EFE6] leading-tight",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "truncate max-w-[90px] sm:max-w-[130px]",
											children: progression.playerName
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "text-[10px] font-mono text-[#E08E26] tabular-nums",
											children: ["LVL ", progression.level]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(User, { className: "w-3 h-3 text-[#F3EFE6]/45 group-hover:text-[#E08E26] transition hidden sm:inline" })
									]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-2 mt-0.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "w-16 sm:w-20 h-1.5 rounded-full bg-[#141714] overflow-hidden border border-[#F3EFE6]/10",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "h-full bg-[#E08E26]",
											style: { width: `${xpPct}%` }
										})
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "hidden sm:inline text-[10px] font-mono tabular-nums text-[#F3EFE6]/55",
										children: [
											progression.xp,
											"/",
											progression.xpToNext,
											" XP"
										]
									})]
								})]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => onNavigate("HOW_TO_PLAY"),
							"aria-label": "Field Manual",
							title: "How to Play",
							className: "min-w-[44px] min-h-[44px] px-2.5 flex items-center justify-center gap-1.5 rounded-xl border border-[#F3EFE6]/18 bg-[#1E221D]/90 text-xs font-semibold text-[#F3EFE6]/85 hover:bg-[#272D25] transition whitespace-nowrap",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookOpen, { className: "w-4 h-4 text-[#E08E26]" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "hidden lg:inline",
								children: "Guide"
							})]
						}),
						canFullscreen && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => {
								if (isFullscreen) exitLandscapeFullscreen();
								else enterLandscapeFullscreen();
							},
							"aria-label": isFullscreen ? "Exit fullscreen" : "Enter landscape fullscreen",
							title: isFullscreen ? "Exit Fullscreen" : "Landscape Fullscreen",
							className: "min-w-[44px] min-h-[44px] px-2.5 flex items-center justify-center rounded-xl border border-[#F3EFE6]/18 bg-[#1E221D]/90 text-[#F3EFE6]/85 hover:bg-[#272D25] transition",
							children: isFullscreen ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Minimize2, { className: "w-4 h-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Maximize2, { className: "w-4 h-4" })
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
				className: `relative z-10 screen-transition flex-1 w-full max-w-6xl mx-auto px-4 sm:px-7 grid grid-cols-1 landscape:grid-cols-12 lg:grid-cols-12 items-center ${isCompactLandscape ? "py-2.5 gap-3" : "py-4 sm:py-6 gap-5 lg:gap-6"}`,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: `landscape:col-span-7 lg:col-span-7 flex flex-col ${isCompactLandscape ? "gap-2.5" : "gap-4"}`,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "bg-[#1B1F1A]/95 border border-[#F3EFE6]/15 rounded-2xl p-3.5 sm:p-5 shadow-xl",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-1 sm:grid-cols-12 gap-3.5 items-center",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "sm:col-span-7 flex items-center gap-3.5 bg-[#141714]/85 border border-[#F3EFE6]/10 rounded-xl p-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TankPreviewSvg, {
									tank: activeTank,
									cosmeticId: progression.equippedCosmetic,
									customization: sessionCustomizations?.[activeTank.id] ?? progression.tankCustomizations?.[activeTank.id] ?? null,
									size: isCompactLandscape ? 74 : 96,
									className: "shrink-0"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "min-w-0 flex-1",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "text-[11px] font-mono uppercase tracking-wider text-[#E08E26]",
											children: ["Active Tank · ", activeTank.role]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
											className: "font-display text-2xl sm:text-3xl font-extrabold text-[#F3EFE6] leading-tight truncate",
											children: activeTank.name
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "mt-1 flex flex-wrap gap-x-2.5 gap-y-0.5 text-[11px] font-mono tabular-nums text-[#F3EFE6]/70",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [getEffectiveTankMaxHp(activeTank), " HP"] }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "·" }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [getEffectiveTankMoveSpeed(activeTank), " SPD"] }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "·" }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [activeTank.stats.magazineCapacity, " RND"] }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "·" }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [getEffectiveTankReloadSec(activeTank).toFixed(2), "s RLD"] })
											]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "mt-1.5 text-[11px] text-[#F3EFE6]/65 truncate",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-[#E08E26] font-semibold",
													children: activeTank.activeAbility.name
												}),
												" ",
												"· ",
												getEffectiveTankProjectileRange(activeTank),
												" Rng"
											]
										})
									]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => onNavigate("ARENA_SELECT"),
								className: "sm:col-span-5 text-left bg-[#141714]/85 border border-[#F3EFE6]/12 hover:border-[#E08E26]/65 rounded-xl p-2.5 transition group",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center justify-between gap-2 mb-1.5",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-[10px] font-mono uppercase tracking-wider text-[#F3EFE6]/60",
											children: "Selected Arena"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "text-[11px] font-semibold text-[#E08E26] flex items-center gap-0.5",
											children: ["Change", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "w-3.5 h-3.5 group-hover:translate-x-0.5 transition-transform" })]
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArenaPreviewSvg, {
										arena: activeArena,
										className: "rounded-md"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "mt-1.5 flex items-center justify-between gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "font-display text-lg font-bold text-[#F3EFE6] leading-none truncate",
											children: activeArena.name
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-[10px] font-mono text-[#F3EFE6]/60 truncate",
											children: activeArena.subtitle
										})]
									})
								]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-5 gap-1 sm:gap-2 mt-3 pt-2.5 border-t border-[#F3EFE6]/10 text-center",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "font-mono text-xs sm:text-base font-bold tabular-nums text-[#F3EFE6]",
									children: progression.matchesPlayed
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-[9px] sm:text-[10px] uppercase tracking-wider text-[#F3EFE6]/50",
									children: "Matches"
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "font-mono text-xs sm:text-base font-bold tabular-nums text-[#22C55E]",
									children: progression.wins
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-[9px] sm:text-[10px] uppercase tracking-wider text-[#F3EFE6]/50",
									children: "Wins"
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "font-mono text-xs sm:text-base font-bold tabular-nums text-[#F3EFE6]",
									children: progression.totalEliminations
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-[9px] sm:text-[10px] uppercase tracking-wider text-[#F3EFE6]/50",
									children: "Elims"
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "font-mono text-xs sm:text-base font-bold tabular-nums text-sky-400",
									children: formatPlaytime(progression.totalPlaytimeSec)
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-[9px] sm:text-[10px] uppercase tracking-wider text-[#F3EFE6]/50",
									children: "Playtime"
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "font-mono text-xs sm:text-base font-bold tabular-nums text-[#E08E26]",
									children: progression.bestPlacement ? `#${progression.bestPlacement}` : "—"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-[9px] sm:text-[10px] uppercase tracking-wider text-[#F3EFE6]/50",
									children: "Best Rank"
								})] })
							]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: onStartBattle,
						className: `w-full rounded-2xl bg-[#E08E26] text-[#141714] font-display font-extrabold tracking-wider uppercase flex items-center justify-center gap-3 hover:bg-[#EE9B32] active:scale-[0.99] transition shadow-xl border-2 border-[#FEF08A]/35 ${isCompactLandscape ? "min-h-[52px] text-2xl" : "min-h-[60px] sm:min-h-[66px] text-3xl sm:text-4xl"}`,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "w-6 h-6 sm:w-7 sm:h-7 fill-current" }), "PLAY"]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
					"aria-label": "Primary menu navigation",
					className: `landscape:col-span-5 lg:col-span-5 flex flex-col ${isCompactLandscape ? "gap-2" : "gap-2.5"}`,
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => onNavigate("GARAGE"),
							className: "min-h-[52px] sm:min-h-[58px] w-full px-4 py-2.5 rounded-xl bg-[#1E221D] border border-[#F3EFE6]/18 hover:border-[#E08E26]/75 hover:bg-[#252A23] transition flex items-center justify-between gap-3 text-left group",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-3 min-w-0",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "w-10 h-10 rounded-lg bg-[#E08E26]/15 border border-[#E08E26]/40 text-[#E08E26] flex items-center justify-center shrink-0",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wrench, { className: "w-5 h-5" })
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "min-w-0",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "font-display text-xl font-bold tracking-wide text-[#F3EFE6] leading-none",
										children: "Garage"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "text-xs text-[#F3EFE6]/60 mt-0.5 truncate",
										children: ["Customize paint, decals & inspect ", activeTank.name]
									})]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "w-5 h-5 text-[#F3EFE6]/45 group-hover:text-[#E08E26] group-hover:translate-x-0.5 transition shrink-0" })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => onNavigate("TANK_COLLECTION"),
							className: "min-h-[52px] sm:min-h-[58px] w-full px-4 py-2.5 rounded-xl bg-[#1E221D] border border-[#F3EFE6]/18 hover:border-[#E08E26]/75 hover:bg-[#252A23] transition flex items-center justify-between gap-3 text-left group",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-3 min-w-0",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "w-10 h-10 rounded-lg bg-[#272D25] border border-[#F3EFE6]/20 text-[#F3EFE6] flex items-center justify-center shrink-0",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Layers, { className: "w-5 h-5 text-[#E08E26]" })
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "min-w-0",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "font-display text-xl font-bold tracking-wide text-[#F3EFE6] leading-none",
										children: "Tank Shop & Hangar"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "text-xs text-[#F3EFE6]/60 mt-0.5 truncate",
										children: [
											"Unlock & deploy tanks (",
											progression.unlockedTanks.length,
											"/6 Unlocked)"
										]
									})]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "w-5 h-5 text-[#F3EFE6]/45 group-hover:text-[#E08E26] group-hover:translate-x-0.5 transition shrink-0" })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => onNavigate("ARENA_SELECT"),
							className: "min-h-[52px] sm:min-h-[58px] w-full px-4 py-2.5 rounded-xl bg-[#1E221D] border border-[#F3EFE6]/18 hover:border-[#E08E26]/75 hover:bg-[#252A23] transition flex items-center justify-between gap-3 text-left group",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-3 min-w-0",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "w-10 h-10 rounded-lg bg-[#272D25] border border-[#F3EFE6]/20 text-[#F3EFE6] flex items-center justify-center shrink-0",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Map$1, { className: "w-5 h-5 text-sky-400" })
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "min-w-0",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "font-display text-xl font-bold tracking-wide text-[#F3EFE6] leading-none",
										children: "Arena Selection"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "text-xs text-[#F3EFE6]/60 mt-0.5 truncate",
										children: ["Current: ", activeArena.name]
									})]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "w-5 h-5 text-[#F3EFE6]/45 group-hover:text-[#E08E26] group-hover:translate-x-0.5 transition shrink-0" })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-2 gap-2.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => onNavigate("MISSIONS"),
								className: `min-h-[48px] sm:min-h-[52px] px-3.5 py-2 rounded-xl border transition flex items-center gap-2.5 text-left ${unclaimedMissionsCount > 0 ? "bg-[#222820] border-[#E08E26]/70 hover:border-[#E08E26] hover:bg-[#283024]" : "bg-[#1E221D] border-[#F3EFE6]/18 hover:border-[#E08E26]/65 hover:bg-[#252A23]"}`,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "relative w-9 h-9 rounded-lg bg-[#272D25] border border-[#F3EFE6]/15 flex items-center justify-center shrink-0",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Award, { className: "w-4 h-4 text-[#E08E26]" }), unclaimedMissionsCount > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "absolute -top-1.5 -right-1.5 min-w-[18px] h-[18px] px-1 rounded-full bg-[#E08E26] text-[#141714] font-mono text-[10px] font-extrabold flex items-center justify-center shadow",
										children: unclaimedMissionsCount
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "min-w-0",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "font-display text-lg font-bold leading-none text-[#F3EFE6]",
										children: "Missions"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: `text-[10px] font-mono mt-0.5 truncate ${unclaimedMissionsCount > 0 ? "text-[#FDE68A] font-bold" : "text-[#F3EFE6]/55"}`,
										children: unclaimedMissionsCount > 0 ? `${unclaimedMissionsCount} Claimable` : "Daily · Weekly"
									})]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => onNavigate("STATISTICS"),
								className: "min-h-[48px] sm:min-h-[52px] px-3.5 py-2 rounded-xl bg-[#1E221D] border border-[#F3EFE6]/18 hover:border-[#E08E26]/65 hover:bg-[#252A23] transition flex items-center gap-2.5 text-left",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "w-9 h-9 rounded-lg bg-[#272D25] border border-[#F3EFE6]/15 flex items-center justify-center shrink-0",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChartColumn, { className: "w-4 h-4 text-[#22C55E]" })
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "min-w-0",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "font-display text-lg font-bold leading-none text-[#F3EFE6]",
										children: "Statistics"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-[10px] font-mono text-[#F3EFE6]/55 mt-0.5 truncate",
										children: progression.matchesPlayed > 0 ? `${Math.round(progression.wins / progression.matchesPlayed * 100)}% Win Rate` : "Record · Scrap"
									})]
								})]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => onNavigate("SETTINGS"),
							className: "min-h-[46px] sm:min-h-[50px] w-full px-4 py-2 rounded-xl bg-[#1E221D] border border-[#F3EFE6]/18 hover:border-[#E08E26]/65 hover:bg-[#252A23] transition flex items-center justify-between gap-3 text-left group",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-3 min-w-0",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "w-9 h-9 rounded-lg bg-[#272D25] border border-[#F3EFE6]/15 flex items-center justify-center shrink-0",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Settings, { className: "w-4 h-4 text-[#F3EFE6]/85" })
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "min-w-0",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "font-display text-lg font-bold leading-none text-[#F3EFE6]",
										children: "Settings"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-[10px] font-mono text-[#F3EFE6]/55 mt-0.5 truncate",
										children: "Audio · Graphics · Controls · Local Save Data"
									})]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "w-5 h-5 text-[#F3EFE6]/45 group-hover:text-[#E08E26] group-hover:translate-x-0.5 transition shrink-0" })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between text-[11px] text-[#F3EFE6]/50 px-1 pt-0.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "inline-flex items-center gap-1.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shield, { className: "w-3.5 h-3.5 text-[#E08E26]" }), "6 Tanks · 3 Arenas · 10 Powerups"]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "inline-flex items-center gap-1 font-mono",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Compass, { className: "w-3.5 h-3.5" }), "FFA Arena"]
							})]
						})
					]
				})]
			})
		]
	});
}
// src/ui/MissionsScreen.tsx
var ACHIEVEMENT_CATEGORIES = [
	"All",
	"Combat",
	"Survival",
	"Collection",
	"Exploration"
];
function getCategoryIcon(category) {
	switch (category) {
		case "Combat": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Crosshair, { className: "w-3.5 h-3.5" });
		case "Survival": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shield, { className: "w-3.5 h-3.5" });
		case "Collection": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Package, { className: "w-3.5 h-3.5" });
		case "Exploration": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Compass, { className: "w-3.5 h-3.5" });
	}
}
function RewardChips({ reward, progression }) {
	const cosmetic = reward.cosmeticId ? COSMETIC_DEFINITIONS[reward.cosmeticId] : null;
	const activeTank = TANK_DEFINITIONS[progression.selectedTank] || TANK_DEFINITIONS.assault;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-wrap items-center gap-2",
		children: [
			reward.xp > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-[#E08E26]/15 border border-[#E08E26]/35 text-[11px] font-mono font-bold text-[#FDE68A] tabular-nums",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "w-3 h-3 text-[#E08E26]" }),
					"+",
					reward.xp,
					" XP"
				]
			}),
			reward.scrap > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-sky-500/12 border border-sky-400/35 text-[11px] font-mono font-bold text-sky-300 tabular-nums",
				children: [
					"+",
					reward.scrap,
					" Scrap"
				]
			}),
			cosmetic && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "inline-flex items-center gap-2 px-2.5 py-1 rounded-lg bg-[#22C55E]/12 border border-[#22C55E]/35 text-[11px] font-semibold text-[#86EFAC]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TankPreviewSvg, {
					tank: activeTank,
					cosmeticId: cosmetic.id,
					size: 24,
					className: "shrink-0"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [cosmetic.name, " (Visual Skin)"] })]
			})
		]
	});
}
function MissionsScreen({ progression, missionsState, onClaimReward, onCheckReset, onBack }) {
	const [activeTab, setActiveTab] = (0, import_react.useState)("daily");
	const [achFilter, setAchFilter] = (0, import_react.useState)("All");
	const [nowMs, setNowMs] = (0, import_react.useState)(() => Date.now());
	const [claimBanner, setClaimBanner] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		onCheckReset();
		const timer = window.setInterval(() => {
			setNowMs(Date.now());
			onCheckReset();
		}, 15e3);
		return () => window.clearInterval(timer);
	}, [onCheckReset]);
	const counts = (0, import_react.useMemo)(() => countUnclaimedRewards(missionsState), [missionsState]);
	const countdowns = (0, import_react.useMemo)(() => getResetCountdowns(nowMs, MISSION_RESET_CONFIG), [nowMs]);
	const xpPct = Math.max(0, Math.min(100, progression.xp / Math.max(1, progression.xpToNext) * 100));
	const unlockedAchCount = (0, import_react.useMemo)(() => ACHIEVEMENT_DEFINITIONS.filter((def) => missionsState.achievements[def.id]?.completed).length, [missionsState.achievements]);
	const filteredAchievements = (0, import_react.useMemo)(() => {
		if (achFilter === "All") return ACHIEVEMENT_DEFINITIONS;
		return ACHIEVEMENT_DEFINITIONS.filter((a) => a.category === achFilter);
	}, [achFilter]);
	const handleClaim = (scope, id, title) => {
		const outcome = onClaimReward(scope, id);
		if (outcome.claimed) {
			const cosmeticName = outcome.cosmeticUnlocked ? COSMETIC_DEFINITIONS[outcome.cosmeticUnlocked]?.name ?? null : null;
			setClaimBanner({
				title,
				xp: outcome.xpAwarded,
				scrap: outcome.scrapAwarded,
				cosmeticName
			});
		}
	};
	const renderMissionCard = (scope, entry) => {
		const def = ALL_MISSION_DEFINITIONS[entry.missionId];
		if (!def) return null;
		const pct = Math.max(0, Math.min(100, entry.progress / Math.max(1, def.target) * 100));
		const canClaim = entry.completed && !entry.claimed;
		return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: `rounded-2xl border p-4 transition flex flex-col justify-between gap-3 ${canClaim ? "bg-[#222820] border-[#E08E26] shadow-lg" : entry.claimed ? "bg-[#191D18]/80 border-[#22C55E]/30" : "bg-[#1B1F1A]/95 border-[#F3EFE6]/14"}`,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start justify-between gap-2.5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex items-center gap-2 flex-wrap",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "font-display text-xl font-extrabold tracking-wide text-[#F3EFE6] leading-tight",
							children: def.title
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-[#F3EFE6]/72 mt-1 leading-relaxed",
						children: def.description
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: `shrink-0 px-2.5 py-1 rounded-lg text-[10px] font-mono uppercase tracking-wider font-bold ${entry.claimed ? "bg-[#22C55E]/15 border border-[#22C55E]/35 text-[#86EFAC]" : canClaim ? "bg-[#E08E26]/20 border border-[#E08E26]/55 text-[#FDE68A]" : "bg-[#141714] border border-[#F3EFE6]/15 text-[#F3EFE6]/60"}`,
					children: entry.claimed ? "Claimed" : canClaim ? "Ready" : "Active"
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between text-xs font-mono tabular-nums mb-1.5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-[#F3EFE6]/60 uppercase text-[10px] tracking-wider",
						children: "Progress"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: entry.completed ? "text-[#22C55E] font-bold" : "text-[#F3EFE6]",
						children: [
							entry.progress,
							" / ",
							def.target
						]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "w-full h-2.5 rounded-full bg-[#141714] border border-[#F3EFE6]/10 overflow-hidden",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: `h-full transition-all duration-300 ${entry.completed ? "bg-[#22C55E]" : "bg-[#E08E26]"}`,
						style: { width: `${pct}%` }
					})
				})]
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "pt-2.5 border-t border-[#F3EFE6]/10 flex flex-wrap items-center justify-between gap-2.5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RewardChips, {
					reward: def.reward,
					progression
				}), canClaim ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => handleClaim(scope, def.id, def.title),
					className: "min-h-[44px] px-4 rounded-xl bg-[#E08E26] text-[#141714] font-display text-base font-extrabold tracking-wide uppercase flex items-center gap-1.5 hover:bg-[#EE9B32] active:scale-[0.98] transition whitespace-nowrap shadow",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Gift, { className: "w-4 h-4" }), "Claim"]
				}) : entry.claimed ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-h-[44px] px-3.5 rounded-xl bg-[#22C55E]/12 border border-[#22C55E]/35 text-[#86EFAC] text-xs font-mono font-bold uppercase tracking-wider flex items-center gap-1.5 whitespace-nowrap",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "w-4 h-4" }), "Claimed"]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "min-h-[44px] px-3 rounded-xl bg-[#141714] border border-[#F3EFE6]/10 text-[#F3EFE6]/45 text-xs font-mono flex items-center whitespace-nowrap",
					children: "In Progress"
				})]
			})]
		}, def.id);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "w-full h-full overflow-y-auto bg-[#141714] tactical-bg-grid text-[#F3EFE6] flex flex-col",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
			className: "w-full max-w-6xl mx-auto px-4 sm:px-7 py-3 flex flex-wrap items-center justify-between gap-3 border-b border-[#F3EFE6]/12 shrink-0 bg-[#141714]/85 backdrop-blur-xs",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: onBack,
					className: "min-h-[44px] px-3.5 rounded-xl border border-[#F3EFE6]/20 bg-[#1E221D] flex items-center gap-1.5 text-sm font-semibold hover:bg-[#282D26] transition whitespace-nowrap",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "w-4 h-4" }), "Back"]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-2xl sm:text-3xl font-extrabold tracking-wide leading-none",
					children: "Missions & Achievements"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[11px] font-mono text-[#F3EFE6]/55 mt-0.5",
					children: "Daily Orders · Weekly Ops · Permanent Honors"
				})] })]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-2.5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "bg-[#1E221D] border border-[#F3EFE6]/15 rounded-xl px-3 py-1.5 flex items-center gap-2.5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "w-7 h-7 rounded-lg bg-[#E08E26]/20 border border-[#E08E26]/50 text-[#E08E26] font-display font-extrabold text-sm flex items-center justify-center",
						children: progression.level
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-[96px]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between text-[10px] font-mono tabular-nums",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-[#E08E26] font-bold",
								children: ["LVL ", progression.level]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-[#F3EFE6]/65",
								children: [
									progression.xp,
									"/",
									progression.xpToNext,
									" XP"
								]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "w-full h-1.5 rounded-full bg-[#141714] overflow-hidden mt-1 border border-[#F3EFE6]/10",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "h-full bg-[#E08E26]",
								style: { width: `${xpPct}%` }
							})
						})]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "bg-[#1E221D] border border-sky-400/25 rounded-xl px-3 py-2 text-right",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-[10px] font-mono uppercase tracking-wider text-sky-300/75 leading-none",
						children: "Scrap"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "font-mono text-sm font-bold text-sky-300 tabular-nums mt-0.5",
						children: progression.scrap
					})]
				})]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
			className: "screen-transition flex-1 w-full max-w-6xl mx-auto px-4 sm:px-7 py-4 sm:py-5 flex flex-col gap-4",
			children: [
				claimBanner && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "bg-[#1E2B1E] border border-[#22C55E]/55 rounded-xl px-4 py-2.5 flex flex-wrap items-center justify-between gap-2 shadow-lg",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2 text-xs sm:text-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "w-4 h-4 text-[#22C55E] shrink-0" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "font-bold text-[#F3EFE6]",
								children: [claimBanner.title, " Claimed:"]
							}),
							claimBanner.xp > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "font-mono text-[#FDE68A] font-bold",
								children: [
									"+",
									claimBanner.xp,
									" XP"
								]
							}),
							claimBanner.scrap > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "font-mono text-sky-300 font-bold",
								children: [
									"+",
									claimBanner.scrap,
									" Scrap"
								]
							}),
							claimBanner.cosmeticName && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "font-semibold text-[#86EFAC]",
								children: ["Unlocked Skin: ", claimBanner.cosmeticName]
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setClaimBanner(null),
						className: "text-xs font-mono text-[#F3EFE6]/70 hover:text-[#F3EFE6] px-2 py-1",
						children: "Dismiss"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-3 gap-2 sm:gap-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => setActiveTab("daily"),
							className: `min-h-[48px] px-2 sm:px-3 py-2 rounded-xl border font-display text-sm sm:text-xl font-bold tracking-wide flex items-center justify-center gap-1 sm:gap-2 transition ${activeTab === "daily" ? "bg-[#E08E26] text-[#141714] border-[#FEF08A]/50 shadow" : "bg-[#1B1F1A] text-[#F3EFE6]/80 border-[#F3EFE6]/15 hover:border-[#E08E26]/55"}`,
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "w-3.5 h-3.5 sm:w-4 sm:h-4 shrink-0" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Daily" }),
								counts.daily > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: `px-1.5 py-0.5 rounded-md font-mono text-[10px] sm:text-[11px] font-extrabold tabular-nums ${activeTab === "daily" ? "bg-[#141714] text-[#E08E26]" : "bg-[#E08E26] text-[#141714]"}`,
									children: counts.daily
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => setActiveTab("weekly"),
							className: `min-h-[48px] px-2 sm:px-3 py-2 rounded-xl border font-display text-sm sm:text-xl font-bold tracking-wide flex items-center justify-center gap-1 sm:gap-2 transition ${activeTab === "weekly" ? "bg-[#E08E26] text-[#141714] border-[#FEF08A]/50 shadow" : "bg-[#1B1F1A] text-[#F3EFE6]/80 border-[#F3EFE6]/15 hover:border-[#E08E26]/55"}`,
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Award, { className: "w-3.5 h-3.5 sm:w-4 sm:h-4 shrink-0" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Weekly" }),
								counts.weekly > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: `px-1.5 py-0.5 rounded-md font-mono text-[10px] sm:text-[11px] font-extrabold tabular-nums ${activeTab === "weekly" ? "bg-[#141714] text-[#E08E26]" : "bg-[#E08E26] text-[#141714]"}`,
									children: counts.weekly
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => setActiveTab("achievements"),
							className: `min-h-[48px] px-2 sm:px-3 py-2 rounded-xl border font-display text-sm sm:text-xl font-bold tracking-wide flex items-center justify-center gap-1 sm:gap-2 transition ${activeTab === "achievements" ? "bg-[#E08E26] text-[#141714] border-[#FEF08A]/50 shadow" : "bg-[#1B1F1A] text-[#F3EFE6]/80 border-[#F3EFE6]/15 hover:border-[#E08E26]/55"}`,
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trophy, { className: "w-3.5 h-3.5 sm:w-4 sm:h-4 shrink-0" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "truncate",
									children: "Achievements"
								}),
								counts.achievements > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: `px-1.5 py-0.5 rounded-md font-mono text-[10px] sm:text-[11px] font-extrabold tabular-nums shrink-0 ${activeTab === "achievements" ? "bg-[#141714] text-[#E08E26]" : "bg-[#E08E26] text-[#141714]"}`,
									children: counts.achievements
								})
							]
						})
					]
				}),
				activeTab === "daily" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "flex flex-col gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "bg-[#1B1F1A]/85 border border-[#F3EFE6]/12 rounded-xl px-4 py-2.5 flex flex-wrap items-center justify-between gap-2 text-xs",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "text-[#F3EFE6]/80",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-bold text-[#E08E26]",
								children: "3 Active Daily Missions"
							}), " — Complete objectives in live matches and claim your rewards before midnight reset."]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "inline-flex items-center gap-1.5 font-mono text-[11px] text-[#FDE68A] tabular-nums",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "w-3.5 h-3.5 text-[#E08E26]" }),
								"Resets in ",
								formatCountdownDuration(countdowns.dailyMsLeft),
								" (",
								MISSION_RESET_CONFIG.timezone,
								")"
							]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid grid-cols-1 md:grid-cols-3 gap-3.5",
						children: missionsState.dailyMissions.map((entry) => renderMissionCard("daily", entry))
					})]
				}),
				activeTab === "weekly" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "flex flex-col gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "bg-[#1B1F1A]/85 border border-[#F3EFE6]/12 rounded-xl px-4 py-2.5 flex flex-wrap items-center justify-between gap-2 text-xs",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "text-[#F3EFE6]/80",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-bold text-[#E08E26]",
								children: "3 Active Weekly Operations"
							}), " — Progress simultaneously alongside daily missions across matches."]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "inline-flex items-center gap-1.5 font-mono text-[11px] text-[#FDE68A] tabular-nums",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "w-3.5 h-3.5 text-[#E08E26]" }),
								"Resets in ",
								formatCountdownDuration(countdowns.weeklyMsLeft),
								" (",
								MISSION_RESET_CONFIG.timezone,
								")"
							]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid grid-cols-1 md:grid-cols-3 gap-3.5",
						children: missionsState.weeklyMissions.map((entry) => renderMissionCard("weekly", entry))
					})]
				}),
				activeTab === "achievements" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "flex flex-col gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "bg-[#1B1F1A]/85 border border-[#F3EFE6]/12 rounded-xl px-4 py-2.5 flex flex-wrap items-center justify-between gap-2.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex flex-wrap items-center gap-1.5",
							children: ACHIEVEMENT_CATEGORIES.map((cat) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => setAchFilter(cat),
								className: `min-h-[36px] px-3 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition border ${achFilter === cat ? "bg-[#E08E26]/20 border-[#E08E26] text-[#FDE68A]" : "bg-[#141714] border-[#F3EFE6]/12 text-[#F3EFE6]/65 hover:text-[#F3EFE6]"}`,
								children: [cat !== "All" && getCategoryIcon(cat), cat]
							}, cat))
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "text-xs font-mono tabular-nums text-[#86EFAC]",
							children: [
								"Unlocked ",
								unlockedAchCount,
								" / ",
								ACHIEVEMENT_DEFINITIONS.length
							]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3.5 pb-4",
						children: filteredAchievements.map((def) => {
							const entry = missionsState.achievements[def.id] ?? {
								achievementId: def.id,
								progress: 0,
								completed: false,
								unlockedAtMs: null,
								claimed: false,
								claimedAtMs: null
							};
							const pct = Math.max(0, Math.min(100, entry.progress / Math.max(1, def.target) * 100));
							const canClaim = entry.completed && !entry.claimed;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: `rounded-2xl border p-4 transition flex flex-col justify-between gap-3 ${canClaim ? "bg-[#222820] border-[#E08E26] shadow-lg" : entry.completed ? "bg-[#192019] border-[#22C55E]/35" : "bg-[#1B1F1A]/95 border-[#F3EFE6]/14"}`,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-start justify-between gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "min-w-0",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "inline-flex items-center gap-1 text-[10px] font-mono uppercase tracking-wider text-[#E08E26] mb-1",
												children: [getCategoryIcon(def.category), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: def.category })]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
												className: "font-display text-xl font-extrabold tracking-wide text-[#F3EFE6] leading-tight",
												children: def.title
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-xs text-[#F3EFE6]/72 mt-1 leading-relaxed",
												children: def.description
											})
										]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: `shrink-0 px-2.5 py-1 rounded-lg text-[10px] font-mono uppercase tracking-wider font-bold flex items-center gap-1 ${entry.claimed ? "bg-[#22C55E]/15 border border-[#22C55E]/35 text-[#86EFAC]" : entry.completed ? "bg-[#E08E26]/20 border border-[#E08E26]/55 text-[#FDE68A]" : "bg-[#141714] border border-[#F3EFE6]/12 text-[#F3EFE6]/50"}`,
										children: entry.claimed ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "w-3 h-3" }), "Claimed"] }) : entry.completed ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trophy, { className: "w-3 h-3" }), "Unlocked"] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, { className: "w-3 h-3" }), "Locked"] })
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center justify-between text-xs font-mono tabular-nums mb-1.5",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-[#F3EFE6]/60 uppercase text-[10px] tracking-wider",
											children: "Career Progress"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: entry.completed ? "text-[#22C55E] font-bold" : "text-[#F3EFE6]",
											children: [
												entry.progress,
												" / ",
												def.target
											]
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "w-full h-2 rounded-full bg-[#141714] border border-[#F3EFE6]/10 overflow-hidden",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: `h-full transition-all duration-300 ${entry.completed ? "bg-[#22C55E]" : "bg-[#E08E26]"}`,
											style: { width: `${pct}%` }
										})
									})]
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "pt-2.5 border-t border-[#F3EFE6]/10 flex flex-wrap items-center justify-between gap-2.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RewardChips, {
										reward: def.reward,
										progression
									}), canClaim ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										onClick: () => handleClaim("achievement", def.id, def.title),
										className: "min-h-[44px] px-4 rounded-xl bg-[#E08E26] text-[#141714] font-display text-base font-extrabold tracking-wide uppercase flex items-center gap-1.5 hover:bg-[#EE9B32] active:scale-[0.98] transition whitespace-nowrap shadow",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Gift, { className: "w-4 h-4" }), "Claim"]
									}) : entry.claimed ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "min-h-[44px] px-3.5 rounded-xl bg-[#22C55E]/12 border border-[#22C55E]/35 text-[#86EFAC] text-xs font-mono font-bold uppercase tracking-wider flex items-center gap-1.5 whitespace-nowrap",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "w-4 h-4" }), "Claimed"]
									}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "min-h-[44px] px-3 rounded-xl bg-[#141714] border border-[#F3EFE6]/10 text-[#F3EFE6]/45 text-xs font-mono flex items-center whitespace-nowrap",
										children: "Locked"
									})]
								})]
							}, def.id);
						})
					})]
				})
			]
		})]
	});
}
// src/ui/ProfileScreen.tsx
function ProfileScreen({ progression, onUpdatePlayerName, onEquipCosmetic, onPurchaseCosmetic, onOpenStatistics, onBack }) {
	const [editingName, setEditingName] = (0, import_react.useState)(false);
	const [draftName, setDraftName] = (0, import_react.useState)(progression.playerName);
	const [nameError, setNameError] = (0, import_react.useState)(null);
	const activeTank = TANK_DEFINITIONS[progression.selectedTank] || TANK_DEFINITIONS.assault;
	const xpPct = Math.max(0, Math.min(100, progression.xp / Math.max(1, progression.xpToNext) * 100));
	const xpRemaining = Math.max(0, progression.xpToNext - progression.xp);
	const winRate = progression.matchesPlayed > 0 ? Math.round(progression.wins / progression.matchesPlayed * 100) : 0;
	const handleSaveName = (e) => {
		e.preventDefault();
		const trimmed = draftName.trim();
		if (!trimmed) {
			setNameError("Display name cannot be empty.");
			return;
		}
		onUpdatePlayerName(trimmed.slice(0, 20));
		setDraftName(trimmed.slice(0, 20));
		setNameError(null);
		setEditingName(false);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "w-full h-full overflow-y-auto bg-[#141714] tactical-bg-grid text-[#F3EFE6] flex flex-col",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
			className: "w-full max-w-6xl mx-auto px-4 sm:px-7 py-3 flex items-center justify-between gap-3 border-b border-[#F3EFE6]/12 shrink-0 bg-[#141714]/80",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: onBack,
					className: "min-h-[44px] px-3.5 rounded-xl border border-[#F3EFE6]/20 bg-[#1E221D] flex items-center gap-1.5 text-sm font-semibold hover:bg-[#282D26] transition whitespace-nowrap",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "w-4 h-4" }), "Back"]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-2xl sm:text-3xl font-extrabold tracking-wide leading-none",
					children: "Commander Profile"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[11px] text-[#F3EFE6]/55 mt-0.5",
					children: "Local progression, combat record & level milestone rewards"
				})] })]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-2.5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScrapBadge, { scrap: progression.scrap }), onOpenStatistics && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: onOpenStatistics,
					className: "min-h-[44px] px-3.5 rounded-xl bg-[#1E221D] border border-[#F3EFE6]/20 text-xs sm:text-sm font-semibold flex items-center gap-1.5 hover:border-[#E08E26]/65 hover:bg-[#262C24] transition whitespace-nowrap",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChartColumn, { className: "w-4 h-4 text-[#22C55E]" }), "Statistics"]
				})]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
			className: "screen-transition flex-1 w-full max-w-6xl mx-auto px-4 sm:px-7 py-4 sm:py-6 grid grid-cols-1 lg:grid-cols-12 gap-5 items-start",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "lg:col-span-7 flex flex-col gap-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "bg-[#1B1F1A]/95 border border-[#F3EFE6]/15 rounded-2xl p-4 sm:p-5 shadow-xl",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex flex-wrap items-start justify-between gap-4",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-3.5 min-w-0 flex-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "w-14 h-14 rounded-2xl bg-[#E08E26]/15 border-2 border-[#E08E26] flex flex-col items-center justify-center shrink-0",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-[9px] font-mono uppercase tracking-wider text-[#E08E26] leading-none",
										children: "LVL"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-display text-2xl font-extrabold text-[#F3EFE6] leading-none mt-0.5 tabular-nums",
										children: progression.level
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "min-w-0 flex-1",
									children: [
										!editingName ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center gap-2 flex-wrap",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
												className: "font-display text-2xl sm:text-3xl font-extrabold text-[#F3EFE6] leading-none truncate",
												children: progression.playerName
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
												type: "button",
												onClick: () => {
													setDraftName(progression.playerName);
													setNameError(null);
													setEditingName(true);
												},
												"aria-label": "Edit display name",
												className: "min-h-[34px] px-2.5 rounded-lg bg-[#141714] border border-[#F3EFE6]/18 text-xs font-semibold text-[#F3EFE6]/80 hover:border-[#E08E26]/65 hover:text-[#E08E26] flex items-center gap-1.5 transition",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PenLine, { className: "w-3.5 h-3.5" }), "Rename"]
											})]
										}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
											onSubmit: handleSaveName,
											className: "flex flex-wrap items-center gap-2",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
													htmlFor: "player-name-input",
													className: "sr-only",
													children: "Player Display Name"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
													id: "player-name-input",
													type: "text",
													maxLength: 20,
													value: draftName,
													onChange: (e) => {
														setDraftName(e.target.value);
														if (nameError) setNameError(null);
													},
													autoFocus: true,
													placeholder: "Enter callsign...",
													className: "min-h-[38px] px-3 rounded-lg bg-[#141714] border border-[#E08E26] text-sm font-semibold text-[#F3EFE6] focus:outline-none w-44 sm:w-52"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
													type: "submit",
													className: "min-h-[38px] px-3 rounded-lg bg-[#E08E26] text-[#141714] text-xs font-bold hover:bg-[#EE9B32] transition flex items-center gap-1",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "w-3.5 h-3.5 stroke-[2.5]" }), "Save"]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
													type: "button",
													onClick: () => {
														setEditingName(false);
														setNameError(null);
													},
													className: "min-h-[38px] px-3 rounded-lg border border-[#F3EFE6]/20 text-xs font-medium text-[#F3EFE6]/75 hover:bg-[#272C25] transition",
													children: "Cancel"
												})
											]
										}),
										nameError && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-xs text-red-400 mt-1",
											children: nameError
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center gap-3 mt-1.5 text-xs font-mono text-[#F3EFE6]/60 tabular-nums",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
													className: "inline-flex items-center gap-1",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(User, { className: "w-3.5 h-3.5 text-[#E08E26]" }), "Local Profile"]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "·" }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["Lifetime XP: ", progression.totalXpEarned.toLocaleString()] })
											]
										})
									]
								})]
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-4 bg-[#141714] border border-[#F3EFE6]/12 rounded-xl p-3.5",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between text-xs font-mono tabular-nums mb-1.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "text-[#E08E26] font-bold",
										children: [
											"Level ",
											progression.level,
											" → Level ",
											progression.level + 1
										]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "text-[#F3EFE6]/85",
										children: [
											progression.xp,
											" / ",
											progression.xpToNext,
											" XP"
										]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "w-full h-3 rounded-full bg-[#1E221D] overflow-hidden border border-[#F3EFE6]/12",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "h-full bg-[#E08E26] transition-all duration-300",
										style: { width: `${xpPct}%` }
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between text-[11px] text-[#F3EFE6]/55 mt-1.5 font-mono tabular-nums",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [Math.round(xpPct), "% Complete"] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [xpRemaining, " XP to next level"] })]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-2 sm:grid-cols-4 gap-2.5 mt-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "bg-[#141714] border border-[#F3EFE6]/10 rounded-xl p-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-1.5 text-[11px] text-[#F3EFE6]/55",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shield, { className: "w-3.5 h-3.5 text-[#E08E26]" }), "Total Matches"]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "font-mono text-xl font-bold tabular-nums text-[#F3EFE6] mt-1",
										children: progression.matchesPlayed
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "bg-[#141714] border border-[#F3EFE6]/10 rounded-xl p-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-1.5 text-[11px] text-[#F3EFE6]/55",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trophy, { className: "w-3.5 h-3.5 text-[#22C55E]" }), "Victories"]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "font-mono text-xl font-bold tabular-nums text-[#22C55E] mt-1",
										children: [progression.wins, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "text-xs text-[#F3EFE6]/50 font-normal ml-1.5",
											children: [
												"(",
												winRate,
												"%)"
											]
										})]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "bg-[#141714] border border-[#F3EFE6]/10 rounded-xl p-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-1.5 text-[11px] text-[#F3EFE6]/55",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skull, { className: "w-3.5 h-3.5 text-red-400" }), "Defeats"]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "font-mono text-xl font-bold tabular-nums text-red-300 mt-1",
										children: progression.defeats
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "bg-[#141714] border border-[#F3EFE6]/10 rounded-xl p-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-1.5 text-[11px] text-[#F3EFE6]/55",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Crosshair, { className: "w-3.5 h-3.5 text-amber-400" }), "Eliminations"]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "font-mono text-xl font-bold tabular-nums text-[#F3EFE6] mt-1",
										children: progression.totalEliminations
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "bg-[#141714] border border-[#F3EFE6]/10 rounded-xl p-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-1.5 text-[11px] text-[#F3EFE6]/55",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Hexagon, { className: "w-3.5 h-3.5 text-sky-300" }), "Scrap Earned"]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "font-mono text-xl font-bold tabular-nums text-sky-300 mt-1",
										children: progression.totalScrapEarned.toLocaleString()
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "bg-[#141714] border border-[#F3EFE6]/10 rounded-xl p-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-1.5 text-[11px] text-[#F3EFE6]/55",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Hexagon, { className: "w-3.5 h-3.5 text-[#E08E26]" }), "Scrap Spent"]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "font-mono text-xl font-bold tabular-nums text-[#E08E26] mt-1",
										children: progression.totalScrapSpent.toLocaleString()
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "bg-[#141714] border border-[#F3EFE6]/10 rounded-xl p-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-1.5 text-[11px] text-[#F3EFE6]/55",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "w-3.5 h-3.5 text-sky-400" }), "Playtime"]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "font-mono text-xl font-bold tabular-nums text-[#F3EFE6] mt-1",
										children: formatPlaytime(progression.totalPlaytimeSec)
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "bg-[#141714] border border-[#F3EFE6]/10 rounded-xl p-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-1.5 text-[11px] text-[#F3EFE6]/55",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "w-3.5 h-3.5 text-[#E08E26]" }), "Lifetime XP"]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "font-mono text-xl font-bold tabular-nums text-[#F3EFE6] mt-1",
										children: progression.totalXpEarned.toLocaleString()
									})]
								})
							]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "bg-[#1B1F1A]/95 border border-[#F3EFE6]/15 rounded-2xl p-4 sm:p-5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-center justify-between gap-2 mb-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
							className: "font-display text-xl font-bold flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Palette, { className: "w-4 h-4 text-[#E08E26]" }), "Tank Cosmetics"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-[#F3EFE6]/60",
							children: "Earned via level milestones or unlocked with Scrap · Visual appearance only"
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "text-[11px] font-mono text-[#F3EFE6]/60",
							children: ["Previewing: ", activeTank.name]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid grid-cols-1 sm:grid-cols-2 gap-2.5",
						children: COSMETIC_LIST.map((cosmetic) => {
							const isUnlocked = cosmetic.id === "default" || progression.unlockedCosmetics.includes(cosmetic.id);
							const isEquipped = progression.equippedCosmetic === cosmetic.id;
							const shopCost = cosmetic.scrapCost ?? 0;
							const isShopSkin = !isUnlocked && shopCost > 0 && Boolean(onPurchaseCosmetic);
							const canBuy = isShopSkin && progression.scrap >= shopCost;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								disabled: !isUnlocked && !canBuy,
								onClick: () => {
									if (isUnlocked) onEquipCosmetic(cosmetic.id);
									else if (canBuy && onPurchaseCosmetic) {
										if (onPurchaseCosmetic(cosmetic.id).success) onEquipCosmetic(cosmetic.id);
									}
								},
								className: `text-left rounded-xl p-3 border flex items-center gap-3 transition ${isEquipped ? "bg-[#252B23] border-[#E08E26]" : isUnlocked ? "bg-[#141714] border-[#F3EFE6]/15 hover:border-[#E08E26]/55" : canBuy ? "bg-[#141714] border-sky-400/35 hover:border-sky-400" : "bg-[#141714]/60 border-[#F3EFE6]/8 opacity-65 cursor-not-allowed"}`,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TankPreviewSvg, {
									tank: activeTank,
									cosmeticId: cosmetic.id,
									customization: progression.tankCustomizations?.[activeTank.id] ?? null,
									size: 54,
									className: "shrink-0"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "min-w-0 flex-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center justify-between gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-sm font-bold text-[#F3EFE6] truncate",
											children: cosmetic.name
										}), isEquipped ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-[10px] font-mono uppercase px-1.5 py-0.5 rounded bg-[#E08E26] text-[#141714] font-bold shrink-0",
											children: "Equipped"
										}) : isUnlocked ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-[10px] font-mono uppercase px-1.5 py-0.5 rounded bg-[#22C55E]/15 text-[#86EFAC] shrink-0",
											children: "Equip"
										}) : isShopSkin ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: `text-[10px] font-mono uppercase px-1.5 py-0.5 rounded font-bold shrink-0 ${canBuy ? "bg-sky-400 text-[#141714]" : "bg-[#272D25] text-sky-300"}`,
											children: canBuy ? `Buy · ${shopCost} Scrap` : `${shopCost} Scrap`
										}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "text-[10px] font-mono uppercase px-1.5 py-0.5 rounded bg-[#272D25] text-[#F3EFE6]/60 inline-flex items-center gap-1 shrink-0",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, { className: "w-2.5 h-2.5" }), cosmetic.unlockSourceLabel ?? `LVL ${cosmetic.unlockLevel}`]
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-[11px] text-[#F3EFE6]/65 mt-0.5 leading-snug",
										children: cosmetic.description
									})]
								})]
							}, cosmetic.id);
						})
					})]
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
				className: "lg:col-span-5 bg-[#1B1F1A]/95 border border-[#F3EFE6]/15 rounded-2xl p-4 sm:p-5 flex flex-col gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
					className: "font-display text-xl font-bold flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Award, { className: "w-4 h-4 text-[#E08E26]" }), "Level Milestone Rewards"]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-[#F3EFE6]/60 mt-0.5",
					children: "Granted automatically once when reaching each milestone level"
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex flex-col gap-2.5",
					children: MILESTONE_REWARDS.map((milestone) => {
						const claimed = progression.claimedMilestoneLevels.includes(milestone.level);
						const reached = progression.level >= milestone.level || claimed;
						const cosmetic = milestone.cosmeticId ? COSMETIC_DEFINITIONS[milestone.cosmeticId] : null;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: `rounded-xl p-3 border flex items-center gap-3 ${reached ? "bg-[#1A241B] border-[#22C55E]/40" : "bg-[#141714] border-[#F3EFE6]/12"}`,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: `w-11 h-11 rounded-xl flex flex-col items-center justify-center font-mono shrink-0 border ${reached ? "bg-[#22C55E]/15 border-[#22C55E]/50 text-[#86EFAC]" : "bg-[#1E221D] border-[#F3EFE6]/15 text-[#F3EFE6]/65"}`,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-[9px] uppercase leading-none",
									children: "LVL"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-base font-extrabold leading-none mt-0.5",
									children: milestone.level
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0 flex-1",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center justify-between gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-sm font-bold text-[#F3EFE6] truncate",
											children: milestone.title
										}), reached ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "inline-flex items-center gap-1 text-[10px] font-mono uppercase px-2 py-0.5 rounded bg-[#22C55E]/20 text-[#86EFAC] font-bold shrink-0",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "w-3 h-3" }), "Unlocked"]
										}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "text-[10px] font-mono uppercase px-2 py-0.5 rounded bg-[#272D25] text-[#E08E26] shrink-0",
											children: ["Level ", milestone.level]
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-[11px] text-[#F3EFE6]/65 mt-0.5 leading-snug",
										children: milestone.description
									}),
									milestone.type === "currency" && milestone.scrapAmount && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "text-[11px] font-mono text-[#E08E26] mt-1",
										children: [
											"Reward: +",
											milestone.scrapAmount,
											" Scrap"
										]
									}),
									cosmetic && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-2 mt-1.5",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "w-3 h-3 rounded-full border border-[#F3EFE6]/30",
												style: { backgroundColor: cosmetic.previewPrimary }
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "w-3 h-3 rounded-full border border-[#F3EFE6]/30",
												style: { backgroundColor: cosmetic.previewAccent }
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "text-[11px] font-mono text-[#F3EFE6]/70",
												children: ["Cosmetic: ", cosmetic.name]
											})
										]
									})
								]
							})]
						}, milestone.id);
					})
				})]
			})]
		})]
	});
}
// src/ui/ResultsScreen.tsx
function getReasonLabel(result) {
	switch (result.reason) {
		case "last_standing": return "Last tank standing in the arena";
		case "time_highest_hp": return "Match timer expired · Highest remaining armor";
		case "time_outscored": return `Time expired · ${result.winnerName} held higher armor`;
		case "eliminated": return `Eliminated · ${result.winnerName} took the field`;
	}
}
function ResultsScreen({ result, progression, summary, isRewardedSupported = false, onWatchRewardedAd, onPlayAgain, onMainMenu }) {
	const [adBusy, setAdBusy] = (0, import_react.useState)(false);
	const [adStatusText, setAdStatusText] = (0, import_react.useState)(null);
	const rewardGrantId = `match_bonus_${result.matchId}`;
	const alreadyClaimedBonus = Boolean(progression.processedRewardedAdIds?.includes(rewardGrantId));
	const tank = TANK_DEFINITIONS[result.tankId];
	const arena = ARENA_DEFINITIONS[result.arenaId];
	const prevLevel = summary?.previousLevel ?? progression.level;
	const newLevel = summary?.newLevel ?? progression.level;
	const leveledUp = (summary?.levelsGained ?? 0) > 0;
	const xpBreakdown = summary?.xpBreakdown;
	const scrapBreakdown = summary?.scrapBreakdown ?? result.scrapBreakdown ?? calculateMatchScrapBreakdown(result);
	const xpPct = Math.max(0, Math.min(100, progression.xp / Math.max(1, progression.xpToNext) * 100));
	const unlockedMilestones = summary?.unlockedMilestones ?? [];
	const scrapFromMilestones = summary?.scrapFromMilestones ?? 0;
	const totalScrapEarned = summary?.totalScrapAwarded ?? result.scrapEarned;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed inset-0 z-30 w-full h-full overflow-y-auto bg-[#141714]/82 backdrop-blur-xs text-[#F3EFE6] flex items-center justify-center p-3 sm:p-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: `w-full max-w-2xl bg-[#1E221D] border-2 rounded-2xl p-4 sm:p-6 shadow-2xl my-auto ${result.victory ? "border-[#E08E26]/65" : "border-[#F3EFE6]/25"}`,
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col items-center text-center",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: `w-12 h-12 sm:w-14 sm:h-14 rounded-full flex items-center justify-center border-2 mb-2 ${result.victory ? "bg-[#E08E26]/20 border-[#E08E26] text-[#E08E26]" : "bg-red-500/15 border-red-400/60 text-red-400"}`,
							children: result.victory ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trophy, { className: "w-6 h-6 sm:w-7 sm:h-7" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skull, { className: "w-6 h-6 sm:w-7 sm:h-7" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: `font-display text-3xl sm:text-5xl font-extrabold tracking-wide leading-none ${result.victory ? "text-[#E08E26]" : "text-[#F3EFE6]"}`,
							children: result.victory ? "Victory" : "Defeat"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs sm:text-sm text-[#F3EFE6]/75 mt-1",
							children: getReasonLabel(result)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-xs text-[#F3EFE6]/55 mt-1 font-mono tabular-nums",
							children: [
								tank.name,
								" · ",
								arena.name,
								" · Rank #",
								result.placement,
								" of ",
								result.totalTanks
							]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-4 gap-2 sm:gap-3 my-4 py-3 border-y border-[#F3EFE6]/12 text-center",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "font-mono text-xl sm:text-2xl font-bold tabular-nums text-[#F3EFE6]",
							children: [
								"#",
								result.placement,
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-xs sm:text-sm text-[#F3EFE6]/50",
									children: ["/", result.totalTanks]
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-[11px] text-[#F3EFE6]/60 mt-0.5",
							children: "Placement"
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "font-mono text-xl sm:text-2xl font-bold tabular-nums text-[#F3EFE6]",
							children: result.eliminations
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-[11px] text-[#F3EFE6]/60 mt-0.5",
							children: "Eliminations"
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "font-mono text-xl sm:text-2xl font-bold tabular-nums text-[#F3EFE6]",
							children: result.damageDealt
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-[11px] text-[#F3EFE6]/60 mt-0.5",
							children: "Damage"
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "font-mono text-xl sm:text-2xl font-bold tabular-nums text-sky-300",
							children: ["+", totalScrapEarned]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-[11px] text-[#F3EFE6]/60 mt-0.5",
							children: "Total Scrap"
						})] })
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-1 sm:grid-cols-2 gap-3 mb-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "bg-[#141714] border border-sky-400/25 rounded-xl p-3.5 flex flex-col justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between gap-2 mb-2.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Hexagon, { className: "w-4 h-4 text-sky-300" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-xs font-mono uppercase tracking-wider font-bold text-[#F3EFE6]",
									children: "Scrap Rewards"
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "font-mono text-sm font-extrabold text-sky-300 tabular-nums",
								children: [
									"+",
									totalScrapEarned,
									" Scrap"
								]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-1 text-xs font-mono tabular-nums pb-2.5 border-b border-[#F3EFE6]/10",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between text-[#F3EFE6]/75",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Match Completion" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "text-[#F3EFE6]",
										children: ["+", scrapBreakdown.completionScrap]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between text-[#F3EFE6]/75",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
										"Eliminations (",
										result.eliminations,
										")"
									] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "text-[#F3EFE6]",
										children: ["+", scrapBreakdown.eliminationScrap]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between text-[#F3EFE6]/75",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Victory Bonus" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: scrapBreakdown.victoryBonusScrap > 0 ? "text-[#22C55E]" : "text-[#F3EFE6]/40",
										children: scrapBreakdown.victoryBonusScrap > 0 ? `+${scrapBreakdown.victoryBonusScrap}` : "0"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between text-[#F3EFE6]/75",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Performance Bonus" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: scrapBreakdown.performanceBonusScrap > 0 ? "text-sky-300" : "text-[#F3EFE6]/40",
										children: scrapBreakdown.performanceBonusScrap > 0 ? `+${scrapBreakdown.performanceBonusScrap}` : "0"
									})]
								}),
								scrapFromMilestones > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between text-[#86EFAC]",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Level Milestone Bonus" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["+", scrapFromMilestones] })]
								})
							]
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between text-xs font-mono tabular-nums pt-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-[#F3EFE6]/65",
								children: "Updated Balance"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "font-extrabold text-sky-300",
								children: [progression.scrap.toLocaleString(), " Scrap"]
							})]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "bg-[#141714] border border-[#F3EFE6]/12 rounded-xl p-3.5 flex flex-col justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between gap-2 mb-2.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "w-4 h-4 text-[#E08E26]" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-xs font-mono uppercase tracking-wider font-bold text-[#F3EFE6]",
									children: "Experience"
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "font-mono text-sm font-extrabold text-[#E08E26] tabular-nums",
								children: [
									"+",
									xpBreakdown?.totalXp ?? 0,
									" XP"
								]
							})]
						}), xpBreakdown && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-1 text-xs font-mono tabular-nums pb-2.5 mb-2 border-b border-[#F3EFE6]/10",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between text-[#F3EFE6]/75",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Match Completed" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "text-[#F3EFE6]",
										children: ["+", xpBreakdown.completionXp]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between text-[#F3EFE6]/75",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
										"Eliminations (",
										result.eliminations,
										")"
									] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "text-[#F3EFE6]",
										children: ["+", xpBreakdown.eliminationXp]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between text-[#F3EFE6]/75",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Victory Bonus" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: xpBreakdown.victoryBonusXp > 0 ? "text-[#22C55E]" : "text-[#F3EFE6]/40",
										children: xpBreakdown.victoryBonusXp > 0 ? `+${xpBreakdown.victoryBonusXp}` : "0"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between text-[#F3EFE6]/75",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Top-3 Survival" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: xpBreakdown.topThreeBonusXp > 0 ? "text-sky-400" : "text-[#F3EFE6]/40",
										children: xpBreakdown.topThreeBonusXp > 0 ? `+${xpBreakdown.topThreeBonusXp}` : "0"
									})]
								})
							]
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between gap-2 text-xs font-mono tabular-nums mb-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-2",
								children: [leveledUp ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "inline-flex items-center gap-1 font-bold text-[#E08E26]",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Star, { className: "w-3.5 h-3.5 fill-current" }),
										"LVL ",
										prevLevel,
										" → LVL ",
										newLevel
									]
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "font-bold text-[#F3EFE6]",
									children: ["Level ", newLevel]
								}), leveledUp && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "px-1.5 py-0.5 rounded bg-[#E08E26]/20 border border-[#E08E26]/50 text-[#E08E26] text-[10px] font-extrabold uppercase",
									children: "Level Up!"
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-[#F3EFE6]/75",
								children: [
									progression.xp,
									" / ",
									progression.xpToNext,
									" XP"
								]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "w-full h-2.5 rounded-full bg-[#1E221D] overflow-hidden border border-[#F3EFE6]/10",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "h-full bg-[#E08E26] transition-all duration-300",
								style: { width: `${xpPct}%` }
							})
						})] })]
					})]
				}),
				unlockedMilestones.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "bg-[#1A241B] border border-[#22C55E]/40 rounded-xl p-3 mb-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "text-[11px] font-mono uppercase tracking-wider text-[#86EFAC] font-bold flex items-center gap-1.5 mb-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Award, { className: "w-3.5 h-3.5" }), "Milestone Rewards Unlocked"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex flex-col gap-1",
						children: unlockedMilestones.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between text-xs gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "font-semibold text-[#F3EFE6]",
								children: [
									"LVL ",
									m.level,
									" · ",
									m.title
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-mono text-[#86EFAC] shrink-0",
								children: m.type === "currency" && m.scrapAmount ? `+${m.scrapAmount} Scrap` : "Cosmetic Unlocked"
							})]
						}, m.id))
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between text-xs text-[#F3EFE6]/65 mb-4 font-mono tabular-nums",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["Survival Time: ", formatPlaytime(result.survivalSec)] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "text-sky-300 font-bold",
						children: ["Scrap Balance: ", progression.scrap.toLocaleString()]
					})]
				}),
				onWatchRewardedAd && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "bg-[#141714] border border-[#E08E26]/30 rounded-xl p-3 mb-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2.5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-1.5 text-xs font-bold text-[#E08E26]",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Film, { className: "w-3.5 h-3.5 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
								"Optional Supply Drop (+",
								35,
								" Bonus Scrap)"
							] })]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[11px] text-[#F3EFE6]/65 mt-0.5",
							children: alreadyClaimedBonus ? `Bonus +35 Scrap claimed for this match.` : adStatusText ? adStatusText : isRewardedSupported ? `Watch a short ad to receive +35 bonus Scrap.` : "Rewarded ads are unavailable in local/offline mode."
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						disabled: alreadyClaimedBonus || adBusy || !isRewardedSupported,
						onClick: async () => {
							if (alreadyClaimedBonus || adBusy || !isRewardedSupported) return;
							setAdBusy(true);
							setAdStatusText(null);
							try {
								const outcome = await onWatchRewardedAd(rewardGrantId);
								if (outcome.granted) setAdStatusText(`+35 Bonus Scrap granted!`);
								else if (outcome.status === "skipped") setAdStatusText("Ad closed early — no bonus Scrap granted.");
								else if (outcome.status === "unavailable") setAdStatusText("Rewarded ads are not available right now.");
								else setAdStatusText("Ad failed to complete — no bonus Scrap granted.");
							} finally {
								setAdBusy(false);
							}
						},
						className: `min-h-[42px] px-3.5 rounded-lg font-mono text-xs font-bold shrink-0 transition whitespace-nowrap ${alreadyClaimedBonus ? "bg-[#1A2B1D] border border-[#22C55E]/40 text-[#86EFAC] cursor-default" : isRewardedSupported && !adBusy ? "bg-[#E08E26]/20 border border-[#E08E26] text-[#FDE68A] hover:bg-[#E08E26]/30" : "bg-[#1E221D] border border-[#F3EFE6]/15 text-[#F3EFE6]/45 cursor-not-allowed"}`,
						children: alreadyClaimedBonus ? `+35 Claimed` : adBusy ? "Loading Ad..." : isRewardedSupported ? `Watch Ad · +35 Scrap` : "Ads Unavailable"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col sm:flex-row gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						disabled: adBusy,
						onClick: onPlayAgain,
						className: "min-h-[48px] flex-1 px-5 rounded-xl bg-[#E08E26] text-[#141714] font-display text-xl font-extrabold tracking-wide flex items-center justify-center gap-2 hover:bg-[#EE9B32] transition whitespace-nowrap disabled:opacity-60",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { className: "w-4 h-4" }), "Play Again"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						disabled: adBusy,
						onClick: onMainMenu,
						className: "min-h-[48px] flex-1 px-5 rounded-xl bg-[#272C25] border border-[#F3EFE6]/20 text-[#F3EFE6] font-semibold text-sm flex items-center justify-center gap-2 hover:bg-[#31382E] transition whitespace-nowrap disabled:opacity-60",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(House, { className: "w-4 h-4" }), "Main Menu"]
					})]
				})
			]
		})
	});
}
// src/ui/SettingsScreen.tsx
var QUALITY_OPTIONS = [
	{
		id: "low",
		label: "Low"
	},
	{
		id: "medium",
		label: "Medium"
	},
	{
		id: "high",
		label: "High"
	}
];
function SettingsScreen({ settings, onUpdateSettings, onResetSettings, onResetProgress, onBack }) {
	const [confirmResetProgress, setConfirmResetProgress] = (0, import_react.useState)(false);
	const { isLandscape, isFullscreen, canFullscreen } = useViewportOrientation();
	const vibrationSupported = isVibrationSupported();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "w-full h-full overflow-y-auto bg-[#141714] tactical-bg-grid text-[#F3EFE6] flex flex-col",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
			className: "w-full max-w-4xl mx-auto px-4 sm:px-7 py-3 flex items-center justify-between gap-3 border-b border-[#F3EFE6]/12 shrink-0 bg-[#141714]/80",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: onBack,
					className: "min-h-[44px] px-3.5 rounded-xl border border-[#F3EFE6]/20 bg-[#1E221D] flex items-center gap-1.5 text-sm font-semibold hover:bg-[#282D26] transition whitespace-nowrap",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "w-4 h-4" }), "Back"]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-2xl sm:text-3xl font-extrabold tracking-wide",
					children: "Settings"
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: onResetSettings,
				className: "min-h-[44px] px-3.5 rounded-xl border border-[#F3EFE6]/20 bg-[#1E221D] text-xs sm:text-sm font-semibold flex items-center gap-1.5 text-[#F3EFE6]/85 hover:border-[#E08E26]/65 hover:text-[#F3EFE6] transition whitespace-nowrap",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { className: "w-4 h-4 text-[#E08E26]" }), "Reset to Default"]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
			className: "screen-transition flex-1 w-full max-w-4xl mx-auto px-4 sm:px-7 py-5 flex flex-col gap-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "bg-[#1B1F1A]/95 border border-[#F3EFE6]/15 rounded-2xl p-4 sm:p-5 flex flex-col gap-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display text-xl font-bold",
							children: "Audio"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between gap-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-sm font-semibold",
								children: "Sound Effects"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-xs text-[#F3EFE6]/60",
								children: "Cannon fire, armor impacts, ability cues, and movement rumble"
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => onUpdateSettings({
									...settings,
									soundEnabled: !settings.soundEnabled
								}),
								className: `min-h-[44px] px-4 rounded-xl border font-semibold text-sm flex items-center gap-2 transition whitespace-nowrap ${settings.soundEnabled ? "bg-[#E08E26] text-[#141714] border-[#E08E26]" : "bg-[#141714] text-[#F3EFE6]/70 border-[#F3EFE6]/20"}`,
								children: [settings.soundEnabled ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Volume2, { className: "w-4 h-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VolumeX, { className: "w-4 h-4" }), settings.soundEnabled ? "Enabled" : "Muted"]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap items-center justify-between gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								htmlFor: "sfx-volume-slider",
								className: "text-sm font-medium text-[#F3EFE6]/85",
								children: "Sound Effects Volume"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-3 w-full sm:w-64",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									id: "sfx-volume-slider",
									type: "range",
									min: 0,
									max: 100,
									value: Math.round(settings.soundVolume * 100),
									onChange: (e) => onUpdateSettings({
										...settings,
										soundVolume: Number(e.target.value) / 100
									}),
									className: "w-full accent-[#E08E26]"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "w-10 text-right font-mono text-xs tabular-nums",
									children: [Math.round(settings.soundVolume * 100), "%"]
								})]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "border-t border-[#F3EFE6]/10 pt-4 flex items-center justify-between gap-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-sm font-semibold",
								children: "Music"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-xs text-[#F3EFE6]/60",
								children: "Original tactical soundtrack during menus and battle"
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => onUpdateSettings({
									...settings,
									musicEnabled: !settings.musicEnabled
								}),
								className: `min-h-[44px] px-4 rounded-xl border font-semibold text-sm flex items-center gap-2 transition whitespace-nowrap ${settings.musicEnabled ? "bg-[#E08E26] text-[#141714] border-[#E08E26]" : "bg-[#141714] text-[#F3EFE6]/70 border-[#F3EFE6]/20"}`,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Music, { className: "w-4 h-4" }), settings.musicEnabled ? "Enabled" : "Muted"]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap items-center justify-between gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								htmlFor: "music-volume-slider",
								className: "text-sm font-medium text-[#F3EFE6]/85",
								children: "Music Volume"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-3 w-full sm:w-64",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									id: "music-volume-slider",
									type: "range",
									min: 0,
									max: 100,
									value: Math.round(settings.musicVolume * 100),
									onChange: (e) => onUpdateSettings({
										...settings,
										musicVolume: Number(e.target.value) / 100
									}),
									className: "w-full accent-[#E08E26]"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "w-10 text-right font-mono text-xs tabular-nums",
									children: [Math.round(settings.musicVolume * 100), "%"]
								})]
							})]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "bg-[#1B1F1A]/95 border border-[#F3EFE6]/15 rounded-2xl p-4 sm:p-5 flex flex-col gap-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display text-xl font-bold",
							children: "Graphics & Feedback"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap items-center justify-between gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-sm font-semibold",
								children: "Graphics Quality"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-xs text-[#F3EFE6]/60",
								children: "Adjusts particle pool density, tread decals, and ambient arena effects"
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex items-center gap-1 bg-[#141714] p-1 rounded-xl border border-[#F3EFE6]/15",
								children: QUALITY_OPTIONS.map((opt) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => onUpdateSettings({
										...settings,
										graphicsQuality: opt.id,
										lowDetailMode: opt.id === "low"
									}),
									className: `min-h-[38px] px-3.5 rounded-lg text-xs font-semibold transition whitespace-nowrap ${settings.graphicsQuality === opt.id ? "bg-[#E08E26] text-[#141714]" : "text-[#F3EFE6]/70 hover:text-[#F3EFE6]"}`,
									children: opt.label
								}, opt.id))
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between gap-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-sm font-semibold",
								children: "Screen Shake"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-xs text-[#F3EFE6]/60",
								children: "Subtle camera kick during barrel blasts and tank eliminations"
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => onUpdateSettings({
									...settings,
									screenShakeEnabled: !settings.screenShakeEnabled
								}),
								className: `min-h-[44px] px-4 rounded-xl border font-semibold text-sm transition whitespace-nowrap ${settings.screenShakeEnabled ? "bg-[#E08E26] text-[#141714] border-[#E08E26]" : "bg-[#141714] text-[#F3EFE6]/70 border-[#F3EFE6]/20"}`,
								children: settings.screenShakeEnabled ? "On" : "Off"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between gap-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-sm font-semibold",
								children: "Vibration"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-xs text-[#F3EFE6]/60",
								children: vibrationSupported ? "Short haptic pulses on cannon fire, ability use, and heavy hits" : "Hardware vibration is not supported on this device or browser"
							})] }), vibrationSupported ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => onUpdateSettings({
									...settings,
									vibrationEnabled: !settings.vibrationEnabled
								}),
								className: `min-h-[44px] px-4 rounded-xl border font-semibold text-sm transition whitespace-nowrap ${settings.vibrationEnabled ? "bg-[#E08E26] text-[#141714] border-[#E08E26]" : "bg-[#141714] text-[#F3EFE6]/70 border-[#F3EFE6]/20"}`,
								children: settings.vibrationEnabled ? "On" : "Off"
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "min-h-[44px] px-3.5 rounded-xl border border-[#F3EFE6]/12 bg-[#141714] text-xs font-mono text-[#F3EFE6]/45 flex items-center whitespace-nowrap",
								children: "Unsupported"
							})]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "bg-[#1B1F1A]/95 border border-[#F3EFE6]/15 rounded-2xl p-4 sm:p-5 flex flex-col gap-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display text-xl font-bold",
							children: "Controls & Match"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap items-center justify-between gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								htmlFor: "sensitivity-slider",
								className: "text-sm font-semibold block",
								children: "Control Sensitivity"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-xs text-[#F3EFE6]/60",
								children: "Scales virtual joystick response and turret tracking speed"
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-3 w-full sm:w-64",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									id: "sensitivity-slider",
									type: "range",
									min: 60,
									max: 150,
									step: 5,
									value: Math.round(settings.controlSensitivity * 100),
									onChange: (e) => onUpdateSettings({
										...settings,
										controlSensitivity: Number(e.target.value) / 100
									}),
									className: "w-full accent-[#E08E26]"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "w-12 text-right font-mono text-xs tabular-nums",
									children: [Math.round(settings.controlSensitivity * 100), "%"]
								})]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap items-center justify-between gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-sm font-semibold",
								children: "Virtual Joysticks"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-xs text-[#F3EFE6]/60",
								children: "Always display touch joysticks or auto-detect touchscreens"
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex items-center gap-1 bg-[#141714] p-1 rounded-xl border border-[#F3EFE6]/15",
								children: ["always", "auto"].map((opt) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => onUpdateSettings({
										...settings,
										showTouchControls: opt
									}),
									className: `min-h-[38px] px-3.5 rounded-lg text-xs font-semibold transition whitespace-nowrap ${settings.showTouchControls === opt ? "bg-[#E08E26] text-[#141714]" : "text-[#F3EFE6]/70 hover:text-[#F3EFE6]"}`,
									children: opt === "always" ? "Always Show" : "Touch Only"
								}, opt))
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between gap-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-sm font-semibold",
								children: "Auto-Fire on Full Aim"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-xs text-[#F3EFE6]/60",
								children: "Fire automatically when pushing the aiming stick to the outer ring"
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => onUpdateSettings({
									...settings,
									autoFireOnAim: !settings.autoFireOnAim
								}),
								className: `min-h-[44px] px-4 rounded-xl border font-semibold text-sm transition whitespace-nowrap ${settings.autoFireOnAim ? "bg-[#E08E26] text-[#141714] border-[#E08E26]" : "bg-[#141714] text-[#F3EFE6]/70 border-[#F3EFE6]/20"}`,
								children: settings.autoFireOnAim ? "On" : "Off"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap items-center justify-between gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-sm font-semibold",
								children: "Match Time Limit"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-xs text-[#F3EFE6]/60",
								children: "Timer winner uses highest remaining HP, then eliminations"
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex items-center gap-1 bg-[#141714] p-1 rounded-xl border border-[#F3EFE6]/15",
								children: [
									90,
									150,
									210
								].map((sec) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: () => onUpdateSettings({
										...settings,
										matchDurationSec: sec
									}),
									className: `min-h-[38px] px-3 rounded-lg font-mono text-xs font-semibold tabular-nums transition whitespace-nowrap ${settings.matchDurationSec === sec ? "bg-[#E08E26] text-[#141714]" : "text-[#F3EFE6]/70 hover:text-[#F3EFE6]"}`,
									children: [sec, "s"]
								}, sec))
							})]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "bg-[#1B1F1A]/95 border border-[#F3EFE6]/15 rounded-2xl p-4 sm:p-5 flex flex-col gap-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display text-xl font-bold",
							children: "Landscape & Display"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap items-center justify-between gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "text-sm font-semibold",
								children: ["Current Orientation: ", isLandscape ? "Landscape" : "Portrait"]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-xs text-[#F3EFE6]/60",
								children: "Lock fullscreen landscape mode on supported Android and desktop browsers"
							})] }), canFullscreen && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => {
									if (isFullscreen) exitLandscapeFullscreen();
									else enterLandscapeFullscreen();
								},
								className: `min-h-[44px] px-4 rounded-xl border font-semibold text-sm flex items-center gap-2 transition whitespace-nowrap ${isFullscreen ? "bg-[#E08E26] text-[#141714] border-[#E08E26]" : "bg-[#141714] text-[#F3EFE6] border-[#F3EFE6]/25 hover:border-[#F3EFE6]/45"}`,
								children: [isFullscreen ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Minimize2, { className: "w-4 h-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Maximize2, { className: "w-4 h-4" }), isFullscreen ? "Exit Fullscreen" : "Enter Landscape Fullscreen"]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between gap-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-sm font-semibold",
								children: "Portrait Rotation Prompt"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-xs text-[#F3EFE6]/60",
								children: "Show a landscape reminder when holding mobile devices vertically"
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => onUpdateSettings({
									...settings,
									landscapePromptEnabled: !settings.landscapePromptEnabled
								}),
								className: `min-h-[44px] px-4 rounded-xl border font-semibold text-sm transition whitespace-nowrap ${settings.landscapePromptEnabled ? "bg-[#E08E26] text-[#141714] border-[#E08E26]" : "bg-[#141714] text-[#F3EFE6]/70 border-[#F3EFE6]/20"}`,
								children: settings.landscapePromptEnabled ? "Enabled" : "Off"
							})]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "bg-[#1B1F1A]/95 border border-[#F3EFE6]/15 rounded-2xl p-4 sm:p-5 flex flex-wrap items-center justify-between gap-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-sm font-semibold",
						children: "Local Match Records"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-xs text-[#F3EFE6]/60",
						children: "Clears locally stored match counts, wins, eliminations, and selections"
					})] }), !confirmResetProgress ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => setConfirmResetProgress(true),
						className: "min-h-[44px] px-4 rounded-xl border border-red-500/40 text-red-400 text-sm font-semibold flex items-center gap-2 hover:bg-red-500/10 transition whitespace-nowrap",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "w-4 h-4" }), "Clear Local Records"]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => {
								onResetProgress();
								setConfirmResetProgress(false);
							},
							className: "min-h-[44px] px-4 rounded-xl bg-red-600 text-white text-sm font-semibold hover:bg-red-500 transition whitespace-nowrap",
							children: "Confirm Clear"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => setConfirmResetProgress(false),
							className: "min-h-[44px] px-4 rounded-xl border border-[#F3EFE6]/20 text-sm font-medium hover:bg-[#272C25] transition whitespace-nowrap",
							children: "Cancel"
						})]
					})]
				})
			]
		})]
	});
}
// src/ui/StatisticsScreen.tsx
function StatisticsScreen({ progression, missionsState, lastSavedAtMs, onOpenProfile, onOpenMissions, onBack }) {
	const matchesPlayed = progression.matchesPlayed;
	const matchesWon = progression.wins;
	const matchesLost = progression.defeats;
	const winRatePct = matchesPlayed > 0 ? (matchesWon / matchesPlayed * 100).toFixed(1) : "0.0";
	const unlockedAchievements = ACHIEVEMENT_DEFINITIONS.filter((def) => missionsState.achievements[def.id]?.completed);
	const customizedTanksCount = Object.keys(progression.tankCustomizations ?? {}).length;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "w-full h-full overflow-y-auto bg-[#141714] tactical-bg-grid text-[#F3EFE6] flex flex-col",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
			className: "w-full max-w-6xl mx-auto px-4 sm:px-7 py-3 flex flex-wrap items-center justify-between gap-3 border-b border-[#F3EFE6]/12 shrink-0 bg-[#141714]/80",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: onBack,
					className: "min-h-[44px] px-3.5 rounded-xl border border-[#F3EFE6]/20 bg-[#1E221D] flex items-center gap-1.5 text-sm font-semibold hover:bg-[#282D26] transition whitespace-nowrap",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "w-4 h-4" }), "Back"]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-2xl sm:text-3xl font-extrabold tracking-wide leading-none",
					children: "Combat Statistics"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-[11px] text-[#F3EFE6]/55 mt-0.5",
					children: [
						"Commander ",
						progression.playerName,
						" · Lifetime combat record, Scrap ledger & unlocks"
					]
				})] })]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-2.5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScrapBadge, { scrap: progression.scrap }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: onOpenProfile,
					className: "min-h-[44px] px-3.5 rounded-xl bg-[#1E221D] border border-[#F3EFE6]/20 text-xs sm:text-sm font-semibold hover:border-[#E08E26]/65 hover:bg-[#262C24] transition whitespace-nowrap",
					children: "Profile"
				})]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
			className: "screen-transition flex-1 w-full max-w-6xl mx-auto px-4 sm:px-7 py-4 sm:py-6 flex flex-col gap-5",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "bg-[#1B1F1A]/95 border border-[#F3EFE6]/15 rounded-2xl p-4 sm:p-5 shadow-xl",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center justify-between gap-2 mb-3.5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
						className: "font-display text-xl font-bold flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChartColumn, { className: "w-5 h-5 text-[#E08E26]" }), "Match Performance"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "text-xs font-mono text-[#F3EFE6]/60 tabular-nums",
						children: [
							"Level ",
							progression.level,
							" · ",
							progression.totalXpEarned.toLocaleString(),
							" Lifetime XP"
						]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "bg-[#141714] border border-[#F3EFE6]/12 rounded-xl p-3.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-1.5 text-[11px] text-[#F3EFE6]/60",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shield, { className: "w-3.5 h-3.5 text-[#E08E26]" }), "Matches Played"]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "font-mono text-2xl font-extrabold tabular-nums text-[#F3EFE6] mt-1",
								children: matchesPlayed.toLocaleString()
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "bg-[#141714] border border-[#22C55E]/25 rounded-xl p-3.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-1.5 text-[11px] text-[#F3EFE6]/60",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trophy, { className: "w-3.5 h-3.5 text-[#22C55E]" }), "Matches Won"]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "font-mono text-2xl font-extrabold tabular-nums text-[#22C55E] mt-1",
								children: matchesWon.toLocaleString()
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "bg-[#141714] border border-red-400/20 rounded-xl p-3.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-1.5 text-[11px] text-[#F3EFE6]/60",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skull, { className: "w-3.5 h-3.5 text-red-400" }), "Matches Lost"]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "font-mono text-2xl font-extrabold tabular-nums text-red-300 mt-1",
								children: matchesLost.toLocaleString()
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "bg-[#141714] border border-[#E08E26]/30 rounded-xl p-3.5",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-1.5 text-[11px] text-[#F3EFE6]/60",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Award, { className: "w-3.5 h-3.5 text-[#E08E26]" }), "Win Rate"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "font-mono text-2xl font-extrabold tabular-nums text-[#E08E26] mt-1",
									children: [winRatePct, "%"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-[10px] font-mono text-[#F3EFE6]/45 mt-0.5",
									children: matchesPlayed > 0 ? `${matchesWon}W / ${matchesPlayed} completed` : "No matches completed"
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "bg-[#141714] border border-[#F3EFE6]/12 rounded-xl p-3.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-1.5 text-[11px] text-[#F3EFE6]/60",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Crosshair, { className: "w-3.5 h-3.5 text-amber-400" }), "Total Eliminations"]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "font-mono text-2xl font-extrabold tabular-nums text-[#F3EFE6] mt-1",
								children: progression.totalEliminations.toLocaleString()
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "bg-[#141714] border border-[#F3EFE6]/12 rounded-xl p-3.5",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-1.5 text-[11px] text-[#F3EFE6]/60",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "w-3.5 h-3.5 text-sky-400" }), "Combat Time"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "font-mono text-xl sm:text-2xl font-extrabold tabular-nums text-sky-300 mt-1",
									children: formatPlaytime(progression.totalPlaytimeSec)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "text-[10px] font-mono text-[#F3EFE6]/45 mt-0.5",
									children: ["Best Rank: ", progression.bestPlacement ? `#${progression.bestPlacement}` : "—"]
								})
							]
						})
					]
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-1 lg:grid-cols-12 gap-5 items-start",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "lg:col-span-5 bg-[#1B1F1A]/95 border border-[#F3EFE6]/15 rounded-2xl p-4 sm:p-5 flex flex-col gap-3.5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
								className: "font-display text-xl font-bold flex items-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Hexagon, { className: "w-5 h-5 text-sky-300" }), "Scrap Economy Ledger"]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-[11px] font-mono text-sky-300/80",
								children: "Single Currency"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-2.5",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "bg-[#141714] border border-sky-400/25 rounded-xl p-3.5 flex items-center justify-between gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-xs text-[#F3EFE6]/65",
										children: "Current Scrap Balance"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-[11px] text-[#F3EFE6]/45 mt-0.5",
										children: "Available for Tank & Cosmetic Shops"
									})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "font-mono text-2xl font-extrabold tabular-nums text-sky-300",
										children: progression.scrap.toLocaleString()
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "bg-[#141714] border border-[#22C55E]/25 rounded-xl p-3.5 flex items-center justify-between gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-2.5",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "w-9 h-9 rounded-lg bg-[#22C55E]/15 border border-[#22C55E]/35 flex items-center justify-center text-[#22C55E] shrink-0",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TrendingUp, { className: "w-4 h-4" })
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "text-xs font-semibold text-[#F3EFE6]",
											children: "Total Scrap Earned"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "text-[11px] text-[#F3EFE6]/50",
											children: "Matches, milestones & mission claims"
										})] })]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "font-mono text-xl font-extrabold tabular-nums text-[#86EFAC]",
										children: ["+", progression.totalScrapEarned.toLocaleString()]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "bg-[#141714] border border-[#E08E26]/25 rounded-xl p-3.5 flex items-center justify-between gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-2.5",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "w-9 h-9 rounded-lg bg-[#E08E26]/15 border border-[#E08E26]/35 flex items-center justify-center text-[#E08E26] shrink-0",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TrendingDown, { className: "w-4 h-4" })
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "text-xs font-semibold text-[#F3EFE6]",
											children: "Total Scrap Spent"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "text-[11px] text-[#F3EFE6]/50",
											children: "Tank unlocks, paints, decals & skins"
										})] })]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "font-mono text-xl font-extrabold tabular-nums text-[#E08E26]",
										children: progression.totalScrapSpent.toLocaleString()
									})]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-1 pt-3 border-t border-[#F3EFE6]/10 flex items-center justify-between gap-2 text-[11px] font-mono text-[#F3EFE6]/55",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "inline-flex items-center gap-1.5",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HardDrive, { className: "w-3.5 h-3.5 text-[#22C55E]" }),
									"Save Format v",
									progression.saveVersion ?? 4,
									" · Auto-Saved"
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "tabular-nums",
								children: lastSavedAtMs ? new Date(lastSavedAtMs).toLocaleTimeString([], {
									hour: "2-digit",
									minute: "2-digit"
								}) : "Restored"
							})]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "lg:col-span-7 bg-[#1B1F1A]/95 border border-[#F3EFE6]/15 rounded-2xl p-4 sm:p-5 flex flex-col gap-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap items-center justify-between gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
								className: "font-display text-xl font-bold flex items-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Palette, { className: "w-5 h-5 text-[#E08E26]" }), "Unlocks & Achievements"]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: onOpenMissions,
								className: "min-h-[38px] px-3 rounded-lg bg-[#141714] border border-[#F3EFE6]/18 text-xs font-semibold text-[#E08E26] hover:border-[#E08E26]/65 transition",
								children: "View All Missions & Achievements"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-2 sm:grid-cols-4 gap-2.5 font-mono tabular-nums",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "bg-[#141714] border border-[#F3EFE6]/10 rounded-xl p-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-[10px] font-sans text-[#F3EFE6]/55",
										children: "Tanks Unlocked"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "text-lg font-bold text-[#F3EFE6] mt-0.5",
										children: [
											progression.unlockedTanks.length,
											" / ",
											TANK_LIST.length
										]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "bg-[#141714] border border-[#F3EFE6]/10 rounded-xl p-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-[10px] font-sans text-[#F3EFE6]/55",
										children: "Paint Colors"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-lg font-bold text-[#F3EFE6] mt-0.5",
										children: progression.unlockedPaintColors.length
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "bg-[#141714] border border-[#F3EFE6]/10 rounded-xl p-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-[10px] font-sans text-[#F3EFE6]/55",
										children: "Decals & Presets"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "text-lg font-bold text-[#F3EFE6] mt-0.5",
										children: [
											progression.unlockedDecals.length,
											" / ",
											progression.unlockedPresets.length
										]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "bg-[#141714] border border-[#F3EFE6]/10 rounded-xl p-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-[10px] font-sans text-[#F3EFE6]/55",
										children: "Custom Looks Saved"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-lg font-bold text-[#86EFAC] mt-0.5",
										children: customizedTanksCount
									})]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between text-xs mb-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "font-semibold text-[#F3EFE6]/85",
								children: [
									"Unlocked Achievements (",
									unlockedAchievements.length,
									" / ",
									ACHIEVEMENT_DEFINITIONS.length,
									")"
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "font-mono text-[#E08E26]",
								children: [Math.round(unlockedAchievements.length / Math.max(1, ACHIEVEMENT_DEFINITIONS.length) * 100), "% Complete"]
							})]
						}), unlockedAchievements.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "rounded-xl bg-[#141714] border border-[#F3EFE6]/10 p-4 text-xs text-[#F3EFE6]/60 text-center",
							children: "No achievements unlocked yet. Complete matches, destroy obstacles, and try new tanks to earn permanent badges."
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid grid-cols-1 sm:grid-cols-2 gap-2 max-h-56 overflow-y-auto pr-0.5",
							children: unlockedAchievements.map((ach) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "rounded-xl bg-[#141714] border border-[#22C55E]/30 px-3 py-2 flex items-center justify-between gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "min-w-0",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-xs font-bold text-[#F3EFE6] truncate",
										children: ach.title
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "text-[10px] text-[#F3EFE6]/55 truncate",
										children: [
											ach.category,
											" · ",
											ach.description
										]
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-[10px] font-mono uppercase px-1.5 py-0.5 rounded bg-[#22C55E]/15 text-[#86EFAC] shrink-0",
									children: "Unlocked"
								})]
							}, ach.id))
						})] })
					]
				})]
			})]
		})]
	});
}
// src/ui/TankRosterScreen.tsx
function StatBar({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center gap-3 text-xs",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "w-20 text-[#F3EFE6]/65 font-medium",
				children: label
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex-1 h-2 bg-[#141714] rounded-sm overflow-hidden border border-[#F3EFE6]/10",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "h-full bg-[#E08E26] transition-all duration-200",
					style: { width: `${value * 10}%` }
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "w-7 text-right font-mono tabular-nums text-[#F3EFE6]/85",
				children: [value, "/10"]
			})
		]
	});
}
function TankRosterScreen({ progression, sessionCustomizations, isRewardedSupported = false, onWatchRewardedAd, onSelectTank, onPurchaseTank, onOpenGarage, onBack, onStartBattle }) {
	const [inspectedId, setInspectedId] = (0, import_react.useState)(progression.selectedTank);
	const [adBusy, setAdBusy] = (0, import_react.useState)(false);
	const [shopNotice, setShopNotice] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		setInspectedId((curr) => curr in TANK_DEFINITIONS ? curr : progression.selectedTank);
	}, [progression.selectedTank]);
	const inspectedTank = TANK_DEFINITIONS[inspectedId] || TANK_DEFINITIONS.assault;
	const effectiveMaxHp = getEffectiveTankMaxHp(inspectedTank);
	const effectiveMoveSpeed = getEffectiveTankMoveSpeed(inspectedTank);
	const effectiveRange = getEffectiveTankProjectileRange(inspectedTank);
	const effectiveReloadSec = getEffectiveTankReloadSec(inspectedTank);
	const isUnlocked = isTankUnlocked(progression, inspectedTank.id);
	const isSelected = isUnlocked && progression.selectedTank === inspectedTank.id;
	const canAfford = progression.scrap >= inspectedTank.unlockCost;
	const scrapMissing = Math.max(0, inspectedTank.unlockCost - progression.scrap);
	const handleBuyTank = (tankId) => {
		const def = TANK_DEFINITIONS[tankId];
		const outcome = onPurchaseTank(tankId);
		if (outcome.success) setShopNotice({
			type: "success",
			text: `${def.name} unlocked and ready for deployment! (-${outcome.cost} Scrap)`
		});
		else if (outcome.reason === "insufficient_scrap") setShopNotice({
			type: "error",
			text: `Insufficient Scrap: need ${Math.max(0, outcome.cost - outcome.remainingScrap)} more Scrap to unlock ${def.name}.`
		});
		else if (outcome.reason === "already_unlocked") setShopNotice({
			type: "error",
			text: `${def.name} is already unlocked.`
		});
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "w-full h-full overflow-y-auto bg-[#141714] tactical-bg-grid text-[#F3EFE6] flex flex-col",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
			className: "w-full max-w-6xl mx-auto px-4 sm:px-7 py-3 flex flex-wrap items-center justify-between gap-3 border-b border-[#F3EFE6]/12 shrink-0 bg-[#141714]/80",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: onBack,
					className: "min-h-[44px] px-3.5 rounded-xl border border-[#F3EFE6]/20 bg-[#1E221D] flex items-center gap-1.5 text-sm font-semibold hover:bg-[#282D26] transition whitespace-nowrap",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "w-4 h-4" }), "Back"]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-2xl sm:text-3xl font-extrabold tracking-wide leading-none",
					children: "Tank Shop & Hangar"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-[11px] text-[#F3EFE6]/55 mt-0.5",
					children: [
						progression.unlockedTanks.length,
						" of ",
						TANK_LIST.length,
						" tanks unlocked · Unlock new chassis with Scrap"
					]
				})] })]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-2.5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScrapBadge, { scrap: progression.scrap }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: onOpenGarage,
					className: "min-h-[44px] px-3.5 sm:px-4 rounded-xl bg-[#1E221D] border border-[#F3EFE6]/20 text-xs sm:text-sm font-semibold flex items-center gap-2 hover:border-[#E08E26]/65 hover:bg-[#262C24] transition whitespace-nowrap",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wrench, { className: "w-4 h-4 text-[#E08E26]" }), "Open Garage"]
				})]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
			className: "screen-transition flex-1 w-full max-w-6xl mx-auto px-4 sm:px-7 py-3.5 sm:py-5 grid grid-cols-1 landscape:grid-cols-12 lg:grid-cols-12 gap-4 sm:gap-5 items-start",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "landscape:col-span-7 lg:col-span-7 flex flex-col gap-3",
				children: [shopNotice && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: `rounded-xl px-3.5 py-2.5 text-xs font-semibold border flex items-center justify-between gap-2 ${shopNotice.type === "success" ? "bg-[#1A2B1D] border-[#22C55E]/50 text-[#86EFAC]" : "bg-[#2B1B1B] border-red-400/45 text-red-300"}`,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: shopNotice.text }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setShopNotice(null),
						className: "text-[11px] font-mono opacity-75 hover:opacity-100 px-1.5",
						children: "Dismiss"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-2 sm:grid-cols-3 gap-2.5 sm:gap-3",
					children: TANK_LIST.map((tank) => {
						const unlocked = isTankUnlocked(progression, tank.id);
						const selected = unlocked && progression.selectedTank === tank.id;
						const focused = inspectedTank.id === tank.id;
						const affordable = progression.scrap >= tank.unlockCost;
						const customForCard = sessionCustomizations?.[tank.id] ?? progression.tankCustomizations?.[tank.id] ?? null;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => {
								setInspectedId(tank.id);
								setShopNotice(null);
								if (unlocked) onSelectTank(tank.id);
							},
							"aria-pressed": selected,
							className: `text-left rounded-xl p-3 border transition flex flex-col items-center gap-2 relative ${selected ? "bg-[#252B23] border-[#E08E26] shadow-lg" : focused ? "bg-[#212620] border-[#F3EFE6]/45" : unlocked ? "bg-[#1B1F1A]/95 border-[#F3EFE6]/12 hover:border-[#F3EFE6]/30" : "bg-[#171A16]/90 border-[#F3EFE6]/10 hover:border-sky-400/45"}`,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "relative",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: unlocked ? "" : "opacity-70 saturate-75",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TankPreviewSvg, {
										tank,
										cosmeticId: progression.equippedCosmetic,
										customization: customForCard,
										size: 78
									})
								}), selected ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "absolute -top-1 -right-1 w-6 h-6 rounded-full bg-[#22C55E] text-[#141714] flex items-center justify-center shadow",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "w-3.5 h-3.5 stroke-[3]" })
								}) : !unlocked ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "absolute -top-1 -right-1 w-6 h-6 rounded-full bg-[#141714] border border-sky-400/50 text-sky-300 flex items-center justify-center shadow",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, { className: "w-3.5 h-3.5" })
								}) : null]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "w-full text-center",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "font-display text-lg font-bold leading-tight truncate text-[#F3EFE6]",
										children: tank.name
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-[11px] text-[#F3EFE6]/60 truncate",
										children: tank.role
									}),
									unlocked ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: `mt-1 text-[10px] font-mono uppercase tracking-wider font-semibold ${selected ? "text-[#22C55E]" : "text-[#F3EFE6]/55"}`,
										children: selected ? "Selected" : "Unlocked"
									}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: `mt-1 inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[10px] font-mono font-bold tabular-nums border ${affordable ? "bg-sky-500/15 border-sky-400/45 text-sky-300" : "bg-[#141714] border-[#F3EFE6]/15 text-[#F3EFE6]/55"}`,
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Hexagon, { className: "w-2.5 h-2.5" }),
											tank.unlockCost,
											" Scrap"
										]
									})
								]
							})]
						}, tank.id);
					})
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
				className: "landscape:col-span-5 lg:col-span-5 bg-[#1B1F1A]/95 border border-[#F3EFE6]/15 rounded-2xl p-4 sm:p-5 flex flex-col gap-3.5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TankPreviewSvg, {
							tank: inspectedTank,
							cosmeticId: progression.equippedCosmetic,
							customization: sessionCustomizations?.[inspectedTank.id] ?? progression.tankCustomizations?.[inspectedTank.id] ?? null,
							size: 86,
							className: "shrink-0"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0 flex-1",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "text-xs text-[#E08E26] font-medium truncate",
										children: [
											inspectedTank.role,
											" · ",
											effectiveMaxHp,
											" HP"
										]
									}), !isUnlocked ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "inline-flex items-center gap-1 px-2 py-0.5 rounded bg-[#141714] border border-sky-400/40 text-sky-300 text-[10px] font-mono font-bold shrink-0",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, { className: "w-2.5 h-2.5" }), "Locked"]
									}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "inline-flex items-center gap-1 px-2 py-0.5 rounded bg-[#22C55E]/15 border border-[#22C55E]/35 text-[#86EFAC] text-[10px] font-mono font-bold shrink-0",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "w-2.5 h-2.5" }), "Owned"]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "font-display text-3xl font-extrabold text-[#F3EFE6] leading-tight truncate",
									children: inspectedTank.name
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs text-[#F3EFE6]/75 mt-1 leading-relaxed",
									children: inspectedTank.description
								})
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col gap-2 pt-2 border-t border-[#F3EFE6]/10",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatBar, {
								label: "Armor",
								value: inspectedTank.ratings.armor
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatBar, {
								label: "Firepower",
								value: inspectedTank.ratings.firepower
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatBar, {
								label: "Mobility",
								value: inspectedTank.ratings.mobility
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatBar, {
								label: "Range",
								value: inspectedTank.ratings.range
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-3 gap-2 pt-2 border-t border-[#F3EFE6]/10 text-xs font-mono tabular-nums",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "bg-[#141714] border border-[#F3EFE6]/10 rounded-lg px-2.5 py-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-[10px] font-sans text-[#F3EFE6]/55",
									children: "Health"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "font-bold text-[#F3EFE6]",
									children: [effectiveMaxHp, " HP"]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "bg-[#141714] border border-[#F3EFE6]/10 rounded-lg px-2.5 py-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-[10px] font-sans text-[#F3EFE6]/55",
									children: "Move Speed"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "font-bold text-[#F3EFE6]",
									children: effectiveMoveSpeed
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "bg-[#141714] border border-[#F3EFE6]/10 rounded-lg px-2.5 py-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-[10px] font-sans text-[#F3EFE6]/55",
									children: "Proj. Range"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "font-bold text-[#F3EFE6]",
									children: effectiveRange
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "bg-[#141714] border border-[#F3EFE6]/10 rounded-lg px-2.5 py-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-[10px] font-sans text-[#F3EFE6]/55",
									children: "Magazine"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "font-bold text-[#E08E26]",
									children: [inspectedTank.stats.magazineCapacity, " Rounds"]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "bg-[#141714] border border-[#F3EFE6]/10 rounded-lg px-2.5 py-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-[10px] font-sans text-[#F3EFE6]/55",
									children: "Reload"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "font-bold text-emerald-400",
									children: [effectiveReloadSec.toFixed(2), "s"]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "bg-[#141714] border border-[#F3EFE6]/10 rounded-lg px-2.5 py-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-[10px] font-sans text-[#F3EFE6]/55",
									children: "Damage"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "font-bold text-[#F3EFE6]",
									children: inspectedTank.stats.projectileDamage
								})]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col gap-2 pt-2 border-t border-[#F3EFE6]/10 text-xs",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "bg-[#141714] border border-[#F3EFE6]/10 rounded-lg p-2.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between font-semibold text-[#E08E26]",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "inline-flex items-center gap-1.5",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Zap, { className: "w-3.5 h-3.5" }),
										"Active: ",
										inspectedTank.activeAbility.name
									]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "font-mono tabular-nums text-[#F3EFE6]/65",
									children: [inspectedTank.activeAbility.cooldownSec, "s CD"]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[#F3EFE6]/75 mt-1 leading-relaxed",
								children: inspectedTank.activeAbility.description
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "bg-[#141714] border border-[#F3EFE6]/10 rounded-lg p-2.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "inline-flex items-center gap-1.5 font-semibold text-emerald-400",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shield, { className: "w-3.5 h-3.5" }),
									"Passive: ",
									inspectedTank.passiveAbility.name
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[#F3EFE6]/75 mt-1 leading-relaxed",
								children: inspectedTank.passiveAbility.description
							})]
						})]
					}),
					!isUnlocked ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "pt-2 border-t border-[#F3EFE6]/10 space-y-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between text-xs font-mono tabular-nums",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-[#F3EFE6]/65",
									children: "Unlock Cost"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "font-bold text-sky-300",
									children: [inspectedTank.unlockCost, " Scrap"]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								disabled: !canAfford,
								onClick: () => handleBuyTank(inspectedTank.id),
								className: `min-h-[48px] w-full px-5 rounded-xl font-display text-lg font-extrabold tracking-wide flex items-center justify-center gap-2 transition whitespace-nowrap ${canAfford ? "bg-sky-400 text-[#141714] hover:bg-sky-300 shadow-lg" : "bg-[#141714] border border-[#F3EFE6]/15 text-[#F3EFE6]/45 cursor-not-allowed"}`,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShoppingCart, { className: "w-4 h-4" }), canAfford ? `Unlock Tank · ${inspectedTank.unlockCost} Scrap` : `Need ${scrapMissing} More Scrap`]
							}),
							onWatchRewardedAd && !canAfford && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								disabled: !isRewardedSupported || adBusy,
								onClick: async () => {
									if (!isRewardedSupported || adBusy) return;
									setAdBusy(true);
									try {
										const outcome = await onWatchRewardedAd(`shop_${Date.now()}`);
										if (outcome.granted) setShopNotice({
											type: "success",
											text: `Supply Drop received: +35 Scrap!`
										});
										else if (outcome.status === "skipped") setShopNotice({
											type: "error",
											text: "Ad closed early — no bonus Scrap awarded."
										});
										else setShopNotice({
											type: "error",
											text: "Rewarded ads are unavailable offline or right now."
										});
									} finally {
										setAdBusy(false);
									}
								},
								className: `min-h-[40px] w-full px-3 rounded-lg border text-xs font-mono font-semibold flex items-center justify-center gap-1.5 transition ${isRewardedSupported && !adBusy ? "bg-[#222820] border-[#E08E26]/65 text-[#FDE68A] hover:bg-[#2B3227]" : "bg-[#141714] border-[#F3EFE6]/12 text-[#F3EFE6]/40 cursor-not-allowed"}`,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Film, { className: "w-3.5 h-3.5" }), adBusy ? "Loading Ad..." : isRewardedSupported ? `Optional Ad · +35 Scrap` : "Optional Ad (+35 Scrap) · Offline Unavailable"]
							})
						]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "pt-1 flex items-center gap-2.5",
						children: [!isSelected ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => onSelectTank(inspectedTank.id),
							className: "min-h-[46px] flex-1 px-4 rounded-xl bg-[#272D25] border border-[#F3EFE6]/25 text-sm font-semibold hover:bg-[#31382E] transition whitespace-nowrap",
							children: "Select Tank"
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: onOpenGarage,
							className: "min-h-[46px] flex-1 px-4 rounded-xl bg-[#272D25] border border-[#F3EFE6]/25 text-sm font-semibold flex items-center justify-center gap-2 hover:bg-[#31382E] transition whitespace-nowrap",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wrench, { className: "w-4 h-4 text-[#E08E26]" }), "Customize in Garage"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => {
								onSelectTank(inspectedTank.id);
								onStartBattle(inspectedTank.id);
							},
							className: "min-h-[46px] flex-1 px-5 rounded-xl bg-[#E08E26] text-[#141714] font-display text-lg font-extrabold tracking-wide flex items-center justify-center gap-2 hover:bg-[#EE9B32] transition whitespace-nowrap",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "w-4 h-4 fill-current" }), "Play Match"]
						})]
					})
				]
			})]
		})]
	});
}
// src/App.tsx
function App() {
	const [screen, setScreen] = (0, import_react.useState)("MAIN_MENU");
	const screenRef = (0, import_react.useRef)(screen);
	screenRef.current = screen;
	const [previousMenuScreen, setPreviousMenuScreen] = (0, import_react.useState)("MAIN_MENU");
	const [progression, setProgression] = (0, import_react.useState)(() => loadProgression());
	const progressionRef = (0, import_react.useRef)(progression);
	progressionRef.current = progression;
	const [missionsState, setMissionsState] = (0, import_react.useState)(() => loadMissions(void 0, Date.now(), progressionRef.current));
	const missionsRef = (0, import_react.useRef)(missionsState);
	missionsRef.current = missionsState;
	const [settings, setSettings] = (0, import_react.useState)(() => loadSettings());
	const [lastResult, setLastResult] = (0, import_react.useState)(null);
	const [lastMatchSummary, setLastMatchSummary] = (0, import_react.useState)(null);
	const [levelUpModalSummary, setLevelUpModalSummary] = (0, import_react.useState)(null);
	const [showLevelUpModal, setShowLevelUpModal] = (0, import_react.useState)(false);
	const [matchInstanceKey, setMatchInstanceKey] = (0, import_react.useState)(1);
	const [dismissedPortraitPrompt, setDismissedPortraitPrompt] = (0, import_react.useState)(false);
	const [lastSavedAtMs, setLastSavedAtMs] = (0, import_react.useState)(null);
	const [saveFeedbackText, setSaveFeedbackText] = (0, import_react.useState)(null);
	const [bridgeReady, setBridgeReady] = (0, import_react.useState)(false);
	const [bridgeState, setBridgeState] = (0, import_react.useState)(() => platformBridge.getState());
	const [transitioningAd, setTransitioningAd] = (0, import_react.useState)(false);
	const saveToastTimerRef = (0, import_react.useRef)(null);
	const { isPortrait, isTouchDevice, width, canFullscreen } = useViewportOrientation();
	const showLandscapeOverlay = settings.landscapePromptEnabled && !dismissedPortraitPrompt && isPortrait && (isTouchDevice || width < 640);
	(0, import_react.useEffect)(() => {
		const unsubscribe = subscribeSaveEvents((ev) => {
			if (ev.status === "saved") {
				setLastSavedAtMs(ev.timestampMs);
				if (screenRef.current === "IN_GAME") return;
				setSaveFeedbackText("Progress Saved");
				if (saveToastTimerRef.current !== null) window.clearTimeout(saveToastTimerRef.current);
				saveToastTimerRef.current = window.setTimeout(() => {
					setSaveFeedbackText(null);
					saveToastTimerRef.current = null;
				}, 1600);
			}
		});
		return () => {
			unsubscribe();
			if (saveToastTimerRef.current !== null) window.clearTimeout(saveToastTimerRef.current);
		};
	}, []);
	(0, import_react.useEffect)(() => {
		const unsubState = platformBridge.subscribeState((nextState) => {
			setBridgeState(nextState);
			soundFX.setPlatformMuted(!nextState.isAudioEnabled);
			soundFX.setAdPaused(nextState.isAdPlaying || nextState.isPlatformPaused);
		});
		let active = true;
		platformBridge.init().then(async () => {
			const hydrated = await hydrateFromPlatformStorage();
			if (!active) return;
			if (hydrated.progression) {
				progressionRef.current = hydrated.progression;
				setProgression(hydrated.progression);
			}
			if (hydrated.missions) {
				missionsRef.current = hydrated.missions;
				setMissionsState(hydrated.missions);
			}
			platformBridge.notifyGameReady();
			platformBridge.trackEvent("game_started", { platform_id: platformBridge.platformId });
		}).finally(() => {
			if (active) setBridgeReady(true);
		});
		return () => {
			active = false;
			unsubState();
		};
	}, []);
	(0, import_react.useEffect)(() => {
		soundFX.configure(settings.soundEnabled, settings.soundVolume, settings.musicEnabled, settings.musicVolume);
	}, [settings]);
	(0, import_react.useEffect)(() => {
		soundFX.setMusicMode(screen === "IN_GAME" ? "battle" : screen === "RESULTS" ? "none" : "menu");
	}, [screen]);
	const checkMissionResets = (0, import_react.useCallback)(() => {
		const { state: checked, dailyReset, weeklyReset } = ensureMissionPeriodsCurrent(missionsRef.current);
		if (dailyReset || weeklyReset || checked !== missionsRef.current) {
			missionsRef.current = checked;
			setMissionsState(checked);
			saveMissions(checked);
		}
	}, []);
	(0, import_react.useEffect)(() => {
		const onFocus = () => checkMissionResets();
		window.addEventListener("focus", onFocus);
		return () => window.removeEventListener("focus", onFocus);
	}, [checkMissionResets]);
	(0, import_react.useEffect)(() => {
		return gameBridge.onGameplayEvent((event) => {
			const { nextState, applied } = applyGameplayEvent(missionsRef.current, event);
			if (applied || nextState !== missionsRef.current) {
				missionsRef.current = nextState;
				setMissionsState(nextState);
				saveMissions(nextState);
			}
		});
	}, []);
	(0, import_react.useEffect)(() => {
		return gameBridge.onMatchEnd((result) => {
			const { progression: nextProgression, summary } = applyMatchResultToProgression(progressionRef.current, result);
			progressionRef.current = nextProgression;
			setProgression(nextProgression);
			setLastResult(result);
			setLastMatchSummary(summary);
			if (!summary.alreadyProcessed) {
				platformBridge.recordCompletedMatch();
				platformBridge.trackEvent("match_completed", {
					tank_id: result.tankId,
					arena_id: result.arenaId,
					placement: result.placement,
					eliminations: result.eliminations,
					survival_sec: result.survivalSec
				});
				platformBridge.trackEvent(result.victory ? "match_victory" : "match_defeat", {
					tank_id: result.tankId,
					arena_id: result.arenaId,
					placement: result.placement
				});
			}
			if (!summary.alreadyProcessed && summary.levelsGained > 0) {
				setLevelUpModalSummary(summary);
				setShowLevelUpModal(true);
			} else {
				setLevelUpModalSummary(null);
				setShowLevelUpModal(false);
			}
			setScreen("RESULTS");
		});
	}, []);
	const navigateTo = (0, import_react.useCallback)((target) => {
		if (target === screen) return;
		if (target === "MAIN_MENU" || target === "MISSIONS") checkMissionResets();
		if (screen === "MAIN_MENU" || screen === "GARAGE" || screen === "TANK_COLLECTION" || screen === "ARENA_SELECT") setPreviousMenuScreen(screen);
		setScreen(target);
	}, [checkMissionResets, screen]);
	const handleSelectArena = (0, import_react.useCallback)((arenaId) => {
		setProgression((prev) => {
			const next = {
				...prev,
				selectedArena: arenaId
			};
			progressionRef.current = next;
			saveProgression(next);
			return next;
		});
	}, []);
	const handleSelectTank = (0, import_react.useCallback)((tankId) => {
		setProgression((prev) => {
			if (!TANK_DEFINITIONS[tankId]?.implemented) return prev;
			if (!isTankUnlocked(prev, tankId)) return prev;
			const next = {
				...prev,
				selectedTank: tankId
			};
			progressionRef.current = next;
			saveProgression(next);
			return next;
		});
	}, []);
	const handleUpdateSettings = (0, import_react.useCallback)((next) => {
		const normalized = {
			...next,
			lowDetailMode: next.graphicsQuality === "low"
		};
		setSettings(normalized);
		saveSettings(normalized);
		gameBridge.emitSettingsChange(normalized);
	}, []);
	const handleResetSettings = (0, import_react.useCallback)(() => {
		const defaults = resetSettingsToDefault();
		setSettings(defaults);
		gameBridge.emitSettingsChange(defaults);
	}, []);
	const handleToggleSound = (0, import_react.useCallback)(() => {
		soundFX.unlockFromUserGesture();
		setSettings((prev) => {
			const next = {
				...prev,
				soundEnabled: !prev.soundEnabled
			};
			saveSettings(next);
			gameBridge.emitSettingsChange(next);
			return next;
		});
	}, []);
	const handleToggleMusic = (0, import_react.useCallback)(() => {
		soundFX.unlockFromUserGesture();
		setSettings((prev) => {
			const next = {
				...prev,
				musicEnabled: !prev.musicEnabled
			};
			saveSettings(next);
			gameBridge.emitSettingsChange(next);
			return next;
		});
	}, []);
	const handleUpdatePlayerName = (0, import_react.useCallback)((name) => {
		setProgression((prev) => {
			const next = updatePlayerDisplayName(prev, name);
			progressionRef.current = next;
			return next;
		});
	}, []);
	const handleEquipCosmetic = (0, import_react.useCallback)((cosmeticId) => {
		setProgression((prev) => {
			const next = equipPlayerCosmetic(prev, cosmeticId);
			progressionRef.current = next;
			return next;
		});
	}, []);
	const handleApplyTankCustomization = (0, import_react.useCallback)((tankId, customization) => {
		setProgression((prev) => {
			const next = saveTankCustomization(prev, tankId, customization);
			progressionRef.current = next;
			return next;
		});
	}, []);
	const handleResetTankCustomization = (0, import_react.useCallback)((tankId) => {
		setProgression((prev) => {
			const next = resetSavedTankCustomization(prev, tankId);
			progressionRef.current = next;
			return next;
		});
	}, []);
	const handlePurchaseTank = (0, import_react.useCallback)((tankId) => {
		const outcome = buyTankWithScrap(progressionRef.current, tankId);
		if (outcome.success) {
			progressionRef.current = outcome.nextProgression;
			setProgression(outcome.nextProgression);
			platformBridge.trackEvent("tank_unlocked", {
				tank_id: tankId,
				cost_scrap: outcome.cost
			});
		}
		return outcome;
	}, []);
	const handleWatchRewardedAd = (0, import_react.useCallback)(async (grantId) => {
		const outcome = await platformBridge.showRewardedAd(grantId);
		if (outcome.granted) {
			const rewardRes = grantRewardedAdScrap(progressionRef.current, grantId, 35);
			if (rewardRes.granted) {
				progressionRef.current = rewardRes.nextProgression;
				setProgression(rewardRes.nextProgression);
			}
		}
		return outcome;
	}, []);
	const handlePurchasePaintColor = (0, import_react.useCallback)((hex) => {
		const outcome = buyPaintColorWithScrap(progressionRef.current, hex);
		if (outcome.success) {
			progressionRef.current = outcome.nextProgression;
			setProgression(outcome.nextProgression);
		}
		return outcome;
	}, []);
	const handlePurchaseCustomPaint = (0, import_react.useCallback)(() => {
		const outcome = buyCustomPaintStudioWithScrap(progressionRef.current);
		if (outcome.success) {
			progressionRef.current = outcome.nextProgression;
			setProgression(outcome.nextProgression);
		}
		return outcome;
	}, []);
	const handlePurchaseDecal = (0, import_react.useCallback)((decalId) => {
		const outcome = buyDecalWithScrap(progressionRef.current, decalId);
		if (outcome.success) {
			progressionRef.current = outcome.nextProgression;
			setProgression(outcome.nextProgression);
		}
		return outcome;
	}, []);
	const handlePurchasePreset = (0, import_react.useCallback)((presetId) => {
		const outcome = buyPresetWithScrap(progressionRef.current, presetId);
		if (outcome.success) {
			progressionRef.current = outcome.nextProgression;
			setProgression(outcome.nextProgression);
		}
		return outcome;
	}, []);
	const handlePurchaseCosmetic = (0, import_react.useCallback)((cosmeticId) => {
		const outcome = buySpecialCosmeticWithScrap(progressionRef.current, cosmeticId);
		if (outcome.success) {
			progressionRef.current = outcome.nextProgression;
			setProgression(outcome.nextProgression);
		}
		return outcome;
	}, []);
	const handleClaimMissionReward = (0, import_react.useCallback)((scope, id) => {
		const { nextProgression, nextMissions, outcome } = claimMissionOrAchievementReward(progressionRef.current, missionsRef.current, scope, id);
		if (outcome.claimed) {
			progressionRef.current = nextProgression;
			missionsRef.current = nextMissions;
			setProgression(nextProgression);
			setMissionsState(nextMissions);
			saveProgression(nextProgression);
			saveMissions(nextMissions);
			if (outcome.levelsGained > 0) {
				setLevelUpModalSummary({
					matchId: `claim_${scope}_${id}`,
					xpBreakdown: {
						completionXp: outcome.xpAwarded,
						victoryBonusXp: 0,
						eliminationXp: 0,
						topThreeBonusXp: 0,
						totalXp: outcome.xpAwarded
					},
					previousLevel: outcome.previousLevel,
					newLevel: outcome.newLevel,
					previousXp: 0,
					previousXpToNext: 0,
					newXp: nextProgression.xp,
					newXpToNext: nextProgression.xpToNext,
					levelsGained: outcome.levelsGained,
					unlockedMilestones: outcome.unlockedMilestones,
					scrapFromMatch: outcome.scrapAwarded,
					scrapFromMilestones: 0,
					totalScrapAwarded: outcome.scrapAwarded,
					alreadyProcessed: false
				});
				setShowLevelUpModal(true);
			}
		}
		return outcome;
	}, []);
	const handleResetProgress = (0, import_react.useCallback)(() => {
		const fresh = resetAllLocalData();
		progressionRef.current = fresh.progression;
		missionsRef.current = fresh.missions;
		setProgression(fresh.progression);
		setMissionsState(fresh.missions);
		setSettings(fresh.settings);
		setLastResult(null);
		setLastMatchSummary(null);
		setLevelUpModalSummary(null);
		setShowLevelUpModal(false);
		gameBridge.emitSettingsChange(fresh.settings);
	}, []);
	const launchConfig = (0, import_react.useMemo)(() => ({
		tankId: progression.selectedTank,
		arenaId: progression.selectedArena,
		cosmeticId: progression.equippedCosmetic,
		customization: progression.tankCustomizations[progression.selectedTank] ?? null,
		settings
	}), [
		progression.selectedTank,
		progression.selectedArena,
		progression.equippedCosmetic,
		progression.tankCustomizations,
		settings
	]);
	(0, import_react.useEffect)(() => {
		gameBridge.setLaunchConfig(launchConfig);
	}, [launchConfig]);
	const startBattle = (0, import_react.useCallback)((tankIdOverride) => {
		soundFX.unlockFromUserGesture();
		const activeProg = progressionRef.current;
		const targetTankId = tankIdOverride && TANK_DEFINITIONS[tankIdOverride]?.implemented && isTankUnlocked(activeProg, tankIdOverride) ? tankIdOverride : isTankUnlocked(activeProg, activeProg.selectedTank) ? activeProg.selectedTank : "assault";
		const effectiveConfig = {
			tankId: targetTankId,
			arenaId: activeProg.selectedArena,
			cosmeticId: activeProg.equippedCosmetic,
			customization: activeProg.tankCustomizations[targetTankId] ?? null,
			settings
		};
		gameBridge.setLaunchConfig(effectiveConfig);
		setLastResult(null);
		setLastMatchSummary(null);
		setLevelUpModalSummary(null);
		setShowLevelUpModal(false);
		gameBridge.clearLastHudSnapshot();
		if (screen === "RESULTS") {
			setScreen("IN_GAME");
			gameBridge.sendCommand("RESTART");
		} else {
			setMatchInstanceKey((k) => k + 1);
			setScreen("IN_GAME");
		}
		if (isTouchDevice) enterLandscapeFullscreen();
	}, [
		isTouchDevice,
		screen,
		settings
	]);
	const handleResultsPlayAgain = (0, import_react.useCallback)(async () => {
		setTransitioningAd(true);
		try {
			await platformBridge.maybeShowInterstitial("match_complete", { inActiveMatch: screenRef.current === "IN_GAME" });
		} finally {
			setTransitioningAd(false);
			startBattle();
		}
	}, [startBattle]);
	const handleResultsMainMenu = (0, import_react.useCallback)(async () => {
		setTransitioningAd(true);
		try {
			await platformBridge.maybeShowInterstitial("return_to_menu", { inActiveMatch: screenRef.current === "IN_GAME" });
		} finally {
			setTransitioningAd(false);
			setShowLevelUpModal(false);
			setLevelUpModalSummary(null);
			setScreen("MAIN_MENU");
		}
	}, []);
	const unclaimedMissionsCount = (0, import_react.useMemo)(() => countUnclaimedRewards(missionsState).total, [missionsState]);
	if (!bridgeReady) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative w-full h-full bg-[#141714] tactical-bg-grid text-[#F3EFE6] flex flex-col items-center justify-center p-6 text-center",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "w-14 h-14 rounded-2xl bg-[#E08E26] text-[#141714] flex items-center justify-center shadow-xl border border-[#FEF08A]/45 mb-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Crosshair, { className: "w-8 h-8 stroke-[2.5]" })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-3xl sm:text-4xl font-extrabold tracking-wider uppercase text-[#F3EFE6]",
				children: "TANKBOUND ARENA"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-mono uppercase tracking-[0.2em] text-[#E08E26] mt-2",
				children: "Preparing Command Deck..."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "w-48 h-1.5 rounded-full bg-[#222720] border border-[#F3EFE6]/12 overflow-hidden mt-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-full w-2/3 bg-[#E08E26] animate-pulse rounded-full" })
			})
		]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative w-full h-full overflow-hidden bg-[#141714]",
		children: [
			screen === "MAIN_MENU" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MainMenu, {
				progression,
				sessionCustomizations: progression.tankCustomizations,
				unclaimedMissionsCount,
				onNavigate: navigateTo,
				onStartBattle: () => startBattle()
			}),
			screen === "PROFILE" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProfileScreen, {
				progression,
				onUpdatePlayerName: handleUpdatePlayerName,
				onEquipCosmetic: handleEquipCosmetic,
				onPurchaseCosmetic: handlePurchaseCosmetic,
				onOpenStatistics: () => navigateTo("STATISTICS"),
				onBack: () => setScreen("MAIN_MENU")
			}),
			screen === "STATISTICS" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatisticsScreen, {
				progression,
				missionsState,
				lastSavedAtMs,
				onOpenProfile: () => navigateTo("PROFILE"),
				onOpenMissions: () => navigateTo("MISSIONS"),
				onBack: () => setScreen("MAIN_MENU")
			}),
			screen === "GARAGE" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GarageScreen, {
				progression,
				sessionCustomizations: progression.tankCustomizations,
				onApplyCustomization: handleApplyTankCustomization,
				onResetCustomization: handleResetTankCustomization,
				onSelectTank: handleSelectTank,
				onPurchaseTank: handlePurchaseTank,
				onPurchasePreset: handlePurchasePreset,
				onPurchasePaintColor: handlePurchasePaintColor,
				onPurchaseCustomPaint: handlePurchaseCustomPaint,
				onPurchaseDecal: handlePurchaseDecal,
				onPurchaseCosmetic: handlePurchaseCosmetic,
				onEquipCosmetic: handleEquipCosmetic,
				onOpenCollection: () => navigateTo("TANK_COLLECTION"),
				onBack: () => setScreen(previousMenuScreen === "TANK_COLLECTION" ? "TANK_COLLECTION" : "MAIN_MENU"),
				onStartBattle: startBattle
			}),
			screen === "TANK_COLLECTION" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TankRosterScreen, {
				progression,
				sessionCustomizations: progression.tankCustomizations,
				isRewardedSupported: bridgeState.isRewardedSupported,
				onWatchRewardedAd: handleWatchRewardedAd,
				onSelectTank: handleSelectTank,
				onPurchaseTank: handlePurchaseTank,
				onOpenGarage: () => navigateTo("GARAGE"),
				onBack: () => setScreen(previousMenuScreen === "GARAGE" ? "GARAGE" : "MAIN_MENU"),
				onStartBattle: startBattle
			}),
			screen === "ARENA_SELECT" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArenaSelectionScreen, {
				selectedArena: progression.selectedArena,
				onSelectArena: handleSelectArena,
				onBack: () => setScreen("MAIN_MENU"),
				onStartBattle: () => startBattle()
			}),
			screen === "MISSIONS" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MissionsScreen, {
				progression,
				missionsState,
				onClaimReward: handleClaimMissionReward,
				onCheckReset: checkMissionResets,
				onBack: () => {
					setShowLevelUpModal(false);
					setLevelUpModalSummary(null);
					setScreen("MAIN_MENU");
				}
			}),
			screen === "SETTINGS" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SettingsScreen, {
				settings,
				onUpdateSettings: handleUpdateSettings,
				onResetSettings: handleResetSettings,
				onResetProgress: handleResetProgress,
				onBack: () => setScreen("MAIN_MENU")
			}),
			screen === "HOW_TO_PLAY" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HowToPlayScreen, { onBack: () => setScreen("MAIN_MENU") }),
			(screen === "IN_GAME" || screen === "RESULTS") && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative w-full h-full",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PhaserGameHost, {
					launchConfig,
					matchInstanceKey
				}), screen === "IN_GAME" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GameHUD, {
					settings,
					selectedTankId: progression.selectedTank,
					onToggleSound: handleToggleSound,
					onToggleMusic: handleToggleMusic,
					onExitToMenu: () => setScreen("MAIN_MENU"),
					onRestartMatch: () => {}
				})]
			}),
			screen === "RESULTS" && lastResult && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResultsScreen, {
				result: lastResult,
				progression,
				summary: lastMatchSummary,
				isRewardedSupported: bridgeState.isRewardedSupported,
				onWatchRewardedAd: handleWatchRewardedAd,
				onPlayAgain: handleResultsPlayAgain,
				onMainMenu: handleResultsMainMenu
			}),
			transitioningAd && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				"aria-live": "polite",
				className: "fixed inset-0 z-50 bg-[#0D0F0D]/80 backdrop-blur-xs flex items-center justify-center p-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "rounded-xl bg-[#1E221D] border border-[#F3EFE6]/20 px-5 py-3 text-xs font-mono uppercase tracking-wider text-[#F3EFE6]/85 shadow-xl",
					children: "Preparing Next Sector..."
				})
			}),
			(screen === "RESULTS" || screen === "MISSIONS") && showLevelUpModal && levelUpModalSummary && levelUpModalSummary.levelsGained > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LevelUpModal, {
				summary: levelUpModalSummary,
				activeTankId: lastResult?.tankId ?? progression.selectedTank,
				onDismiss: () => {
					setShowLevelUpModal(false);
					setLevelUpModalSummary(null);
				}
			}),
			showLandscapeOverlay && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "fixed inset-0 z-50 bg-[#141714]/92 backdrop-blur-sm flex items-center justify-center p-5",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "w-full max-w-sm bg-[#1E221D] border-2 border-[#E08E26]/45 rounded-2xl p-6 text-center shadow-2xl",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "w-12 h-12 rounded-full bg-[#E08E26]/15 border border-[#E08E26]/50 text-[#E08E26] flex items-center justify-center mx-auto mb-3",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCw, { className: "w-6 h-6" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display text-2xl font-extrabold tracking-wide text-[#F3EFE6]",
							children: "Landscape Mode Recommended"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs sm:text-sm text-[#F3EFE6]/75 mt-2 leading-relaxed",
							children: "Tankbound Arena is designed for landscape dual-stick controls and full-arena visibility. Rotate your device sideways or switch to landscape fullscreen."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-col gap-2.5 mt-5",
							children: [canFullscreen && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => enterLandscapeFullscreen(),
								className: "min-h-[46px] w-full rounded-xl bg-[#E08E26] text-[#141714] font-semibold text-sm flex items-center justify-center gap-2 hover:bg-[#EE9B32] transition whitespace-nowrap",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Maximize2, { className: "w-4 h-4" }), "Switch to Landscape Fullscreen"]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => setDismissedPortraitPrompt(true),
								className: "min-h-[44px] w-full rounded-xl border border-[#F3EFE6]/20 text-[#F3EFE6]/85 text-sm font-medium hover:bg-[#272C25] transition whitespace-nowrap",
								children: "Continue Anyway"
							})]
						})
					]
				})
			}),
			saveFeedbackText && screen !== "IN_GAME" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				role: "status",
				"aria-live": "polite",
				className: "pointer-events-none fixed bottom-3 right-3 z-40 inline-flex items-center gap-1.5 rounded-xl bg-[#1B1F1A]/95 border border-[#22C55E]/45 px-3 py-1.5 text-[11px] font-mono font-semibold text-[#86EFAC] shadow-lg backdrop-blur-xs",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "w-3.5 h-3.5 stroke-[2.5]" }), saveFeedbackText]
			})
		]
	});
}
// src/main.tsx
(0, import_client.createRoot)(document.getElementById("root")).render(/* @__PURE__ */ (0, import_jsx_runtime.jsx)(App, {}));
